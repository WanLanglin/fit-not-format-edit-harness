from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op

OPERATORS = ("+", "-", "*", "/")


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""

        def apply_op(op: Op, left: float, right: float) -> float:
            match op:
                case "+":
                    return left + right
                case "-":
                    return left - right
                case "*":
                    return left * right
                case "/":
                    return left / right
                case _:
                    raise Exception(f"unknown operator: {op!r}")

        # Work on a copy so the caller's list is left untouched.
        tokens = list(inputs)

        while True:
            # 1. scan down the list until there is an operator
            op_index = next(
                (i for i, token in enumerate(tokens) if token in OPERATORS), None
            )
            if op_index is None:
                break  # there are no operators left

            # 2. apply the operator to the last two numbers and replace them
            #    with the result
            if op_index < 2:
                raise Exception("malformed expression: operator without two numbers")
            left, right = tokens[op_index - 2], tokens[op_index - 1]
            tokens = (
                tokens[: op_index - 2]
                + [apply_op(tokens[op_index], left, right)]
                + tokens[op_index + 1 :]
            )

            # 3. repeat this process from the start on the new sequence

        # The input is malformed when this leaves more than one number behind.
        if len(tokens) != 1:
            raise Exception("malformed expression: more than one number remaining")

        return tokens[0]
