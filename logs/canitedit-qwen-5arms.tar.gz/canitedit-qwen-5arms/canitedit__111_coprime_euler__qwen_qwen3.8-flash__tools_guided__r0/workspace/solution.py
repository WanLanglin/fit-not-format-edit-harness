import math

def gcd(a : int, b : int) -> int:
    """Compute the Greatest Common Divisor (GCD) of a and b."""
    assert a > 0 and b > 0
    while b != 0:
        a, b = b, a % b
    return a

def euler_totient(n : int) -> int:
    """Compute the Euler's Totient function of n."""
    assert n > 0 
    if n == 1 : return 1
    count = 0
    for i in range(1, n):
        if gcd(i, n) == 1:
            count += 1
    return count

def powermod(base : int, exp : int, mod : int) -> int:
    """Compute base**exp % mod using successive squaring.

    The recursion halves the exponent at every step: to evaluate
    base**exp it first computes base**(exp // 2) and squares that
    result modulo `mod` (multiplying once more by `base` when `exp`
    is odd).  The exponent-0 case returns 1.
    """
    assert exp >= 0 and mod > 0
    if exp == 0:
        return 1
    if mod == 1:
        return 0
    base = base % mod
    half = powermod(base, exp // 2, mod)   # base ** (exp / 2)
    result = (half * half) % mod           # base ** (2 * (exp // 2))
    if exp % 2 == 1:
        result = (result * base) % mod     # restore the leftover factor
    return result

def check_coprime_euler(a : int, b : int):
    assert a > 0 and b > 0
    return powermod(a, euler_totient(b), b) == 1
