from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception
        
class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True


class GoodStrategy(Strategy):
    '''A strong tic-tac-toe strategy.

    It works out whose turn it is from the board it is given, then chooses a
    move using the usual priorities:

        1. win the game outright,
        2. block an opponent who is about to win,
        3. take the centre,
        4. create a fork (two winning threats at once),
        5. deny the opponent a fork,
        6. take a corner, and finally any remaining square.
    '''

    LINES = (
        ((0, 0), (0, 1), (0, 2)),
        ((1, 0), (1, 1), (1, 2)),
        ((2, 0), (2, 1), (2, 2)),
        ((0, 0), (1, 0), (2, 0)),
        ((0, 1), (1, 1), (2, 1)),
        ((0, 2), (1, 2), (2, 2)),
        ((0, 0), (1, 1), (2, 2)),
        ((2, 0), (1, 1), (0, 2)),
    )

    SQUARES = ((0, 0), (0, 2), (2, 0), (2, 2), (0, 1), (1, 0), (1, 2), (2, 1))

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        mine = self._markToPlay(board)
        theirs = not mine

        # 1. Win immediately, if that is possible.
        move = self._completingMove(board, mine)
        if move is not None:
            return move

        # 2. Otherwise stop the opponent from winning on their next move.
        move = self._completingMove(board, theirs)
        if move is not None:
            return move

        # 3. The centre belongs to the most lines, so grab it early.
        if board[1][1] is None:
            return (1, 1)

        # 4. Create a fork: two threats the opponent cannot both block.
        move = self._forkMove(board, mine)
        if move is not None:
            return move

        # 5. If the opponent could fork, take the square they would use.
        move = self._forkMove(board, theirs)
        if move is not None:
            return move

        # 6. Corners are worth more than edges.
        for square in self.SQUARES:
            if board[square[0]][square[1]] is None:
                return square

        raise Exception  # The board is full, so the game is already over.

    def _markToPlay(self, board: List[List[bool]]) -> bool:
        '''X (True) is to move when both players have played the same number
           of moves, otherwise it is O's (False) turn.'''
        marks = [cell for row in board for cell in row if cell is not None]
        return len(marks) % 2 == 0

    def _completingMove(self, board: List[List[bool]], mark: bool):
        '''Returns the empty square that finishes a line of three `mark`s,
           or None when no such square exists.'''
        for line in self.LINES:
            values = [board[row][col] for row, col in line]
            if values.count(mark) == 2 and values.count(None) == 1:
                return line[values.index(None)]
        return None

    def _forkMove(self, board: List[List[bool]], mark: bool):
        '''Returns an empty square which, if played, creates two separate
           winning threats for `mark`, or None when no such square exists.'''
        for row in range(3):
            for col in range(3):
                if board[row][col] is not None:
                    continue
                threats = 0
                for line in self.LINES:
                    if (row, col) not in line:
                        continue
                    values = [mark if (lineRow, lineCol) == (row, col)
                              else board[lineRow][lineCol]
                              for lineRow, lineCol in line]
                    if values.count(mark) == 2 and values.count(None) == 1:
                        threats += 1
                if threats >= 2:
                    return (row, col)
        return None
