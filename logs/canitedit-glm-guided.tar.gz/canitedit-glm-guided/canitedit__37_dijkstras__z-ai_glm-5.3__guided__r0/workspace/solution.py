import heapq
import itertools
from typing import Dict, List, Optional


class Node:
    '''Simple node (No duplicate edges between nodes)'''

    def __init__(self, id: int):
        self.id = id
        self.out_edges = []
        self.in_edges = []

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Node):
            return False
        else:
            return self.id == __value.id

    def __hash__(self) -> int:
        return self.id


class Edge:
    def __init__(self, src: Node, dest: Node, weight: int):
        assert weight > 0

        self.src = src
        self.dest = dest
        self.weight = weight

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Edge):
            return False
        else:
            return self.dest == __value.dest and self.src == __value.src


class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''

    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques.keys():
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        self.edges = []

    def add_edge(self, edge: Edge):
        assert edge not in self.edges
        self.edges.append(edge)

    def fibonacci(self, x: Node) -> Dict[Node, Optional[int]]:
        '''Shortest distance from x to every node of the graph.

        Returns a dictionary with every node in self.nodes as keys.  Each
        value is the length of the shortest path (the smallest possible sum
        of edge weights) leading from x to that node, or None when no such
        path exists.
        '''
        distances: Dict[Node, Optional[int]] = {}
        distances[x] = 0

        # Collect every edge the graph knows about.  Besides the edges stored
        # on the graph itself, the per node edge lists are inspected as well,
        # so the result does not depend on how the graph was assembled.
        edges = list(self.edges)
        nodes = list(self.nodes)
        if x not in nodes:
            nodes.append(x)
        for node in nodes:
            edges.extend(getattr(node, 'out_edges', None) or [])
            edges.extend(getattr(node, 'in_edges', None) or [])

        outgoing: Dict[Node, List[Edge]] = {}
        seen = set()
        for edge in edges:
            if id(edge) in seen:
                continue
            seen.add(id(edge))
            outgoing.setdefault(edge.src, []).append(edge)

        # Dijkstra's algorithm (all edge weights are positive).  The counter
        # keeps the queue entries comparable when two distances are equal,
        # since Node does not define an ordering.
        counter = itertools.count()
        queue = [(0, next(counter), x)]
        visited = set()
        while queue:
            distance, _, node = heapq.heappop(queue)
            if node in visited:
                continue
            visited.add(node)

            for edge in outgoing.get(node, []):
                neighbour = edge.dest
                if neighbour in visited:
                    continue
                candidate = distance + edge.weight
                shortest = distances.get(neighbour)
                if shortest is None or candidate < shortest:
                    distances[neighbour] = candidate
                    heapq.heappush(queue, (candidate, next(counter), neighbour))

        return {node: distances.get(node) for node in self.nodes}
