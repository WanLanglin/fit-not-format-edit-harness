import re
from solution import create_rel_diff


def apply_rel_diff(before: str, diff: str) -> str:
    """Apply a relative diff produced by create_rel_diff back onto `before`."""
    lines = before.split("\n")
    if diff == "":
        return before
    parts = re.split(r"(?m)^(\d+)(<add>|<del><add>|<del>)", diff)
    assert parts[0] == "", parts[0]
    groups, order = {}, []
    for i in range(1, len(parts), 3):
        num, op, text = parts[i], parts[i + 1], parts[i + 2]
        text = text[:-1] if text.endswith("\n") else text
        if num not in groups:
            groups[num] = []
            order.append(num)
        groups[num].append((op, text))
    # apply bottom-up so that anchors for earlier ops stay valid
    for num in sorted((int(n) for n in order), reverse=True):
        ops = groups[str(num)]
        assert len([1 for op, _ in ops if op != "<add>"]) <= 1, (num, ops)
        for op, text in ops:
            if op == "<del>":
                del lines[num - 1]
            elif op == "<del><add>":
                lines[num - 1:num] = text.split("\n")
        for text in reversed([t for op, t in ops if op == "<add>"]):
            lines[num:num] = text.split("\n")
    return "\n".join(lines)


cases = [
    # pure prepend (the case being fixed)
    ("a\nb\nc", "x\ny\na\nb\nc"),
    ("a\nb\nc", "a\nb\nc"),
    ("only", "new\nonly"),
    ("a\nb", "1\n2\n3\n4\na\nb"),
    # prepend plus other edits
    ("a\nb\nc", "p\nq\na\nB\nc\nr"),
    ("a\nb\nc", "p\na\nb"),
    ("a\nb\nc\n d", "z\na\nb\nc\n d"),
    # appends / deletes / replaces / mixed
    ("a\nb\nc", "a\nb\nc\nd"),
    ("a\nb\nc", "b\nc"),
    ("a\nb\nc", "a\nX\nc"),
    ("a\nb\nc", "c\nb\na"),
    ("a\nb\nc\nd\ne", "a\nD\ne\nf"),
    ("def f():\n    return 1\n\ndef g():\n    return 2",
     "import os\n\ndef f():\n    return 1\n\ndef g():\n    return 3\n    # note"),
    ("x", ""),
    ("", "y"),
    ("a", "a"),
    ("a\na\na", "b\na\na\na"),
    ("a\na\na", "a\nb\na\na\na"),
    ("head\ntail", "h1\nh2\nhead\nmid\ntail\nt2"),
    # duplicate-content lines interacting with prepend
    ("p\nq\np\nq", "p\np\nq\np\nq"),
    ("a\nb\na\nb", "c\na\nb\na\nb"),
    # prepend + append + identical middle
    ("line1\nline2\nline3\nline4\nline5",
     "NEW0\nNEW1\nline1\nline2\nline3\nline4\nline5\nNEW6"),
    # prepend where the first before line is deleted
    ("a\nb\nc", "p\nq\nb\nc"),
    # prepend + replacement
    ("a\nb\nb\nc", "p\na\nq\nb\nc"),
    ("aaa\naaa\naaa\naaa", "aaa\naaa\naaa\naaa\naaa"),
    ("aaa\naaa\naaa\naaa", "aaa\naaa\naaa"),
]

fails = 0
for before, after in cases:
    d = create_rel_diff(before, after)
    try:
        got = apply_rel_diff(before, d)
    except Exception as e:  # noqa: BLE001
        got = "ERROR: %r" % (e,)
    ok = got == after
    if not ok:
        fails += 1
    print(("PASS" if ok else "FAIL"), repr(before), "->", repr(after))
    print("     diff:", repr(d))
    if not ok:
        print("     got :", repr(got))
print("failures:", fails, "of", len(cases))
