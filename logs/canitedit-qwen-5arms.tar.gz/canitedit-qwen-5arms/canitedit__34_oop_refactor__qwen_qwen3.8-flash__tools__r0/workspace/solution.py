from abc import ABC, abstractmethod


class Message(ABC):
    """Base contract for every kind of message the system can handle."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Turn the raw content into its processed representation."""

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(content={self.content!r})"


class TextMessage(Message):
    """A plain textual message."""

    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    """An image described by its caption/description."""

    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    """Create the right Message subclass for a given message type."""

    _registry = {
        "text": TextMessage,
        "image": ImageMessage,
    }

    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        try:
            message_class = MessageFactory._registry[message_type]
        except KeyError:
            raise ValueError(f"Unknown message type: {message_type!r}")
        return message_class(content)
