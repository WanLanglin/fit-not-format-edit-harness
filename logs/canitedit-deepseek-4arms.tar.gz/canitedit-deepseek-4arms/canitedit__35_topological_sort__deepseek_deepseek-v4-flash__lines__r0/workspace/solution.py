from typing import List
from collections import deque

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        # Build id->node mapping
        node_map = {node.id: node for node in self.nodes}

        # Compute in-degrees (number of edges pointing to each node)
        in_degree = {node.id: 0 for node in self.nodes}
        for node in self.nodes:
            for edge_id in node.out_edges:
                in_degree[edge_id] = in_degree.get(edge_id, 0) + 1

        # Use a queue for BFS-based Kahn's algorithm
        queue = deque([node.id for node in self.nodes if in_degree[node.id] == 0])

        sorted_ids = []
        while queue:
            current_id = queue.popleft()
            sorted_ids.append(current_id)
            for edge_id in node_map[current_id].out_edges:
                in_degree[edge_id] -= 1
                if in_degree[edge_id] == 0:
                    queue.append(edge_id)

        # If not all nodes were sorted, the graph has a cycle
        if len(sorted_ids) != len(self.nodes):
            raise RuntimeError('Graph has a cycle')

        return [node_map[nid] for nid in sorted_ids]
