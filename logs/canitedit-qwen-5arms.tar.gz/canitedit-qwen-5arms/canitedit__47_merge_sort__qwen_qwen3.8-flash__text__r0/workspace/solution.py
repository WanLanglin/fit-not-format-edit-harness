from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort ``lst`` in ascending order, in place, and return it.

    Optimised for partially sorted input (large already-ordered runs):

    * a cheap linear scan at the entry point short-circuits input that is
      already sorted, so no slicing or copying happens at all;
    * after the two halves have been sorted, the merge step is skipped
      entirely when the halves are already ordered relative to each other
      (``L[-1] <= R[0]``). ``lst`` already holds the correct elements in the
      correct positions, so that merge costs no comparisons and no copies.

    The two sorted halves are contiguous, non-overlapping slices, so
    ``L[-1] <= R[0]`` implies every left element is <= every right element and
    the concatenation of the halves is already the merged, sorted order.
    """
    # Fast path: an already sorted (or empty / single element) list needs no
    # splitting and no copying -- only the n - 1 comparisons of this scan.
    if all(lst[i - 1] <= lst[i] for i in range(1, len(lst))):
        return lst

    _merge_sort(lst)
    return lst


def _merge_sort(lst: List[int]) -> None:
    """Recursive merge sort working in place on ``lst``."""
    if len(lst) > 1:
        mid = len(lst) // 2
        L = lst[:mid]
        R = lst[mid:]
        _merge_sort(L)
        _merge_sort(R)

        # Early termination: the two sorted halves are already ordered relative
        # to each other, so the merge is a no-op and can be skipped entirely.
        if L[-1] <= R[0]:
            return

        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                lst[k] = L[i]
                i += 1
            else:
                lst[k] = R[j]
                j += 1
            k += 1
        # At most one of the two tails can hold leftovers; copy it in bulk so a
        # run of remaining elements costs one slice assignment instead of one
        # comparison plus one copy per element.
        if i < len(L):
            lst[k:] = L[i:]
        elif j < len(R):
            lst[k:] = R[j:]
