def gcd(a, b):
    """Return the greatest common divisor of ``a`` and ``b``."""
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a


def lcm(a, b):
    """Return the least common multiple of ``a`` and ``b``."""
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // gcd(a, b)
