from abc import ABC, abstractmethod
import math


class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


class MyVector(Vector):
    def __init__(self, *args: int):
        super().__init__(*args)

    def _check_lengths(self, other: "MyVector") -> None:
        if not isinstance(other, Vector):
            raise TypeError("other must be a Vector")
        if len(self.vals) != len(other.vals):
            raise ValueError(
                "vectors must have the same length: "
                f"{len(self.vals)} != {len(other.vals)}"
            )

    def manhattan_distance(self, other: "MyVector") -> float:
        self._check_lengths(other)
        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def cosine_similarity(self, other: "MyVector") -> float:
        self._check_lengths(other)

        dot = float(sum(a * b for a, b in zip(self.vals, other.vals)))
        self_mag = math.sqrt(sum(a * a for a in self.vals))
        other_mag = math.sqrt(sum(b * b for b in other.vals))

        if self_mag == 0 or other_mag == 0:
            raise ValueError("cosine_similarity is undefined for zero-magnitude vectors")

        # Guard against floating point drift pushing the ratio outside [-1, 1].
        ratio = max(-1.0, min(1.0, dot / (self_mag * other_mag)))
        return float(math.acos(ratio))

