import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def get_end_vowel(word):
    # Returns the vowel that ends a word, allowing for an optional
    # trailing 'm' or 'h' after the vowel, or None if the word does
    # not end in a way that can take part in a 'combo'.
    if not word:
        return None
    if word[-1] in "aeiouy":
        return word[-1]
    if len(word) >= 2 and word[-1] in "mh" and word[-2] in "aeiouy":
        return word[-2]
    return None

def get_start_vowel(word):
    # Returns the vowel that starts a word, allowing for an optional
    # leading 'h' before the vowel, or None if the word does not
    # start in a way that can take part in a 'combo'.
    if not word:
        return None
    if word[0] in "aeiouy":
        return word[0]
    if len(word) >= 2 and word[0] == "h" and word[1] in "aeiouy":
        return word[1]
    return None

def combo_count(line):
    combo_count = 0
    words = line.split()
    for first_word, second_word in zip(words, words[1:]):
        if get_end_vowel(first_word) is not None and get_start_vowel(second_word) is not None:
            combo_count += 1
    return combo_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
