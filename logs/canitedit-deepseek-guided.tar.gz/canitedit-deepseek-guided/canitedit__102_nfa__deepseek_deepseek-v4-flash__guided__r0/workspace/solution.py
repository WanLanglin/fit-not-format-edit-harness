from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2, 3]


class DFA:
    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1, 2}

    def transition(self, input: Input) -> State:
        # Deterministic transition table.
        # 0: {0}        start, not accepting
        # 1: {1, 2}     accepting
        # 2: {2}        accepting
        # 3: {}         dead state, not accepting
        table = {
            0: {"a": 1, "b": 3, "": 0},
            1: {"a": 3, "b": 2, "": 1},
            2: {"a": 3, "b": 2, "": 2},
            3: {"a": 3, "b": 3, "": 3},
        }
        return table[self.current][input]

    def accepted(self):
        return self.current in self.accept
        return self.current in self.accept
