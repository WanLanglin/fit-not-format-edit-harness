import string

# Vowels counted by vowel_count; "y" counts as a vowel (as before).
VOWELS = "aeiouy"

# Vowel combinations that are treated as single sounds and are not counted.
DIPHTHONGS = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def diphthong_at(line, index):
    """Return the longest diphthong starting at index, or None."""
    for diphthong in sorted(DIPHTHONGS, key=len, reverse=True):
        if line.startswith(diphthong, index):
            return diphthong
    return None

def vowel_count(line):
    line = prepare_line(line)
    count = 0
    index = 0
    while index < len(line):
        diphthong = diphthong_at(line, index)
        if diphthong:
            # A diphthong is not counted, so skip all of its letters.
            index += len(diphthong)
        elif line[index] in VOWELS:
            count += 1
            index += 1
        else:
            index += 1
    return count
