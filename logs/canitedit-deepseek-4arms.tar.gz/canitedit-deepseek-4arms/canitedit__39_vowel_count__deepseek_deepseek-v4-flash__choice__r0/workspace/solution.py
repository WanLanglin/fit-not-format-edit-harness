import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    diphthongs = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]
    # Match longer diphthongs first so they are not partially consumed.
    diphthongs.sort(key=len, reverse=True)
    line = prepare_line(line)
    vowel_count = 0
    i = 0
    while i < len(line):
        matched = False
        for diphthong in diphthongs:
            if line.startswith(diphthong, i):
                i += len(diphthong)
                matched = True
                break
        if not matched:
            if line[i] in "aeiouy":
                vowel_count += 1
            i += 1
    return vowel_count
