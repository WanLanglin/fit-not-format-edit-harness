from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort ``lst`` in ascending order, in place, and return it.

    This is a top-down merge sort with an *early termination* check that makes
    it adaptive to partially ordered input (see :func:`_merge_sort`): when the
    two sorted runs are already ordered relative to each other the merge is
    dropped entirely, so no comparisons and no element copies are performed.

    A long already-sorted subsequence therefore costs one boundary comparison
    per level that spans it instead of a full linear merge, and an input that
    is already sorted ends up with ``O(n)`` comparisons and *zero* copies.
    Worst case (interleaved input) is unchanged: ``O(n log n)``.
    """
    n = len(lst)
    if n > 1:
        # One auxiliary buffer for the whole recursion: no per-merge
        # allocations, and it is only touched when a real merge happens.
        _merge_sort(lst, 0, n - 1, [0] * n)
    return lst


def _merge_sort(lst: List[int], lo: int, hi: int, aux: List[int]) -> None:
    """Merge sort ``lst[lo:hi + 1]`` in place, using ``aux`` as scratch space."""
    if lo >= hi:
        return

    mid = (lo + hi) // 2
    _merge_sort(lst, lo, mid, aux)
    _merge_sort(lst, mid + 1, hi, aux)

    # Early termination: both runs are sorted, and if the largest element of
    # the left run is <= the smallest element of the right run (they are
    # adjacent here, so the boundary elements are exactly those two), the range
    # is already merged.  Skip the merge phase: 1 comparison, 0 copies,
    # instead of up to (hi - lo) comparisons and (hi - lo + 1) copies.
    if lst[mid] <= lst[mid + 1]:
        return

    _merge(lst, lo, mid, hi, aux)


def _merge(lst: List[int], lo: int, mid: int, hi: int, aux: List[int]) -> None:
    """Merge the sorted runs ``lst[lo:mid + 1]`` and ``lst[mid + 1:hi + 1]``."""
    # Snapshot the runs: ``lst`` is overwritten from ``lo`` upwards while these
    # are read.  Only the left run needs to be buffered, because a right-run
    # element is always emitted at its own index or later.
    aux[lo:mid + 1] = lst[lo:mid + 1]

    i = lo          # read cursor into the buffered left run (in aux)
    j = mid + 1     # read cursor into the right run (still in lst)
    for k in range(lo, hi + 1):
        if i > mid:
            # Left run exhausted: every remaining lst[j:hi + 1] element is
            # already at its final index, so there is nothing left to copy.
            break
        if j > hi:
            # Right run exhausted: shift the tail of the left run over.
            lst[k] = aux[i]
            i += 1
        elif aux[i] <= lst[j]:
            # '<=' keeps earlier elements first, so the sort is stable.
            lst[k] = aux[i]
            i += 1
        else:
            lst[k] = lst[j]
            j += 1
