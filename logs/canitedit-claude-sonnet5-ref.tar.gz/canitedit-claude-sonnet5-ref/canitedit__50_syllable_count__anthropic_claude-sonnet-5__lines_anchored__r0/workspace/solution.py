import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def combo_count(line):
    """Count word-boundary vowel elisions ("combos") in a prepared line.

    A combo happens between two consecutive words when the first word
    ends in a vowel (optionally followed by 'm') and the second word
    begins with a vowel (optionally preceded by 'h').
    """
    vowels = "aeiouy"
    words = line.split()
    combo_count = 0

    for first_word, second_word in zip(words, words[1:]):
        ends_in_vowel = bool(first_word) and first_word[-1] in vowels
        ends_in_vowel_m = (
            len(first_word) >= 2
            and first_word[-1] == "m"
            and first_word[-2] in vowels
        )

        starts_with_vowel = bool(second_word) and second_word[0] in vowels
        starts_with_h_vowel = (
            len(second_word) >= 2
            and second_word[0] == "h"
            and second_word[1] in vowels
        )

        if (ends_in_vowel or ends_in_vowel_m) and (
            starts_with_vowel or starts_with_h_vowel
        ):
            combo_count += 1

    return combo_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
