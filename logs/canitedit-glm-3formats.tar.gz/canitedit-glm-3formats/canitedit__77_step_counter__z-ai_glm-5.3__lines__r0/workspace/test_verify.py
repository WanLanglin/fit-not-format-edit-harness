from solution import StepCounter, FitnessTracker

c = StepCounter()
c.add_steps(1250)
assert c.get_steps() == 1250
assert c.get_distance() == 1.0, c.get_distance()

c2 = StepCounter()
c2.add_steps(1251)
assert abs(c2.get_distance() - 1.0008) < 1e-9, c2.get_distance()

c3 = StepCounter()
c3.add_steps(1249)
assert abs(c3.get_distance() - 0.9992) < 1e-9, c3.get_distance()

c4 = StepCounter()
c4.add_steps(600)
c4.add_steps(650)
assert abs(c4.get_distance() - 1.0) < 1e-9, c4.get_distance()

print("all checks passed")
