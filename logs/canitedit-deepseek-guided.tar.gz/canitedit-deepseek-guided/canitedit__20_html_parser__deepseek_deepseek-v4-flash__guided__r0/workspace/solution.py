from typing import List, Union, Dict
import re


class HTMLElement:
    def __init__(self, name, content: List[Union[str, 'HTMLElement']], attributes: Dict[str, str] = None):
        self.name = name
        self.content = content
        self.attributes = attributes if attributes is not None else {}

    def __str__(self):
        attr_str = ''.join(f' {k}="{v}"' for k, v in self.attributes.items())
        return f"<{self.name}{attr_str}>{''.join(str(c) for c in self.content)}</{self.name}>"

    def __repr__(self):
        return f"HTMLElement(name={self.name}, content={repr(self.content)}, attributes={self.attributes})"


def parse(content: str) -> List[HTMLElement]:
    """
    Parses the given HTML content and returns a list of HTMLElements.
    """
    tokens = tokenize(content)
    stack = []
    result = []

    for token in tokens:
        if is_start_tag(token):
            stack.append(HTMLElement(get_tag_name(token), [], get_attributes(token)))
        elif is_end_tag(token):
            element = stack.pop()
            if stack:
                stack[-1].content.append(element)
            else:
                result.append(element)
        else:
            if stack:
                stack[-1].content.append(token)

    return result


def tokenize(content: str) -> List[str]:
    # This regex splits the content into tags and text.
    # It looks for anything that starts with '<' and ends with '>', and treats it as a tag.
    # Everything else is treated as text.
    return re.findall(r'<[^>]+>|[^<]+', content)


def is_start_tag(token: str) -> bool:
    # A start tag starts with '<' but does not start with '</'.
    return token.startswith('<') and not token.startswith('</')


def is_end_tag(token: str) -> bool:
    # An end tag starts with '</'.
    return token.startswith('</')


def get_tag_name(token: str) -> str:
    # Extracts the tag name from a token.
    # It removes '<', '>', and '/' from the token to get the tag name.
    return token.strip('</>').split()[0]


def get_attributes(token: str) -> Dict[str, str]:
    # Extracts the attributes from a token.
    # An attribute is of the form name="value" or name='value'.
    # The value may contain spaces, so we must respect the quotes.
    attributes = {}
    token = token.strip('<>')
    # Split on the first word (the tag name), then parse the rest attribute-by-attribute
    # while respecting quoted values that may contain spaces.
    match = re.match(r'^(\S+)\s*(.*)$', token)
    if not match:
        return attributes
    rest = match.group(2)
    # Parse attributes like name="value" or name='value'.
    i = 0
    while i < len(rest):
        # Skip whitespace between attributes.
        while i < len(rest) and rest[i].isspace():
            i += 1
        # Find the attribute name.
        name_start = i
        while i < len(rest) and not rest[i].isspace() and rest[i] != '=':
            i += 1
        if i >= len(rest):
            break
        name = rest[name_start:i]
        if rest[i] != '=':
            # Bare attribute name with no value; not in our format.
            continue
        i += 1  # skip '='
        # Identify the value, which may be quoted and may contain spaces.
        if i < len(rest) and rest[i] in '"\'':
            quote = rest[i]
            i += 1
            value_start = i
            while i < len(rest) and rest[i] != quote:
                i += 1
            value = rest[value_start:i]
            if i < len(rest):
                i += 1  # skip closing quote
        else:
            # Unquoted value, up to the next whitespace.
            value_start = i
            while i < len(rest) and not rest[i].isspace():
                i += 1
            value = rest[value_start:i]
        attributes[name] = value
    return attributes
