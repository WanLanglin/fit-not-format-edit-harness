import re


def concatenate_nums(message):
    parts = re.split(r'(\s{2,})', message)
    if len(parts) == 5:
        subject, first_separator, verb, second_separator, object_ = parts
        return f'{object_}{second_separator}{verb}{first_separator}{subject}'

    words = message.split()
    return f'{words[2]} {words[1]} {words[0]}'


def format_string(name1, name2, message):
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {concatenate_nums(message)}'
    return formattedString
