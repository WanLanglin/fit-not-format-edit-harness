from __future__ import annotations

import pickle
import abc
import warnings
from collections import defaultdict
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import torch
from typing_extensions import deprecated

from . import amp
from .common import amp_definitely_not_available

__all__ = ["GradScaler"]


class OptState(Enum):
    READY = 0
    UNSCALED = 1
    STEPPED = 2


def _refresh_per_optimizer_state() -> Dict[str, Any]:
    return {"stage": OptState.READY, "found_inf_per_device": {}}


def _unscale_grads_(
    optimizer: torch.optim.Optimizer,
    inv_scale: torch.Tensor,
    found_inf: torch.Tensor,
    allow_fp16: bool,
) -> Dict[torch.device, torch.Tensor]:
    per_device_inv_scale = amp._MultiDeviceReplicator(inv_scale)
    per_device_found_inf = amp._MultiDeviceReplicator(found_inf)

    # To set up _amp_foreach_non_finite_check_and_unscale_, split grads by device and dtype.
    # There could be hundreds of grads, so we'd like to iterate through them just once.
    # However, we don't know their devices or dtypes in advance.

    # https://stackoverflow.com/questions/5029934/defaultdict-of-defaultdict
    # Google says mypy struggles with defaultdicts type annotations.
    per_device_and_dtype_grads: Dict[
        torch.device, Dict[torch.dtype, List[torch.Tensor]]
    ] = defaultdict(lambda: defaultdict(list))
    with torch.no_grad():
        for group in optimizer.param_groups:
            for param in group["params"]:
                assert isinstance(param, torch.Tensor)
                if param.grad is None:
                    continue
                if (not allow_fp16) and param.grad.dtype == torch.float16:
                    raise ValueError("Attempting to unscale FP16 gradients.")
                if param.grad.is_sparse:
                    # is_coalesced() == False means the sparse grad has values with duplicate indices.
                    # coalesce() deduplicates indices and adds all values that have the same index.
                    # For scaled fp16 values, there's a good chance coalescing will cause overflow,
                    # so we should check the coalesced _values().
                    if param.grad.dtype is torch.float16:
                        param.grad = param.grad.coalesce()
                    to_unscale = param.grad._values()
                else:
                    to_unscale = param.grad

                # TODO: is there a way to split by device and dtype without appending in the inner loop?
                per_device_and_dtype_grads[to_unscale.device][
                    to_unscale.dtype
                ].append(to_unscale)

        for device, per_dtype_grads in per_device_and_dtype_grads.items():
            for grads in per_dtype_grads.values():
                torch._amp_foreach_non_finite_check_and_unscale_(
                    grads,
                    per_device_found_inf.get(device),
                    per_device_inv_scale.get(device),
                )

    return per_device_found_inf._per_device_tensors


class GradScaler:
    _scale: Optional[torch.Tensor]
    _growth_tracker: Optional[torch.Tensor]
    _per_optimizer_states: Dict[int, Dict[str, Any]]

    def __init__(
        self,
        device: str = "cuda",
        init_scale: float = 2.0**16,
        backoff_factor: float = 0.5,
        growth_interval: int = 2000,
        enabled: bool = True,
    ) -> None:
        self._enabled = enabled

        if self._enabled:
            if (
                device == "cpu"
                or device == "xpu"
                or device == "xpu:0"
                or str(device).startswith("xpu:")
            ):
                # XPU and CPU use higher initial scale (2^32) to avoid frequent overflow
                self._init_scale = 2.0**32
            else:
                self._init_scale = init_scale
            self._backoff_factor = backoff_factor
            self._growth_interval = growth_interval
            self._growth_factor = 2.0

            self._per_optimizer_states = defaultdict(_refresh_per_optimizer_state)
            self._scale: Optional[torch.Tensor] = None
            self._growth_tracker: Optional[torch.Tensor] = None
            self._lazy_init_scale_growth_tracker(device)

        else:
            self._init_scale = init_scale
            self._backoff_factor = backoff_factor
            self._growth_interval = growth_interval
            self._growth_factor = 2.0
            self._per_optimizer_states = defaultdict(_refresh_per_optimizer_state)
            self._scale = None
            self._growth_tracker = None

    def _check_scale_growth_tracker(
        self, funcname: str
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if self._scale is None or self._growth_tracker is None:
            raise RuntimeError(
                f"Attempted {funcname} but _scale and _growth_tracker "
                "are None.  If you are loading a GradScaler, you may need to "
                "call it once at the beginning of your script to initialize it."
            )
        return self._scale, self._growth_tracker

    def _lazy_init_scale_growth_tracker(self, device) -> None:
        if self._scale is None or self._growth_tracker is None:
            self._scale = torch.full(
                (1,), self._init_scale, dtype=torch.float32, device=device
            )
            self._growth_tracker = torch.zeros(
                (1,), dtype=torch.int32, device=device
            )

    def scale(self, outputs):
        if not self._enabled:
            return outputs

        # Short-circuit for the common case.
        if isinstance(outputs, torch.Tensor):
            assert self._scale is not None
            self._lazy_init_scale_growth_tracker(outputs.device)
            return outputs * self._scale.to(device=outputs.device, non_blocking=True)

        # Invoke the more complex machinery only if we're treating multiple outputs.
        stash: List[
            Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.device]
        ] = []  # (out, scale, scaled, dev)

        def apply_scale(val):
            if isinstance(val, torch.Tensor):
                assert self._scale is not None
                self._lazy_init_scale_growth_tracker(val.device)
                s = self._scale.to(device=val.device, non_blocking=True)
                stash.append((val, s, val * s, val.device))
                return stash[-1][2]
            elif isinstance(val, abc.Iterable):
                iterable = map(apply_scale, val)
                if isinstance(val, (list, tuple)):
                    return type(val)(iterable)
                else:
                    return iterable
            else:
                raise ValueError("outputs must be a Tensor or an iterable of Tensors")

        return apply_scale(outputs)

    def _maybe_opt_step(
        self,
        optimizer: torch.optim.Optimizer,
        optimizer_state: Dict,
        *args,
        **kwargs,
    ) -> Optional[float]:
        retval: Optional[float] = None
        if not sum(v.item() for v in optimizer_state["found_inf_per_device"].values()):
            retval = optimizer.step(*args, **kwargs)
        return retval

    def unscale_(self, optimizer: torch.optim.Optimizer) -> None:
        if not self._enabled:
            return

        self._check_scale_growth_tracker("unscale_")

        optimizer_state = self._per_optimizer_states[id(optimizer)]

        if optimizer_state["stage"] is OptState.UNSCALED:
            raise RuntimeError(
                "unscale_() has already been called on this optimizer since the last update()."
            )
        elif optimizer_state["stage"] is OptState.STEPPED:
            raise RuntimeError("unscale_() is being called after step().")

        assert self._scale is not None
        inv_scale = self._scale.double().reciprocal().float()
        found_inf = torch.full(
            (1,), 0.0, dtype=torch.float32, device=self._scale.device
        )

        optimizer_state["found_inf_per_device"] = _unscale_grads_(
            optimizer, inv_scale, found_inf, False
        )
        optimizer_state["stage"] = OptState.UNSCALED

    def step(self, optimizer: torch.optim.Optimizer, *args, **kwargs) -> Optional[float]:
        if not self._enabled:
            return optimizer.step(*args, **kwargs)

        self._check_scale_growth_tracker("step")

        if isinstance(optimizer, torch.optim.Optimizer):
            optimizer_state = self._per_optimizer_states[id(optimizer)]
        else:
            raise RuntimeError("step() requires an instance of torch.optim.Optimizer.")

        if optimizer_state["stage"] is OptState.STEPPED:
            raise RuntimeError("step() has already been called since the last update().")

        retval: Optional[float] = None

        if optimizer_state["stage"] is OptState.READY:
            self.unscale_(optimizer)

        assert len(optimizer_state["found_inf_per_device"]) > 0
        if optimizer_state["stage"] is OptState.UNSCALED:
            retval = self._maybe_opt_step(
                optimizer, optimizer_state, *args, **kwargs
            )
        else:
            # The optimizer wasn't uncaled, so we're done with this step.
            pass

        optimizer_state["stage"] = OptState.STEPPED

        return retval

    def update(self, new_scale=None) -> None:
        if not self._enabled:
            return

        self._check_scale_growth_tracker("update")

        if new_scale is not None:
            # Accept a new user-specified scale.
            if isinstance(new_scale, float):
                self._scale.fill_(new_scale)  # type: ignore[union-attr]
            else:
                reason = (
                    "new_scale should be a float or a 1-element torch.cuda.FloatTensor "
                    "with a single value."
                )
                assert isinstance(new_scale, torch.cuda.FloatTensor), reason  # type: ignore[union-attr]
                self._scale.copy_(new_scale)  # type: ignore[union-attr]
        else:
            # Consume shared inf/nan data collected from optimizers to update the scale.
            # If all found_inf tensors are zero, growth_tracker is incremented.
            # If any found_inf tensor is non-zero, growth_tracker is reset to 0 and scale
            # is multiplied by backoff_factor.
            assert self._scale is not None
            assert self._growth_tracker is not None
            found_infs = [
                found_inf.to(self._scale.device, non_blocking=True)
                for state in self._per_optimizer_states.values()
                for found_inf in state["found_inf_per_device"].values()
            ]

            assert len(found_infs) > 0, "No inf checks were recorded prior to update."

            found_inf_combined = found_infs[0]
            if len(found_infs) > 1:
                for i in range(1, len(found_infs)):
                    found_inf_combined += found_infs[i]

            torch._amp_update_scale_(
                self._scale,
                self._growth_tracker,
                found_inf_combined,
                self._growth_factor,
                self._backoff_factor,
                self._growth_interval,
            )

        # To prepare for next iteration, clear the data collected from optimizers this iteration.
        self._per_optimizer_states = defaultdict(_refresh_per_optimizer_state)

    def get_scale(self) -> float:
        if self._enabled:
            return self._scale.item()  # type: ignore[union-attr]
        else:
            return self._init_scale

    def get_growth_factor(self) -> float:
        return self._growth_factor

    def set_growth_factor(self, new_factor: float) -> None:
        self._growth_factor = new_factor

    def get_backoff_factor(self) -> float:
        return self._backoff_factor

    def set_backoff_factor(self, new_factor: float) -> None:
        self._backoff_factor = new_factor

    def get_growth_interval(self) -> int:
        return self._growth_interval

    def set_growth_interval(self, new_interval: int) -> None:
        self._growth_interval = new_interval

    def is_enabled(self) -> bool:
        return self._enabled

    def is_active(self) -> bool:
        warnings.warn(
            "GradScaler is_enabled and is_active are now identical"
            " since _scale is always populated.",
            stacklevel=2,
        )
        return self._enabled

    def state_dict(self) -> Dict[str, Any]:
        return (
            {
                "scale": self._scale,
                "growth_factor": self._growth_factor,
                "backoff_factor": self._backoff_factor,
                "growth_interval": self._growth_interval,
                "_growth_tracker": self._growth_tracker,
                "_per_optimizer_states": self._per_optimizer_states,
            }
            if self._enabled
            else {}
        )

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        if not self._enabled:
            raise RuntimeError(
                "GradScaler is disabled, so cannot load state dict."
            )
        if len(state_dict) == 0:
            raise RuntimeError(
                "The source state dict is empty, possibly because it was saved "
                "from a disabled instance of GradScaler."
            )
        self._scale = state_dict["scale"]
        self._growth_factor = state_dict["growth_factor"]
        self._backoff_factor = state_dict["backoff_factor"]
        self._growth_interval = state_dict["growth_interval"]
        self._growth_tracker = state_dict["_growth_tracker"]
        self._per_optimizer_states = state_dict["_per_optimizer_states"]

    def __getstate__(self) -> Dict[str, Any]:
        return self.state_dict()

    def __setstate__(self, state: Dict[str, Any]) -> None:
        if self._enabled:
            self.load_state_dict(state)
        else:
            pass

    def __repr__(self) -> str:
        return (
            f"GradScaler(enabled={self._enabled}, init_scale={self._init_scale}, "
            f"backoff_factor={self._backoff_factor}, growth_factor={self._growth_factor}, "
            f"growth_interval={self._growth_interval})"
        )
