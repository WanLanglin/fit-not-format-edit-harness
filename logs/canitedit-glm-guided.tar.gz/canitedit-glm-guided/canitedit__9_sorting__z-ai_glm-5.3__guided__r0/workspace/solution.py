class Sorter:
    def __init__(self):
        pass

    def sort(self, nums: list[int]):
        """Sort `nums` in ascending order, in place."""
        for i in range(1, len(nums)):
            self.insert(nums, i)

    def insert(self, nums: list[int], index: int):
        """Insert `nums[index]` into the sorted prefix `nums[:index]`, in place."""
        num = nums[index]
        pos = index - 1
        while pos >= 0 and nums[pos] > num:
            nums[pos + 1] = nums[pos]
            pos -= 1
        nums[pos + 1] = num
