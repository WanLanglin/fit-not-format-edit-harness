import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def is_vowel(char):
    return char in "aeiouy"


def ends_word_vowel(word):
    # A word ends with a combo-vowel if it ends in a vowel, or in a
    # vowel immediately followed by 'm' at the end of the word.
    if not word:
        return False
    if is_vowel(word[-1]):
        return True
    return len(word) > 1 and word[-1] == "m" and is_vowel(word[-2])


def begins_word_vowel(word):
    # A word begins with a combo-vowel if it starts with a vowel, or with
    # 'h' immediately followed by a vowel.
    if not word:
        return False
    if is_vowel(word[0]):
        return True
    return len(word) > 1 and word[0] == "h" and is_vowel(word[1])


def combo_count(line):
    # Count the 'combo's (elisions) of an already prepared line: a word
    # ending in a vowel (optionally followed by 'm') that is directly
    # followed by a word beginning with a vowel (optionally preceded by 'h').
    words = line.split()
    combos = 0
    for i in range(len(words) - 1):
        if ends_word_vowel(words[i]) and begins_word_vowel(words[i + 1]):
            combos += 1
    return combos


def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
