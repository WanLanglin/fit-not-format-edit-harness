from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    def _sort(lo: int, hi: int) -> None:
        if lo >= hi:
            return
        mid = (lo + hi) // 2
        _sort(lo, mid)
        _sort(mid + 1, hi)

        # Early termination: the two sorted halves are already ordered
        # relative to each other (largest of the left <= smallest of the
        # right), so nothing needs to be merged or copied back.
        if lst[mid] <= lst[mid + 1]:
            return

        # Standard merge. Only the left half needs a temporary copy, which
        # halves the copying cost compared to copying both halves.
        left = lst[lo:mid + 1]
        i = 0          # index into the left copy
        j = mid + 1    # index into the right half of lst
        k = lo         # write position in lst
        while i < len(left) and j <= hi:
            if left[i] <= lst[j]:
                lst[k] = left[i]
                i += 1
            else:
                lst[k] = lst[j]
                j += 1
            k += 1
        while i < len(left):
            lst[k] = left[i]
            i += 1
            k += 1

    _sort(0, len(lst) - 1)
    return lst
