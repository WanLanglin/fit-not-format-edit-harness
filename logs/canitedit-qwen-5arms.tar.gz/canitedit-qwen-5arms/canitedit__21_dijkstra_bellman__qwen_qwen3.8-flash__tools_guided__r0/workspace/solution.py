import heapq


class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.

        Negative edge weights are supported through the Bellman-Ford algorithm, which
        also detects negative cycles: a ``ValueError`` is raised whenever the graph
        contains a negative cycle, since shortest distances are then undefined. Graphs
        whose weights are all non-negative keep using the faster Dijkstra walk.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        if not self._has_negative_weight():
            return self._dijkstra(start)

        edges = self._edge_list()
        if self._has_negative_cycle(edges):
            raise ValueError('Graph contains a negative cycle, '
                             'so shortest distances are undefined')

        return self._bellman_ford(start, edges)

    def _has_negative_weight(self):
        """Return True when at least one edge of the graph has a negative weight."""
        return any(weight < 0
                   for neighbors in self.edges.values()
                   for _, weight in neighbors)

    def _edge_list(self):
        """Return every relaxation candidate as a list of (from, to, weight) tuples."""
        return [(node, neighbor, weight)
                for node, neighbors in self.edges.items()
                for neighbor, weight in neighbors]

    def _has_negative_cycle(self, edges):
        """
        Return True if a negative cycle exists anywhere in the graph.

        Seeding every node with distance 0 makes every edge relaxable from the start,
        so cycles that cannot be reached from a particular source are detected too.
        """
        # Seeding every node with 0 is equivalent to a virtual source joined to all
        # nodes by 0-weight edges, so a negative cycle is always reachable and at most
        # |V| + 1 relaxation rounds are needed to prove that none exists.
        distances = {node: 0 for node in self.nodes}

        for _ in range(len(self.nodes) + 1):
            changed = False
            for from_node, to_node, weight in edges:
                if distances[from_node] + weight < distances[to_node]:
                    distances[to_node] = distances[from_node] + weight
                    changed = True
            if not changed:
                return False

        return True

    def _bellman_ford(self, start, edges=None):
        """
        Shortest distances from start using Bellman-Ford, allowing negative weights.

        Assumes the graph holds no negative cycle; use ``_has_negative_cycle`` first.
        """
        if edges is None:
            edges = self._edge_list()

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # A shortest path without negative cycles uses at most |V| - 1 edges, so that
        # many relaxation rounds suffice; they stop early once nothing changes.
        unreachable = float('infinity')
        for _ in range(max(len(self.nodes) - 1, 0)):
            changed = False
            for from_node, to_node, weight in edges:
                current_dist = shortest_path[from_node]
                if current_dist == unreachable:
                    continue
                distance = current_dist + weight
                if distance < shortest_path[to_node]:
                    shortest_path[to_node] = distance
                    changed = True
            if not changed:
                break

        return shortest_path

    def _dijkstra(self, start):
        """Shortest distances from start, assuming non-negative weights."""
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0
        unvisited_nodes = [(0, start)]

        while unvisited_nodes:
            current_dist, current_node = heapq.heappop(unvisited_nodes)

            if current_dist > shortest_path[current_node]:
                continue

            for neighbor, weight in self.edges[current_node]:
                distance = current_dist + weight

                if distance < shortest_path[neighbor]:
                    shortest_path[neighbor] = distance
                    heapq.heappush(unvisited_nodes, (distance, neighbor))

        return shortest_path
