from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """A deterministic finite automaton equivalent to the original NFA.

    The original NFA (states 0-2, start state 0, accepting states {1, 2},
    epsilon transitions that are all self-loops) accepted exactly the
    language ``a b*``: on "a" it could branch to state 1 (accepting, but
    with no outgoing transitions) or to state 2 (accepting, looping on "b"),
    while "b" from the start state and "a" from state 2 were dead ends.

    Determinising it (subset construction) and merging the equivalent
    accepting subsets {1, 2} and {2} yields this three-state DFA:

    * 0 - start state, not accepting;
    * 1 - accepting, reached on "a" and looping on "b" (merged {1, 2});
    * 2 - dead sink, entered by any input outside the language.

    Both automata therefore accept exactly {a, ab, abb, ...}.  The empty
    input "" keeps the automaton in its current state, mirroring the
    epsilon self-loops of the NFA.
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self):
        return self.current in self.accept
