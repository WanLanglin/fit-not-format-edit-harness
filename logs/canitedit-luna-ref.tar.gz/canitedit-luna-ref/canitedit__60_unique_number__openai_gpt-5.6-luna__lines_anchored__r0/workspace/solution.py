from typing import List


def find_non_pair(numbers: List[int]) -> int:
    unique = 0
    for number in numbers:
        unique ^= number
    return unique
