from typing import List

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Kahn's algorithm: repeatedly emit a node whose predecessors have all
        been emitted. If nodes are left over while none is ready, the graph is
        cyclic and therefore has no topological order.'''
        by_id = {}
        for node in self.nodes:
            if node.id not in by_id:
                by_id[node.id] = node

        # The ids of the graph, in the order the nodes were given.
        node_ids = list(by_id)

        in_degree = dict((node_id, 0) for node_id in node_ids)
        successors = dict((node_id, []) for node_id in node_ids)
        for node in self.nodes:
            for target_id in node.out_edges:
                if target_id not in by_id:
                    # Edge leading to a node that is not part of this graph.
                    continue
                if target_id not in successors[node.id]:
                    successors[node.id].append(target_id)
                    in_degree[target_id] += 1

        ready = [node_id for node_id in node_ids if in_degree[node_id] == 0]
        order = []
        while ready:
            current = ready.pop(0)
            order.append(by_id[current])
            for target_id in successors[current]:
                in_degree[target_id] -= 1
                if in_degree[target_id] == 0:
                    ready.append(target_id)

        if len(order) != len(by_id):
            raise RuntimeError('Graph is cyclic, no topological order exists')

        return order
