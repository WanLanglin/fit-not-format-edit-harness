SPECIAL_CHARACTERS = set("!@#$%^&*()-_=+[]{}\\|;:'\",.<>/?`~")


def minLength(password):
    assert type(password) == str
    return len(password) >= 8


def containsSpecialChar(password):
    for character in password:
        if character in SPECIAL_CHARACTERS:
            return True
    return False


def isPasswordStrong(password):
    return minLength(password) and containsSpecialChar(password)
