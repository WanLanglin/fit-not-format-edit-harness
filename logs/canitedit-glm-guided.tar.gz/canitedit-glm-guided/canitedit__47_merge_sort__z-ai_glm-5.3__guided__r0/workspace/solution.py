from typing import List


def _is_sorted(lst: List[int]) -> bool:
    """Return True when ``lst`` is already in non-decreasing order.

    The scan short-circuits at the first inversion, so it stays cheap on
    unsorted data while letting merge_sort skip all of its work whenever a
    sub-array is already sorted.
    """
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:
            return False
    return True


def merge_sort(lst: List[int]) -> List[int]:
    if len(lst) > 1:
        # Early termination: this sub-array is already sorted, so there is
        # nothing to split, copy, recurse into or merge.
        if _is_sorted(lst):
            return lst

        mid = len(lst) // 2
        L = lst[:mid]
        R = lst[mid:]
        merge_sort(L)
        merge_sort(R)

        # Early termination: the two sorted halves are already ordered
        # relative to each other (every element of L <= every element of R),
        # so the merge loop and all of its comparisons can be skipped.  The
        # halves only have to be written back into place.
        if L[-1] <= R[0]:
            lst[:mid] = L
            lst[mid:] = R
            return lst

        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                lst[k] = L[i]
                i += 1
            else:
                lst[k] = R[j]
                j += 1
            k += 1
        while i < len(L):
            lst[k] = L[i]
            i += 1
            k += 1
        while j < len(R):
            lst[k] = R[j]
            j += 1
            k += 1
    return lst
