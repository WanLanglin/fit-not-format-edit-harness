from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic finite automaton equivalent to the original NFA.

    The NFA accepted exactly ``{ a b^n | n >= 0 }``. Subset construction gives
    ``{0} -a-> {1,2} -b-> {2}`` with every other move reaching the empty set;
    ``{1,2}`` and ``{2}`` are indistinguishable, so the minimal equivalent DFA
    has three states: the start, the accepting ``a b*`` loop, and a dead sink.
    """

    START: State = 0
    ACCEPT: State = 1
    DEAD: State = 2

    # Total transition function: every (state, input) pair yields one state.
    # An ``""`` input leaves the state unchanged, matching the NFA's epsilon
    # self-loops, so it cannot change which words are accepted.
    _TRANSITIONS: dict[State, dict[Input, State]] = {
        0: {"a": 1, "b": 2, "": 0},
        1: {"a": 2, "b": 1, "": 1},
        2: {"a": 2, "b": 2, "": 2},
    }

    def __init__(self) -> None:
        self.current: State = self.START
        self.accept: set[State] = {self.ACCEPT}

    def transition(self, input: Input) -> State:
        """Consume ``input``, move deterministically, and return the new state."""
        self.current = self._TRANSITIONS[self.current][input]
        return self.current

    def accepted(self):
        return self.current in self.accept
