from typing import List, Tuple

def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Kadane's algorithm returning (max_sum, start_index, end_index).

    start_index and end_index are the inclusive indices of the subarray in
    ``lst`` whose sum equals ``max_sum``.
    """
    max_so_far = lst[0]
    curr_max = lst[0]
    srt_idx = 0
    best_srt_idx = 0
    end_idx = 0
    for i in range(1, len(lst)):
        if lst[i] > curr_max + lst[i]:
            curr_max = lst[i]
            srt_idx = i
        else:
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            best_srt_idx = srt_idx
            end_idx = i
    return max_so_far, best_srt_idx, end_idx
