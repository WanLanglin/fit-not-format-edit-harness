class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output

    def next_n_fibs(self, n: int) -> list:
        """Return the next ``n`` Fibonacci numbers without advancing the iterator.

        The sequence starts at the value that ``__next__`` would return right now,
        and the object's state is left untouched, so calling ``__next__`` afterwards
        yields the same number it would have yielded if this method was never called.
        """
        prev_prev, prev = self.prev_prev, self.prev
        result = []
        for _ in range(max(n, 0)):
            output = prev + prev_prev
            prev_prev, prev = prev, output
            result.append(output)
        return result
