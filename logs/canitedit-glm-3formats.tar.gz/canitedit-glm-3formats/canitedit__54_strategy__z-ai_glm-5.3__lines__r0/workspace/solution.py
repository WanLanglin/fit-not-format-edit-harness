from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception
        
class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True


class GoodStrategy(Strategy):
    '''A strategy that beats CornerStrategy.

    CornerStrategy only ever plays corners, and every line that contains a
    corner also needs the centre or an edge, so CornerStrategy can never
    complete a line of its own.  It also never occupies -- and so can never
    block -- the centre or the edges.

    GoodStrategy therefore stays away from the corners entirely (taking one
    could leave CornerStrategy with no corner to play, which makes it raise),
    claims the centre and then completes the middle column, winning the game
    with its third move.

    The strategy is stateless: it works out from the board it is handed
    whether it holds the first player's mark (True) or the second player's
    (False), because the first player always opens and the two players
    strictly alternate.
    '''

    # Every way of winning: three rows, three columns and two diagonals.
    LINES = (
        ((0, 0), (0, 1), (0, 2)),
        ((1, 0), (1, 1), (1, 2)),
        ((2, 0), (2, 1), (2, 2)),
        ((0, 0), (1, 0), (2, 0)),
        ((0, 1), (1, 1), (2, 1)),
        ((0, 2), (1, 2), (2, 2)),
        ((0, 0), (1, 1), (2, 2)),
        ((2, 0), (1, 1), (0, 2)),
    )

    # The centre first, then the rest of the middle column, then the middle
    # row.  None of these cells is a corner.
    PREFERRED_CELLS = ((1, 1), (0, 1), (2, 1), (1, 0), (1, 2))

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        mine = self._firstPlayersTurn(board)

        # Take the game if this move can finish a line of ours.
        winning = self._winningMove(board, mine)
        if winning is not None:
            return winning

        # Otherwise make sure the opponent cannot finish a line next move.
        blocking = self._winningMove(board, not mine)
        if blocking is not None:
            return blocking

        # Otherwise keep building a line through the middle of the board,
        # where CornerStrategy can never interfere.
        for row, col in self.PREFERRED_CELLS:
            if board[row][col] is None:
                return (row, col)

        # The whole middle is taken, so fall back to any free cell.
        for row in range(3):
            for col in range(3):
                if board[row][col] is None:
                    return (row, col)

        raise Exception('the board is full, so there is no move to make')

    def _firstPlayersTurn(self, board: List[List[bool]]) -> bool:
        '''True when the next move on this board belongs to the first player.

        The first player (True) always opens and the players alternate, so
        the board holds an even number of marks exactly when it is the first
        player's turn.
        '''
        played = sum(1 for row in board for cell in row if cell is not None)
        return played % 2 == 0

    def _winningMove(self, board: List[List[bool]], mark: bool):
        '''Returns the single empty cell that would complete a line of `mark`,
        or None when `mark` is not one move away from a line.
        '''
        for line in self.LINES:
            cells = [board[row][col] for row, col in line]
            if cells.count(None) == 1 and cells.count(mark) == 2:
                return line[cells.index(None)]
        return None
