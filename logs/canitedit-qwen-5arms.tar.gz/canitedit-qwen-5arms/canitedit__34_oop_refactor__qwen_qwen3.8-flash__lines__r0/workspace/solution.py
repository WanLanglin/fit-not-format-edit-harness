from abc import ABC, abstractmethod


class Message(ABC):
    """Abstract base class for a message that carries some content."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Process the message and return a string result."""
        raise NotImplementedError("Message subclasses must implement process()")

    def __str__(self) -> str:
        return self.process()


class TextMessage(Message):
    """A plain text message."""

    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    """An image message whose content is a description of the image."""

    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    """Creates Message instances for a requested message type."""

    _MESSAGE_TYPES = {
        "text": TextMessage,
        "image": ImageMessage,
    }

    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        """Return a Message of ``message_type`` holding ``content``.

        Raises:
            ValueError: if ``message_type`` is not a supported type.
        """
        # Dict lookup raises TypeError for unhashable types; treat those as invalid.
        try:
            message_class = MessageFactory._MESSAGE_TYPES.get(message_type)
        except TypeError:
            message_class = None

        if message_class is None:
            raise ValueError(f"Unknown message type: {message_type!r}")

        return message_class(content)


def process_message(message, message_type):
    """Backwards-compatible wrapper around MessageFactory."""
    try:
        return MessageFactory.get_message(message_type, message).process()
    except ValueError:
        return "Unknown message type"
