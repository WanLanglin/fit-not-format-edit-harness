from typing import List

def merge_sort(lst: List[int]) -> List[int]:
    def sort(start: int, end: int) -> None:
        if end - start <= 1:
            return

        mid = (start + end) // 2
        sort(start, mid)
        sort(mid, end)

        # Both halves are sorted at this point.  If the greatest item in
        # the left half is no greater than the least item in the right half,
        # the whole range is already sorted and no merge or copies are needed.
        if lst[mid - 1] <= lst[mid]:
            return

        left = lst[start:mid]
        right = lst[mid:end]
        i = j = 0
        k = start
        while i < len(left) and j < len(right):
            if left[i] < right[j]:
                lst[k] = left[i]
                i += 1
            else:
                lst[k] = right[j]
                j += 1
            k += 1
        while i < len(left):
            lst[k] = left[i]
            i += 1
            k += 1
        while j < len(right):
            lst[k] = right[j]
            j += 1
            k += 1

    sort(0, len(lst))
    return lst
