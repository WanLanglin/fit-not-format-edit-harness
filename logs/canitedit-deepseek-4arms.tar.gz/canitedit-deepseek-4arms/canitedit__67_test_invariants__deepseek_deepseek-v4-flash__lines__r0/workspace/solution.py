class Employer:
    """
    Represents an entity that employs workers.
    """

    def __init__(self, name, funds):
        self.name = name
        self.funds = funds


class Worker:
    """
    Represents a person who does work for an employer.
    Name should be "[first name] [last name]" and pay 
    should be positive.
    """

    def __init__(self, name, pay, company):
        self.name = name
        self.pay = pay
        self.company = company
        self.money = 0

    def lastName(self):
        """
        Returns the last name of the worker.
        """
        return self.name.split()[-1]

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay
        self.company.funds -= self.pay

    def giveRaise(self, percent):
        """
        Gives the worker a raise in pay, given as a percentage of
        the current pay.
        """
        self.pay *= (1.0 + percent)


class PublicWorker(Worker):
    """
    Represents a worker who works for the government.
    People who work for the government are special
    because they are paid with public funds, which
    are virtually unlimited because of public debt.
    """

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay


def test_worker_invariants(w):
    """
    Uses assert to check all the invariants of a Worker,
    including that the name is "[first name] [last name]",
    that the pay is non-negative (per the docs, positive),
    and the semantics of givePay and giveRaise.
    """
    # Name must be first and last name separated by a single space.
    parts = w.name.split(" ")
    assert len(parts) == 2
    assert parts[0] != ""
    assert parts[1] != ""

    # lastName returns the second part of the name.
    assert w.lastName() == parts[1]

    # Pay must be positive (per the documentation) and non-negative.
    assert w.pay is not None
    assert w.pay >= 0

    # givePay should add the pay to the worker's money and
    # remove the pay from the company's funds.
    initial_money = w.money
    initial_funds = w.company.funds
    # Use a copy so we don't disturb the passed-in worker.
    test = _make_test_worker(w)
    test.givePay()
    assert test.money == initial_money + w.pay
    assert test.company.funds == initial_funds - w.pay

    # giveRaise should multiply pay by (1 + percent).
    test2 = _make_test_worker(w)
    percent = 0.5
    test2.giveRaise(percent)
    assert abs(test2.pay - w.pay * (1.0 + percent)) < 1e-9


def test_public_worker_invariants(w):
    """
    Uses assert to check all the invariants of a PublicWorker,
    which is a Worker paid with public funds: givePay adds to
    the worker's money but does not remove from the company's
    funds (they are virtually unlimited).
    """
    # A PublicWorker inherits all the Worker invariants.
    test_worker_invariants(w)

    # But its givePay does not deduct from the company's funds.
    initial_money = w.money
    pay = w.pay
    test = _make_test_worker(w)
    test.givePay()
    assert test.money == initial_money + pay
    assert test.company.funds == w.company.funds


def _make_test_worker(w):
    """
    Builds a fresh worker with the same name/pay/company as w
    so semantics can be checked without mutating w.
    """
    company = _make_test_company(w.company)
    if isinstance(w, PublicWorker):
        return PublicWorker(w.name, w.pay, company)
    return Worker(w.name, w.pay, company)


def _make_test_company(company):
    """
    Builds a fresh company with the same funds as company.
    """
    return Employer(company.name, company.funds)
