from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """A deterministic finite automaton.

    It accepts exactly the same language as the NFA it replaces: every
    string consisting of an "a" followed by zero or more "b"s
    (a, ab, abb, abbb, ...). The empty string is rejected.

    States:
        0: start state, nothing has been read yet
        1: accepting state, "a" has been read followed only by "b"s
        2: dead state, the input read so far is not a prefix of any
           accepted word

    The empty-string input ("") leaves the state unchanged, matching the
    original NFA where every epsilon transition was a self loop.
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table: dict[State, dict[Input, State]] = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self):
        return self.current in self.accept
