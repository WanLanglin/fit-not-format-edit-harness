import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

VOWELS = "aeiouy"

# "aea" must be tried before "ae" so the longest diphthong wins
DIPHTHONGS = sorted(["ae", "oe", "ei", "ea", "ia", "io", "aea"], key=len,
                    reverse=True)


def remove_diphthongs(line):
    """Return line with every diphthong (non-overlapping, left to right) removed."""
    stripped = []
    index = 0
    while index < len(line):
        for diphthong in DIPHTHONGS:
            if line.startswith(diphthong, index):
                index += len(diphthong)
                break
        else:
            stripped.append(line[index])
            index += 1
    return "".join(stripped)

def vowel_count(line):
    vowel_count = 0
    for letter in remove_diphthongs(prepare_line(line)):
        if letter in VOWELS:
            vowel_count += 1
    return vowel_count
