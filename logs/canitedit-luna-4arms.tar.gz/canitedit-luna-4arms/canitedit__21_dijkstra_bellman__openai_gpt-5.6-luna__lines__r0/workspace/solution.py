class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """Compute shortest distances from start with Bellman-Ford.

        Bellman-Ford supports negative edge weights and raises ValueError when
        the graph contains a negative cycle.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0
        edges = [
            (node, neighbor, weight)
            for node, neighbors in self.edges.items()
            for neighbor, weight in neighbors
        ]

        # Relax every edge at most |V| - 1 times.
        for _ in range(len(self.nodes) - 1):
            changed = False
            for from_node, to_node, weight in edges:
                distance = shortest_path[from_node] + weight
                if distance < shortest_path[to_node]:
                    shortest_path[to_node] = distance
                    changed = True
            if not changed:
                break

        # Use a virtual source connected to every node so that negative cycles
        # in disconnected components are detected as well.
        cycle_distances = {node: 0 for node in self.nodes}
        for _ in range(len(self.nodes)):
            changed = False
            for from_node, to_node, weight in edges:
                distance = cycle_distances[from_node] + weight
                if distance < cycle_distances[to_node]:
                    cycle_distances[to_node] = distance
                    changed = True
            if not changed:
                break
        else:
            raise ValueError('Graph contains a negative cycle')

        return shortest_path
