from typing import List


class ConwaysGameOfLife:
    """
    Represents a grid of conway's game of life, where each cell is either alive or dead.
    The rules of the game are the following:
    1. Any live cell with fewer than two live neighbors dies, as if by underpopulation.
    2. Any live cell with two or three live neighbors lives on to the next generation.
    3. Any live cell with more than three live neighbors dies, as if by overpopulation.
    4. Any dead cell with exactly three live neighbors becomes a live cell, as if by reproduction.
    """

    def __init__(self, grid: List[List[int]]):
        """
        Initializes the game with a grid; 0 is dead and 1 is alive.
        """
        self.grid = grid

    def step(self):
        # initialize a fully dead grid
        new_grid = [[0 for _ in row] for row in self.grid]

        for i, row in enumerate(self.grid):
            for j, cell in enumerate(row):
                alive_neighbors = self.compute_alive_nearby_cells(i, j)
                if cell:
                    if alive_neighbors < 2 or alive_neighbors > 3:
                        new_grid[i][j] = 0
                    else:
                        new_grid[i][j] = 1
                else:
                    if alive_neighbors == 3:
                        new_grid[i][j] = 1

        self.grid = new_grid

    def compute_alive_nearby_cells(self, i: int, j: int) -> int:
        """
        Count the live cells surrounding (i, j), excluding (i, j) itself. Positions
        that fall outside the finite grid are skipped rather than indexed.
        """
        count = 0
        for x in range(i - 1, i + 2):
            if x < 0 or x >= len(self.grid):
                continue
            row = self.grid[x]
            for y in range(j - 1, j + 2):
                if x == i and y == j:
                    continue
                if y < 0 or y >= len(row):
                    continue
                count += 1 if row[y] else 0

        return count

    def show(self) -> str:
        buf = ""
        for row in self.grid:
            for cell in row:
                buf += "X" if cell else " "
            buf += "\n"

        return buf


if __name__ == "__main__":
    # Blinker: endpoints of the line lose their only neighbor and the middle
    # survives with two; it must oscillate without IndexError at the edges.
    g = ConwaysGameOfLife([[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [0, 0, 0, 0, 0]])
    for _ in range(4):
        g.step()
    print(g.show())

    # Every cell of a still-life block, including corners, must be countable.
    block = ConwaysGameOfLife([[1, 1], [1, 1]])
    assert [[block.compute_alive_nearby_cells(i, j) for j in range(2)] for i in range(2)] == [[2, 2], [2, 2]]
    assert block.step() is None and block.grid == [[1, 1], [1, 1]]

    # Single cell and ragged grids must not index out of bounds.
    single = ConwaysGameOfLife([[1]])
    assert single.compute_alive_nearby_cells(0, 0) == 0
    single.step()
    assert single.grid == [[0]]
    ragged = ConwaysGameOfLife([[1, 1, 1], [1]])
    assert ragged.compute_alive_nearby_cells(1, 0) == 2
    print("checks passed")
