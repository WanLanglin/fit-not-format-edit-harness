from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception
        
class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True


class GoodStrategy(Strategy):
    """A strategy that exploits the predictable corner-playing opponent."""

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        available = [
            (row, col)
            for row in range(3)
            for col in range(3)
            if board[row][col] is None
        ]

        def would_win(move: Tuple[int, int], player: bool) -> bool:
            row, col = move
            board[row][col] = player
            won = (
                all(board[row][c] is player for c in range(3))
                or all(board[r][col] is player for r in range(3))
                or (
                    row == col
                    and all(board[i][i] is player for i in range(3))
                )
                or (
                    row + col == 2
                    and all(board[i][2 - i] is player for i in range(3))
                )
            )
            board[row][col] = None
            return won

        # Win immediately when possible, and prevent the opponent from doing so.
        for move in available:
            if would_win(move, True):
                return move
        for move in available:
            if would_win(move, False):
                return move

        if len(available) == 9:
            return (0, 0)

        if board[1][1] is None:
            return (1, 1)

        corners = ((0, 0), (0, 2), (2, 0), (2, 2))
        # Taking the corner opposite the opponent's first corner sets up the fork.
        own_corner = any(board[row][col] is True for row, col in corners)
        if not own_corner:
            for row, col in corners:
                opposite = (2 - row, 2 - col)
                if board[row][col] is False and board[opposite[0]][opposite[1]] is None:
                    return opposite

        # An edge is preferable to filling another corner: it supplies the fork.
        for move in ((0, 1), (2, 1), (1, 0), (1, 2)):
            if board[move[0]][move[1]] is None:
                return move

        return available[0]
