from typing import List, Literal, Optional, Union

# Input terminals.  ``e`` is not part of the input alphabet of the grammar: it
# is the empty string on the right-hand side of ``optexpr -> e``.  It is listed
# here because it is the leaf label the parser attaches to that empty
# production, and, as a convenience, it is also consumed if a caller spells the
# empty string out inside the parentheses of a ``for`` header.
Token = Literal["expr", ";", "if", "for", "(", ")", "other", "e"]
NonTerminal = Literal["stmt", "optexpr"]

EPSILON: Literal["e"] = "e"

Child = Union[str, "ParseTree"]


def _is_empty(node: Child) -> bool:
    """True for any spelling of an empty ``optexpr``.

    ``optexpr -> e`` consumes no terminal, so an empty optional expression is
    described equally well by a childless ``optexpr`` node, by an ``optexpr``
    node whose only leaf is the ``e`` marker, or by that bare marker on its
    own.  All three denote the same parse tree.
    """
    if isinstance(node, str):
        return node == EPSILON
    if node.nonterminal != "optexpr":
        return False
    return len(node.children) == 0 or (
        len(node.children) == 1 and node.children[0] == EPSILON
    )


def _key(node: Child):
    """Comparable, epsilon-normalised view of a leaf / subtree."""
    if _is_empty(node):
        return ("optexpr", ())
    if isinstance(node, ParseTree):
        return (node.nonterminal, tuple(_key(child) for child in node.children))
    return node


class ParseTree:
    def __init__(self, children, nonterminal: NonTerminal):
        self.children = children
        self.nonterminal = nonterminal

    def __eq__(self, obj) -> bool:
        if not isinstance(obj, ParseTree):
            return False
        if isinstance(obj, ParseTree) and obj.nonterminal != self.nonterminal:
            return False
        else:
            return _key(self) == _key(obj)

    def __repr__(self) -> str:
        return f"ParseTree({self.children!r}, {self.nonterminal!r})"


class Parser:
    """Recursive-descent parser for

        stmt    := expr ;
                 | if ( expr ) stmt
                 | for ( optexpr ; optexpr ; optexpr ) stmt
                 | other
        optexpr := expr
                 | e
    """

    Malformed = ValueError("input is not in the language accepted by this grammar")

    def __init__(self):
        self.inputs = []
        self.lookahead = 0

    def parse(self, inputs: List[Token]) -> ParseTree:
        self.inputs = list(inputs)
        self.lookahead = 0
        temp = self.stmt()
        if self.lookahead != len(self.inputs):
            raise Parser.Malformed
        else:
            return temp

    def peek(self) -> Optional[Token]:
        """Current input symbol, or ``None`` past the end of the input."""
        if self.lookahead >= len(self.inputs):
            return None
        return self.inputs[self.lookahead]

    def match(self, terminal: Token):
        if terminal == self.peek():
            self.lookahead += 1
        else:
            raise Parser.Malformed

    def stmt(self) -> ParseTree:
        current = self.peek()
        if current == "expr":
            self.match("expr")
            self.match(";")
            return ParseTree(["expr", ";"], "stmt")
        if current == "if":
            self.match("if")
            self.match("(")
            self.match("expr")
            self.match(")")
            return ParseTree(["if", "(", "expr", ")", self.stmt()], "stmt")
        if current == "for":
            self.match("for")
            self.match("(")
            init = self.optexpr()
            self.match(";")
            condition = self.optexpr()
            self.match(";")
            update = self.optexpr()
            self.match(")")
            body = self.stmt()
            return ParseTree(
                ["for", "(", init, ";", condition, ";", update, ")", body],
                "stmt",
            )
        if current == "other":
            self.match("other")
            return ParseTree(["other"], "stmt")
        raise Parser.Malformed

    def optexpr(self) -> ParseTree:
        """``optexpr := expr | e`` -- the empty branch consumes nothing.

        The first set of ``optexpr`` is ``{"expr"}`` and its follow set is
        ``{";", ")"}``, so the two alternatives are separated by a single token
        of lookahead: take ``optexpr -> expr`` on ``expr`` and reduce
        ``optexpr -> e`` otherwise (the ``;`` / ``)`` is then matched by
        :meth:`stmt`).
        """
        if self.peek() == "expr":
            self.match("expr")
            return ParseTree(["expr"], "optexpr")
        if self.peek() == EPSILON:
            # The empty string spelled out in the input: it contributes no
            # terminal to the sentence, only the marker for the branch.
            self.match(EPSILON)
        return ParseTree([EPSILON], "optexpr")
