import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    vowels = "aeiouy"
    words = line.split()
    for previous, following in zip(words, words[1:]):
        starts_with_vowel = following[0] in vowels
        has_combo = (
            previous[-1] in vowels and starts_with_vowel
        )
        has_combo = has_combo or (
            len(previous) >= 2
            and previous[-2] in vowels
            and previous[-1] in "mh"
            and starts_with_vowel
        )
        has_combo = has_combo or (
            len(previous) >= 2
            and previous[-2] in vowels
            and previous[-1] == "m"
            and len(following) >= 2
            and following[0] == "h"
            and following[1] in vowels
        )
        if has_combo:
            syllable_count += 1

    return syllable_count
