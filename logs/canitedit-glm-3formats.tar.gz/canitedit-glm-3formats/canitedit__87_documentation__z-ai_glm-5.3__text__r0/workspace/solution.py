import ast

from typing import Tuple


def _format_annotation(node: ast.expr) -> str:
    """Render an annotation node as source text, e.g. ``int`` or ``List[int]``."""
    if isinstance(node, ast.Name):
        return node.id
    if hasattr(ast, "unparse"):  # Python 3.9+
        return ast.unparse(node)
    if isinstance(node, ast.Attribute):
        return f"{_format_annotation(node.value)}.{node.attr}"
    return ast.dump(node)


def build_documentation(code: str) -> Tuple[str, str]:
    results = []
    parsed_ast = ast.parse(code)
    def visit_FunctionDef(node: ast.FunctionDef) -> None:
        name = node.name
        args_node = node.args
        return_annotation = node.returns
        if return_annotation is None:
            return_annotation = "None"
        else:
            return_annotation = _format_annotation(return_annotation)
        args = []
        for arg in args_node.args:
            label = arg.arg
            if arg.annotation is not None:
                label += f": {_format_annotation(arg.annotation)}"
            args.append(label)
        function_signature = f"{name}({', '.join(args)}): {return_annotation}"
        docstring = ast.get_docstring(node)
        if docstring is None:
            docstring = ""
        results.append((function_signature, docstring))
    for node in ast.walk(parsed_ast):
        if isinstance(node, ast.FunctionDef):
            visit_FunctionDef(node)
    
    return results
