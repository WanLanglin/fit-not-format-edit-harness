"""Schnorr identification protocol made non-interactive (Fiat-Shamir).

The interactive protocol needed the verifier to send a fresh random challenge.
Here the challenge is derived by hashing the prover's commitment together with
the public key and the group prime using SHA-256, so the prover can emit a
complete proof in a single message while the challenge stays unpredictable and
is cryptographically bound to that exact transcript (t, y, p).
"""

import hashlib
from typing import Tuple


def keygen(p: int, g: int, x: int) -> Tuple[Tuple[int, int, int], int]:
    """generate public and private key with given prime (p), base (g), and private key (x)."""
    y = pow(g, x, p)  # public key
    return (p, g, y), x


def prover_commitment(p: int, g: int, r: int) -> Tuple[int, int]:
    """step 1: Prover sends a commitment with given random value (r)."""
    t = pow(g, r, p)
    return t, r


def _encode_int(value: int) -> bytes:
    """Canonical big-endian encoding of an integer, prefixed by its byte length.

    The length prefix keeps the hash input unambiguous (no boundary/shifting
    collisions between the encoded fields), so every argument is truly bound.
    """
    value = int(value)
    magnitude = abs(value)
    length = (magnitude.bit_length() + 7) // 8
    sign = (1 if value < 0 else 0).to_bytes(1, "big")
    return sign + length.to_bytes(8, "big") + magnitude.to_bytes(length, "big")


def hash_to_challenge(t: int, y: int, p: int) -> int:
    """step 2 (non-interactive): derive the challenge from the transcript.

    The challenge is SHA-256 over *all* public transcript values: the prover
    commitment (t), the public key (y) and the prime (p). Hashing t || y || p
    (with a domain-separation tag and length-prefixed fields) replaces the
    verifier's random message, keeps the challenge unpredictable so the proof is
    non-malleable, and stops a challenge from being replayed under a different
    key or modulus.
    """
    digest = hashlib.sha256()
    digest.update(b"SCHNORR-NI-ZK-FIAT-SHAMIR-V1|")
    for value in (t, y, p):
        digest.update(_encode_int(value))
    c = int.from_bytes(digest.digest(), "big")
    # fold the 256-bit digest into the exponent range [1, p-2]: never 0 (a prover
    # could otherwise win by skipping the response) and never p-1 or more
    span = p - 2 if p > 3 else 1
    return c % span + 1


def prover_response(r: int, c: int, x: int, p: int) -> int:
    """step 3: Prover sends a response."""
    s = (r + c * x) % (p - 1)
    return s


def verifier_check(p: int, g: int, y: int, t: int, c: int, s: int) -> bool:
    """verifier checks the prover's response."""
    return pow(g, s, p) == (t * pow(y, c, p)) % p


def schnorr_protocol(
    p: int, g: int, x: int, r: int, c: int = None, bits: int = 256
) -> bool:
    """demonstrate the non-interactive Schnorr protocol with given values.

    The proof is emitted as a single message (t, c, s): the challenge is derived
    with `hash_to_challenge(t, y, p)` instead of being sent by a verifier, so no
    interaction and no verifier randomness is involved. `c` is accepted only for
    backward compatibility with the old interactive call signature and is always
    overwritten - the challenge must be bound to the transcript. `bits` is the
    intended challenge security level (informational: the SHA-256 Fiat-Shamir
    digest provides up to 256 bits).
    """
    # key generation
    params, x = keygen(p, g, x)
    p, g, y = params

    # step 1: Commitment
    t, r = prover_commitment(p, g, r)

    # step 2: Challenge - derived non-interactively from the transcript (t, y, p)
    c = hash_to_challenge(t, y, p)

    # step 3: Response
    s = prover_response(r, c, x, p)

    # Verification of the non-interactive proof (t, s): the challenge is not
    # trusted input, it is re-derived here from the transcript (t, y, p).
    c_verify = hash_to_challenge(t, y, p)
    return verifier_check(p, g, y, t, c_verify, s)
