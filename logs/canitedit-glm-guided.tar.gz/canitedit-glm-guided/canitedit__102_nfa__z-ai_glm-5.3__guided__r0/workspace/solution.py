from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic finite automaton for the language {"a" + "b" * n | n >= 0}.

    Equivalent to the original NFA, which accepted exactly the strings made of
    a single "a" followed by any number of "b"s.

    State 0 is the start state, state 1 is the (only) accepting state, reached
    after reading "a" and kept by further "b"s, and state 2 is the dead state
    that traps every rejected continuation.  The "" entry keeps the current
    state, matching the NFA's epsilon transitions, which were all self-loops.
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self) -> bool:
        return self.current in self.accept
