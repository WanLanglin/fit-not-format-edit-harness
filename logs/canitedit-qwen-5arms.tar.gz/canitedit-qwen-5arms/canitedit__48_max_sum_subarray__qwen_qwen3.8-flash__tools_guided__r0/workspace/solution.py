from typing import List, Tuple


def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Return (max_sum, srt_idx, end_idx) for the maximum-sum subarray.

    Indices are inclusive. Ties are broken by the earliest subarray found.
    """
    if not lst:
        raise ValueError("lst must contain at least one element")

    max_so_far = lst[0]
    curr_max = lst[0]
    srt_idx = 0
    end_idx = 0
    temp_srt = 0
    for i in range(1, len(lst)):
        if curr_max + lst[i] < lst[i]:
            curr_max = lst[i]
            temp_srt = i
        else:
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            srt_idx = temp_srt
            end_idx = i
    return max_so_far, srt_idx, end_idx
