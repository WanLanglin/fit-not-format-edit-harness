from solution import Node, Edge, Graph

a, b, c, d, e = [Node(i) for i in range(5)]
g = Graph([a, b, c, d, e])
g.add_edge(Edge(a, b, 1))
g.add_edge(Edge(b, c, 2))
g.add_edge(Edge(a, c, 5))
g.add_edge(Edge(c, d, 1))
dist = g.fibonacci(a)
assert len(dist) == 5, dist
assert dist[a] == 0
assert dist[b] == 1
assert dist[c] == 3, dist[c]
assert dist[d] == 4
assert dist[e] is None
assert dist[Node(0)] == 0  # equality by id

# unreachable-only graph, start from isolated node
dist_d = g.fibonacci(d)
assert all(v is None for k, v in dist_d.items() if k != d), dist_d
assert dist_d[d] == 0

# cycle handling
x, y, z = Node(10), Node(11), Node(12)
g2 = Graph([x, y, z])
g2.add_edge(Edge(x, y, 3))
g2.add_edge(Edge(y, z, 1))
g2.add_edge(Edge(z, x, 1))
r = g2.fibonacci(x)
assert r[x] == 0 and r[y] == 3 and r[z] == 4, r

# out_edges-only wiring (edges attached to nodes but not in Graph.edges)
p, q = Node(20), Node(21)
g3 = Graph([p, q])
e_pq = Edge(p, q, 7)
p.out_edges.append(e_pq)
q.in_edges.append(e_pq)
r3 = g3.fibonacci(p)
assert r3[q] == 7, r3

print("all checks passed")
