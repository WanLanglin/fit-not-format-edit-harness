import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def _is_vowel(c):
    return c in "aeiouy"

def combo_count(line):
    combo_count = 0
    words = line.split(" ")
    for i in range(len(words) - 1):
        a = words[i]
        b = words[i + 1]

        # end of word a: a vowel, or a vowel followed by 'm'
        end_ok = False
        if len(a) >= 1 and _is_vowel(a[-1]):
            end_ok = True
        elif len(a) >= 2 and _is_vowel(a[-2]) and a[-1] == 'm':
            end_ok = True

        # start of word b: a vowel, or 'h' followed by a vowel
        start_ok = False
        if len(b) >= 1 and _is_vowel(b[0]):
            start_ok = True
        elif len(b) >= 2 and b[0] == 'h' and _is_vowel(b[1]):
            start_ok = True

        if end_ok and start_ok:
            combo_count += 1
    return combo_count

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if _is_vowel(c):
            vowel_count += 1
    return vowel_count - 2 * combo_count(line)

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count += combo_count(line)

    return syllable_count
