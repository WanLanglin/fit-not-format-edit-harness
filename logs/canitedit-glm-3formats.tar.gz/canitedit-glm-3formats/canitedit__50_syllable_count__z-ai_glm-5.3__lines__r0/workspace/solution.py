import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def combo_count(line):
    """Return the number of 'combo' in line.

    A combo joins two words separated by a single space when the first word
    ends with a vowel or with a vowel followed by 'm', and the second word
    begins with a vowel or with 'h' followed by a vowel.
    """
    vowels = "aeiouy"
    words = [word for word in line.split(" ") if word]

    combos = 0
    for first, second in zip(words, words[1:]):
        first_ends = first[-1] in vowels or (
            len(first) > 1 and first[-1] == "m" and first[-2] in vowels
        )
        second_begins = second[0] in vowels or (
            len(second) > 1 and second[0] == "h" and second[1] in vowels
        )
        if first_ends and second_begins:
            combos += 1

    return combos

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    # Every 'combo' makes two adjacent vowels count as a single syllable,
    # so one syllable is lost for each combo.
    syllable_count -= combo_count(line)

    return syllable_count
