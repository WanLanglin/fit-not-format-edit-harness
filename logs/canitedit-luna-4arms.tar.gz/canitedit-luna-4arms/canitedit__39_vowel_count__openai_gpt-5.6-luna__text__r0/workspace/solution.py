import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    vowels = 0
    diphthongs = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]
    line = prepare_line(line)
    position = 0

    while position < len(line):
        diphthong = next(
            (diphthong for diphthong in diphthongs if line.startswith(diphthong, position)),
            None,
        )
        if diphthong:
            vowels += 1
            position += len(diphthong)
        else:
            if line[position] in "aeiouy":
                vowels += 1
            position += 1

    return vowels
