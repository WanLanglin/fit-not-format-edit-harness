from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        stack: List[float] = []

        for token in inputs:
            if token in ("+", "-", "*", "/"):
                if len(stack) < 2:
                    raise Exception("Malformed postfix expression")

                right = stack.pop()
                left = stack.pop()
                match token:
                    case "+":
                        stack.append(left + right)
                    case "-":
                        stack.append(left - right)
                    case "*":
                        stack.append(left * right)
                    case "/":
                        stack.append(left / right)
            elif isinstance(token, (int, float)) and not isinstance(token, bool):
                stack.append(token)
            else:
                raise Exception("Malformed postfix expression")

        if len(stack) != 1:
            raise Exception("Malformed postfix expression")

        return stack[0]
