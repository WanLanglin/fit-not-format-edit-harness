import heapq
from typing import Dict, List, Optional


class Node:
    '''Simple node (No duplicate edges between nodes)'''

    def __init__(self, id: int):
        self.id = id
        self.out_edges = []
        self.in_edges = []

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Node):
            return False
        else:
            return self.id == __value.id

    def __hash__(self) -> int:
        return self.id


class Edge:
    def __init__(self, src: Node, dest: Node, weight: int):
        assert weight > 0

        self.src = src
        self.dest = dest
        self.weight = weight

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Edge):
            return False
        else:
            return self.dest == __value.dest and self.src == __value.src


class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''

    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques.keys():
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        self.edges = []

    def add_edge(self, edge: Edge):
        assert edge not in self.edges
        self.edges.append(edge)

    def fibonacci(self, x: Node) -> Dict[Node, Optional[int]]:
        '''Shortest path distance from x to every node in the graph.

        Returns a dictionary containing every node in self.nodes.  Each value
        is the smallest total weight of the edges of any path from x to that
        node, or None when no such path exists.
        '''
        # Every node starts out unreachable; x itself is at distance 0.
        distances: Dict[Node, Optional[int]] = {node: None for node in self.nodes}

        # Gather the outgoing edges of every node.  Edges may be recorded on
        # the graph itself and/or directly on the nodes, so both are combined.
        adjacency: Dict[Node, List[Edge]] = {node: list(node.out_edges) for node in self.nodes}
        for edge in self.edges:
            outgoing = adjacency.setdefault(edge.src, [])
            if edge not in outgoing:
                outgoing.append(edge)

        # Dijkstra's algorithm (all weights are positive).  Heap entries are
        # (distance, tie breaker, node) so Node objects are never compared.
        tentative: Dict[Node, int] = {x: 0}
        tie_breaker = 0
        heap = [(0, tie_breaker, x)]
        while heap:
            distance, _, node = heapq.heappop(heap)
            if distance > tentative.get(node, distance):
                continue  # A shorter path to this node was already found.
            for edge in adjacency.get(node, []):
                candidate = distance + edge.weight
                if edge.dest not in tentative or candidate < tentative[edge.dest]:
                    tentative[edge.dest] = candidate
                    tie_breaker += 1
                    heapq.heappush(heap, (candidate, tie_breaker, edge.dest))

        for node, distance in tentative.items():
            if node in distances:
                distances[node] = distance

        return distances
