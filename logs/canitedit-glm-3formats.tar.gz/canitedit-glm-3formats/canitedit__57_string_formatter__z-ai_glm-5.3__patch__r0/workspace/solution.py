def concatenate_nums(message):
    # The subject, verb and object can each consist of several words, and in
    # the examples the three parts are separated by a double space
    # (e.g. "the cat  chased  the mouse"). Splitting on that separator keeps
    # each part intact so it can be moved as a whole. When the parts are
    # separated by single spaces only, a single space is used instead.
    separator = "  " if "  " in message else " "

    parts = message.split(separator)
    parts.reverse()
    return separator.join(parts)


def format_string(name1, name2, message):
    reordered_message = concatenate_nums(message)
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {reordered_message}'
    return formattedString
