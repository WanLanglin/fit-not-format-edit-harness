from typing import List

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Order the nodes so every node appears before the nodes it points to.

        Uses Kahn's algorithm and raises RuntimeError if the graph contains a cycle.
        '''
        by_id = {}
        for node in self.nodes:
            by_id[node.id] = node

        adjacency = {node.id: [] for node in self.nodes}
        in_degree = {node.id: 0 for node in self.nodes}
        for node in self.nodes:
            for target in node.out_edges:
                if target not in by_id:
                    # edge to a node that is not part of this graph
                    continue
                adjacency[node.id].append(target)
                in_degree[target] += 1

        queue = [node.id for node in self.nodes if in_degree[node.id] == 0]
        ordered_ids: List[int] = []
        head = 0
        while head < len(queue):
            current = queue[head]
            head += 1
            ordered_ids.append(current)
            for target in adjacency[current]:
                in_degree[target] -= 1
                if in_degree[target] == 0:
                    queue.append(target)

        if len(ordered_ids) != len(self.nodes):
            raise RuntimeError('Graph is not acyclic, so it cannot be sorted topologically')

        return [by_id[node_id] for node_id in ordered_ids]
