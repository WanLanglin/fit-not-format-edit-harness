def minLength(password):
    assert type(password) == str
    return len(password) >= 8

SPECIAL_CHARS = "!@#$%^&*()-_=+[]{};:'\",.<>/?\\|`~"


def containsSpecialChar(password):
    for character in password:
        if character in SPECIAL_CHARS:
            return True
    return False


def isPasswordStrong(password):
    return minLength(password) and containsSpecialChar(password)
