# Copyright (c), Ansible Project
# Simplified BSD License (see licenses/simplified_bsd.txt or https://opensource.org/licenses/BSD-2-Clause)

from __future__ import annotations

import platform
import sys

from ansible.module_utils.common.parameters import remove_values
from ansible.module_utils.common.text.converters import to_native


def heuristic_log_sanitize(data, no_log_values=None):
    ''' Remove strings that look like passwords from log messages '''
    data = to_native(data)
    output = []
    begin = len(data)
    prev_begin = begin
    sep = 1
    while sep:
        try:
            end = data.rindex('@', 0, begin)
        except ValueError:
            output.insert(0, data[0:begin])
            break
        sep = None
        sep_search_end = end
        while not sep:
            try:
                begin = data.rindex('://', 0, sep_search_end)
            except ValueError:
                begin = 0
            try:
                sep = data.index(':', begin + 3, end)
            except ValueError:
                if begin == 0:
                    output.insert(0, data[0:prev_begin])
                    break
                sep_search_end = begin
                continue
        if sep:
            output.insert(0, data[end:prev_begin])
            output.insert(0, '********')
            output.insert(0, data[begin:sep + 1])
            prev_begin = begin
    output = ''.join(output)
    if no_log_values:
        output = remove_values(output, no_log_values)
    return output


def missing_required_lib(library, reason=None, url=None):
    hostname = platform.node()
    msg = "Failed to import the required Python library (%s) on %s's Python %s." % (library, hostname, sys.executable)
    if reason:
        msg += " This is required %s." % reason
    if url:
        msg += " See %s for more info." % url
    msg += (" Please read the module documentation and install it in the appropriate location."
            " If the required library is installed, but Ansible is using the wrong Python interpreter,"
            " please consult the documentation on ansible_python_interpreter")
    return msg
