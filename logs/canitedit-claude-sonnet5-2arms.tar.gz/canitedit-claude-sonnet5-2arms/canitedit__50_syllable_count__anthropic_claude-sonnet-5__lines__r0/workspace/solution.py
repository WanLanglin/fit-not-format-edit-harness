import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def combo_count(line):
    vowels = "aeiouy"
    words = line.split()
    count = 0
    for i in range(len(words) - 1):
        w1, w2 = words[i], words[i + 1]
        if not w1 or not w2:
            continue
        last = w1[-1]
        ends_vowel = last in vowels
        ends_vowel_m = len(w1) >= 2 and last == 'm' and w1[-2] in vowels
        starts_vowel = w2[0] in vowels
        starts_h_vowel = len(w2) >= 2 and w2[0] == 'h' and w2[1] in vowels
        if (ends_vowel or ends_vowel_m) and (starts_vowel or starts_h_vowel):
            count += 1
    return count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
