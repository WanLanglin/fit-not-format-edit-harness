import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

DIPHTHONGS = ("aea", "ae", "oe", "ei", "ea", "ia", "io")


def vowel_count(line):
    line = prepare_line(line)
    count = 0
    index = 0
    while index < len(line):
        diphthong = next(
            (value for value in DIPHTHONGS if line.startswith(value, index)),
            None,
        )
        if diphthong is not None:
            index += len(diphthong)
        else:
            if line[index] in "aeiouy":
                count += 1
            index += 1
    return count
