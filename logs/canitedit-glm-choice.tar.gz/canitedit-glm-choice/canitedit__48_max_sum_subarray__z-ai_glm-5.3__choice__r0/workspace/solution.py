from typing import List, Tuple

def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Return (max_sum, start_idx, end_idx) of the maximum subarray.

    Indices are inclusive. Uses Kadane's algorithm while tracking the
    start of the current candidate subarray.
    """
    max_so_far = lst[0]
    curr_max = lst[0]
    start = 0
    end = 0
    curr_start = 0
    for i in range(1, len(lst)):
        if lst[i] > curr_max + lst[i]:
            # Starting a new subarray at i is better than extending.
            curr_max = lst[i]
            curr_start = i
        else:
            # Extend the current subarray.
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            start = curr_start
            end = i
    return (max_so_far, start, end)
