from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception
        
class GoodStrategy(Strategy):
    '''A strategy that beats CornerStrategy when it moves first.

    On the board, True marks belong to player 1 (this strategy, when the game
    is created as Game(GoodStrategy(), ...)), False marks belong to player 2
    and None marks an empty square.

    CornerStrategy only ever claims corners, and the only lines made up
    entirely of corners are the two diagonals, both of which run through the
    centre.  Claiming the centre on the first move therefore leaves
    CornerStrategy without any line it can ever complete, while the centre
    plus the two edge squares of a middle row or column, squares a corner
    only opponent never claims, gives this strategy a winning line.
    '''

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        # Win immediately if that is possible.
        move = self._completingMove(board, True)
        if move is not None:
            return move

        # Otherwise make sure the opponent cannot win with their next move.
        move = self._completingMove(board, False)
        if move is not None:
            return move

        # The centre blocks both diagonals and lies on four different lines.
        if board[1][1] is None:
            return (1, 1)

        # Build a line through the centre out of edge squares.
        for edge in ((1, 0), (0, 1), (1, 2), (2, 1)):
            if board[edge[0]][edge[1]] is None:
                return edge

        # Otherwise take any square that is still free.
        for row in range(3):
            for col in range(3):
                if board[row][col] is None:
                    return (row, col)
        raise Exception

    def _completingMove(self, board: List[List[bool]], player: bool):
        '''Returns the empty square that completes a line for player, else None.'''
        for line in self._lines():
            marks = [board[row][col] for row, col in line]
            if marks.count(player) == 2 and marks.count(None) == 1:
                return line[marks.index(None)]
        return None

    def _lines(self):
        '''Returns every line of three squares on the board.'''
        lines = [[(row, col) for col in range(3)] for row in range(3)]
        lines += [[(row, col) for row in range(3)] for col in range(3)]
        lines.append([(0, 0), (1, 1), (2, 2)])
        lines.append([(2, 0), (1, 1), (0, 2)])
        return lines


class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True
