import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    vowels = "aeiouy"
    words = line.split()
    combos = 0

    for i in range(len(words) - 1):
        word1 = words[i]
        word2 = words[i + 1]

        # Determine if word2 "starts with a vowel" (directly or after leading 'h')
        w2_starts_vowel = False
        if word2 and word2[0] in vowels:
            w2_starts_vowel = True
        elif len(word2) >= 2 and word2[0] == 'h' and word2[1] in vowels:
            w2_starts_vowel = True

        if not w2_starts_vowel or not word1:
            continue

        # Rule 1: word1 ends with a vowel
        if word1[-1] in vowels:
            combos += 1
        # Rule 2/4: word1 ends with vowel + 'm'
        elif len(word1) >= 2 and word1[-1] == 'm' and word1[-2] in vowels:
            combos += 1
        # Rule 3: word1 ends with vowel + 'h'
        elif len(word1) >= 2 and word1[-1] == 'h' and word1[-2] in vowels:
            combos += 1

    syllable_count -= combos

    return syllable_count
