import re


def concatenate_nums(message):
    """Return ``message`` rearranged from subject-verb-object to object-verb-subject order.

    ``message`` is assumed to consist of a subject, a verb and an object.  The
    spacing of the original message is kept, so for example
    ``"the cat  chased  the mouse"`` becomes ``"the mouse  chased  the cat"``.
    """
    # A run of two or more spaces separates the subject, the verb and the
    # object ("the cat  chased  the mouse").  Remember the separators so that
    # the rearranged message keeps the original spacing.
    pieces = re.split(r'( {2,})', message)
    parts = [piece.strip() for piece in pieces if piece.strip()]
    separators = [piece for piece in pieces if piece and not piece.strip()]

    if len(parts) == 3 and len(separators) == 2:
        subject, verb, obj = parts
        return obj + separators[1] + verb + separators[0] + subject

    # Otherwise the subject, the verb and the object are single words that
    # are separated by a single space ("cat chased mouse").
    words = message.strip().split(' ')
    if len(words) == 3 and all(words):
        subject, verb, obj = words
        return obj + ' ' + verb + ' ' + subject

    # The message is not made up of a subject, a verb and an object; leave it
    # unchanged.
    return message


def format_string(name1, name2, message):
    reordered = concatenate_nums(message)
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {reordered}'
    return formattedString
