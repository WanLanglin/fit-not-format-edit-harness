class Probability:

    def sample_mean(self, X):
        """Computes the sample mean of the data"""
        return sum(X) / len(X)

    def variance(self, X):
        """Computes the variance of the data"""
        mean = sum(X) / len(X)
        return sum((x - mean) ** 2 for x in X) / len(X)

    def covariance(self, correlation, var_x, var_y):
        """Computes covariance from correlation and the variances of X and Y."""
        return correlation * (var_x ** 0.5) * (var_y ** 0.5)
