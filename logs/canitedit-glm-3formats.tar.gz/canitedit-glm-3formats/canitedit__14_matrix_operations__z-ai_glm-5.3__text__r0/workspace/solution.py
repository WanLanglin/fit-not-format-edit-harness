def same_size(matrix1, matrix2) -> bool:
    """Return True if the two matrices have the same dimensions."""
    m1 = matrix1.matrix if isinstance(matrix1, Matrix) else matrix1
    m2 = matrix2.matrix if isinstance(matrix2, Matrix) else matrix2

    if len(m1) != len(m2):
        return False
    return all(len(r1) == len(r2) for r1, r2 in zip(m1, m2))


class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def add(self, other):
        if not same_size(self.matrix, other.matrix):
            raise ValueError("Matrices must have the same dimensions to be added")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)
    
    def subtract(self, other):
        if not same_size(self.matrix, other.matrix):
            raise ValueError("Matrices must have the same dimensions to be subtracted")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)
