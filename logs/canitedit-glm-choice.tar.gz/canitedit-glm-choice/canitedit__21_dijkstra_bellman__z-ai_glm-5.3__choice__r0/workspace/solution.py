class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.

        Negative edge weights are supported. A ValueError is raised when the
        graph contains a negative cycle, because in that case at least one
        node has no well-defined shortest distance.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        edges = self._all_edges()

        if self._has_negative_cycle(edges):
            raise ValueError('Graph contains a negative cycle')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        self._relax_edges(edges, shortest_path, len(self.nodes) - 1)

        return shortest_path

    def _all_edges(self):
        """Returns every edge in the graph as a (from_node, to_node, weight) tuple."""
        return [
            (node, neighbor, weight)
            for node in self.nodes
            for neighbor, weight in self.edges.get(node, [])
            if neighbor in self.nodes
        ]

    def _relax_edges(self, edges, distances, passes):
        """Relaxes every edge, repeating for up to `passes` rounds, in place."""
        for _ in range(passes):
            updated = False

            for from_node, to_node, weight in edges:
                if distances[from_node] == float('infinity'):
                    continue

                distance = distances[from_node] + weight

                if distance < distances[to_node]:
                    distances[to_node] = distance
                    updated = True

            if not updated:
                break

    def _has_negative_cycle(self, edges):
        """
        Detects negative cycles anywhere in the graph (Bellman-Ford).

        Every node is given an initial distance of zero, which behaves like a
        virtual source connected to all of them. That way negative cycles are
        detected even when they cannot be reached from the start node.
        """
        distances = {node: 0 for node in self.nodes}
        self._relax_edges(edges, distances, len(self.nodes) - 1)

        return any(
            distances[from_node] + weight < distances[to_node]
            for from_node, to_node, weight in edges
        )
