import solution


def check(line, expected):
    actual = solution.vowel_count(line)
    print(f"{line!r} -> {actual} (expected {expected})")
    assert actual == expected, line


# Examples given in the task.
check("adspirate meis primaque ab origine mundi", 15)
check("in nova fert animus mutatas dicere formas", 15)

# Overlapping case: "aea" is matched as one diphthong, leaving the final "e".
check("taeae", 1)  # t + aea + e
check("aeaea", 0)  # aea + ea
check("gaea", 0)  # g + aea

# Adjacent vowel pairs that ARE diphthongs are skipped greedily.
check("aeiou", 1)  # ae + io + u
check("coordinator", 5)  # c o o r d i n a t o r -> o,o,i,a,o

# A diphthong with a consonant before/after is still skipped.
check("meis", 0)  # m + ei + s
check("deinde", 1)  # d + ei + nd + e -> only the final "e"
check("foedus", 1)  # f + oe + d + u + s -> only "u"
check("aurea", 2)  # a + u + r + ea -> a, u
check("audio", 2)  # a + u + d + io -> a, u
check("copia", 1)  # c + o + p + ia -> only "o"

# Empty/punctuation/digits behave as before.
check("", 0)
check("a, e. i! o? u; 12345", 5)

# Case sensitivity is unchanged: only lowercase vowels are counted.
check("AEIOU", 0)

print("all assertions passed")
