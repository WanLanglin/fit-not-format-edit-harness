def dnaToRna(base):
    if base == "T":
        return "A"
    elif base == "A":
        return "U"
    elif base == "C":
        return "G"
    elif base == "G":
        return "C"

def transcribe(dna):
    rna = ""
    for base in dna:
        rna += dnaToRna(base)
    return rna
