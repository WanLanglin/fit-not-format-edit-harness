from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """Parse a sequence of input tokens using postfix notation."""
        sequence: List[Token | float] = list(inputs)

        while True:
            operator_index = next(
                (index for index, token in enumerate(sequence) if token in {"+", "-", "*", "/"}),
                None,
            )
            if operator_index is None:
                break
            if operator_index < 2:
                raise Exception("Malformed postfix expression")

            left, right = sequence[operator_index - 2 : operator_index]
            operator = sequence[operator_index]
            if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
                raise Exception("Malformed postfix expression")

            if operator == "+":
                result = left + right
            elif operator == "-":
                result = left - right
            elif operator == "*":
                result = left * right
            else:
                result = left / right

            sequence[operator_index - 2 : operator_index + 1] = [result]

        if len(sequence) != 1 or not isinstance(sequence[0], (int, float)):
            raise Exception("Malformed postfix expression")
        return float(sequence[0])
