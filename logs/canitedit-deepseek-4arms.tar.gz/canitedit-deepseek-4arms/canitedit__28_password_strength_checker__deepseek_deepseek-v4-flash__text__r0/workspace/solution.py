def minLength(password):
    assert type(password) == str
    return len(password) >= 8

def containsSpecialChar(password):
    special_chars = "!@#$%^&*()_+-=[]{};':\",./<>?"
    for ch in password:
        if ch in special_chars:
            return True
    return False

def isPasswordStrong(password):
    return minLength(password) and containsSpecialChar(password)
