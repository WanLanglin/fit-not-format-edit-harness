import ast


class UsageCounter(ast.NodeVisitor):
    """
    Counts the usages of each identifier in the given AST.
    An usage does not count the definition or assignment itself;
    only identifiers that are used after their definition/assignment are counted.
    NOTE: This class does not handle the scoping rules of Python;
    it simply counts the usages based on the name of the identifiers.
    It also only supports identifiers defined in either a function or assignment operation.
    """

    def __init__(self):
        self.usages = {}

    def visit_Name(self, node):
        if node.id in self.usages:
            self.usages[node.id] += 1
            self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name not in self.usages:
            self.usages[node.name] = 0

        # Function arguments are definitions, just like assignment targets.
        arguments = (
            node.args.posonlyargs
            + node.args.args
            + node.args.kwonlyargs
        )
        if node.args.vararg is not None:
            arguments.append(node.args.vararg)
        if node.args.kwarg is not None:
            arguments.append(node.args.kwarg)
        for argument in arguments:
            if argument.arg not in self.usages:
                self.usages[argument.arg] = 0

        self.generic_visit(node)

    def _defined_names(self, target):
        """Return all names defined by an assignment target."""
        if isinstance(target, ast.Name):
            return [target.id]
        if isinstance(target, (ast.Tuple, ast.List)):
            names = []
            for element in target.elts:
                names.extend(self._defined_names(element))
            return names
        if isinstance(target, ast.Starred):
            return self._defined_names(target.value)
        return []

    def visit_Assign(self, node):
        defined_names = []
        for target in node.targets:
            for name in self._defined_names(target):
                if name not in self.usages:
                    self.usages[name] = 0
                defined_names.append(name)

        self.generic_visit(node)
        # generic_visit includes the target names; remove those definitions
        # from the usage count.  This also handles tuple unpacking and chained
        # assignments, where there may be more than one target name.
        for name in defined_names:
            self.usages[name] -= 1
