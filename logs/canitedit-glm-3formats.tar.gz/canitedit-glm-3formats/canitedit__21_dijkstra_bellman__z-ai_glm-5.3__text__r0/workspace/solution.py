class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.
        Supports negative weights; raises ValueError if the graph contains a
        negative cycle.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        if self._has_negative_cycle():
            raise ValueError('Graph contains a negative cycle')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Bellman-Ford: relax every edge once per round, for at most
        # len(self.nodes) - 1 rounds (the longest simple path).
        for _ in range(len(self.nodes) - 1):
            updated = False
            for node in self.nodes:
                if shortest_path[node] == float('infinity'):
                    continue
                for neighbor, weight in self.edges[node]:
                    distance = shortest_path[node] + weight
                    if distance < shortest_path[neighbor]:
                        shortest_path[neighbor] = distance
                        updated = True
            if not updated:
                break

        return shortest_path

    def _has_negative_cycle(self):
        """
        Detects a negative cycle anywhere in the graph with Bellman-Ford.

        Every node starts at distance 0, which is equivalent to running
        Bellman-Ford from a virtual source connected to every node by a
        zero-weight edge, so every part of the graph is checked.
        """
        distances = {node: 0 for node in self.nodes}

        # A shortest path visits at most len(self.nodes) edges from the virtual
        # source, so any improvement during the last round implies a negative
        # cycle. A negative cycle keeps improving forever, so it can never be
        # settled by an early exit.
        for _ in range(len(self.nodes)):
            updated = False
            for node in self.nodes:
                for neighbor, weight in self.edges[node]:
                    distance = distances[node] + weight
                    if distance < distances[neighbor]:
                        distances[neighbor] = distance
                        updated = True
            if not updated:
                return False

        return True
