from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic finite automaton equivalent to the previous NFA.

    The NFA accepted exactly ``a b*`` (an ``a`` followed by zero or more ``b``s):
    reading ``a`` in state 0 reached ``{1, 2}``, state 2 looped on ``b`` and every
    epsilon move was a reflexive self loop, so the reachable subsets ``{1, 2}`` and
    ``{2}`` merge into one accepting state.  Since every epsilon move is the identity,
    the empty input leaves this DFA in its current state, preserving the language.

    States:
      0 - start; no useful prefix seen yet (rejecting)
      1 - an ``a`` followed by only ``b``s has been read (accepting)
      2 - absorbing trap; no continuation can ever be accepted (rejecting)
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self) -> bool:
        return self.current in self.accept
