import sys
from solution import merge_sort

COUNTS = {"copies": 0, "calls": 0, "merges": 0}

orig_lt = int.__lt__


class Counting:
    def __init__(self, v):
        self.v = v
        COUNTS["calls"] += 1

    def __lt__(self, other):
        return self.v < other.v


class Verifier:
    def __lt__(self, other):
        return self.v < other.v


def compare_cost(n, seq):
    """Count element copies + merge steps for a given input."""
    COUNTS.update(copies=0, calls=0, merges=0)

    class Tracked:
        __slots__ = ("v",)

        def __init__(self, v):
            self.v = v

        def __lt__(self, other):
            return self.v < other.v

    # Instrument by wrapping the list in a subclass that counts __setitem__.
    class TrackedList(list):
        def __setitem__(self, i, v):
            COUNTS["copies"] += 1
            super().__setitem__(i, v)

    lst = TrackedList(seq)
    merge_sort(lst)
    assert is_sorted(list(lst)), seq
    return COUNTS["copies"]


def is_sorted(a):
    return all(a[i] <= a[i + 1] for i in range(len(a) - 1))


def test_optimization_actually_saves_work():
    n = 256
    sorted_seq = list(range(n))
    reversed_seq = list(range(n, 0, -1))
    # Sorted input: at most the slice copies; no merge writes back into lst.
    c_sorted = compare_cost(n, sorted_seq)
    c_reverse = compare_cost(n, reversed_seq)
    print("\ncopies sorted=", c_sorted, " copies reversed=", c_reverse, file=sys.stderr)
    assert c_sorted < 4, c_sorted
    assert c_reverse > c_sorted, (c_sorted, c_reverse)


if __name__ == "__main__":
    test_optimization_actually_saves_work()
    print("ok")
