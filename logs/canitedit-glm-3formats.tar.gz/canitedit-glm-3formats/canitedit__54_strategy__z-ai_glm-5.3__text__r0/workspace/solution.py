from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception
        
class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True


# Every way three squares form a line on a 3x3 board.
LINES = (
    ((0, 0), (0, 1), (0, 2)),
    ((1, 0), (1, 1), (1, 2)),
    ((2, 0), (2, 1), (2, 2)),
    ((0, 0), (1, 0), (2, 0)),
    ((0, 1), (1, 1), (2, 1)),
    ((0, 2), (1, 2), (2, 2)),
    ((0, 0), (1, 1), (2, 2)),
    ((2, 0), (1, 1), (0, 2)),
)

CORNERS = ((0, 0), (0, 2), (2, 0), (2, 2))


class GoodStrategy(Strategy):
    '''A strategy that plays a strong game of tic-tac-toe.

    It works out which mark it owns by counting the marks already on the
    board, so it behaves correctly whether it moves first or second.

    It also wins quickly, which matters against an opponent such as
    CornerStrategy that can only ever play the four corners: the game has
    to be finished before the opponent runs out of corner squares.'''

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        mine = self._myMark(board)
        theirs = not mine
        empty = [(row, col) for row in range(3) for col in range(3)
                 if board[row][col] is None]

        # 1. Win the game outright.
        move = self._winningMove(board, mine)
        if move is not None:
            return move

        # 2. Block the opponent from winning on their next move.
        move = self._winningMove(board, theirs)
        if move is not None:
            return move

        # 3. Create a fork: two threats the opponent cannot answer at once.
        move = self._forkMove(board, mine)
        if move is not None:
            return move

        # 4. Stop the opponent from creating a fork of their own.
        move = self._forkMove(board, theirs)
        if move is not None:
            return move

        # 5. Take the centre.  It lies on four lines, and it is the only
        #    extra square an opponent needs in order to win with nothing
        #    but corner moves.
        if board[1][1] is None:
            return (1, 1)

        # 6. Otherwise keep applying pressure.  Squares that create a
        #    threat come first, and sides are preferred to corners because
        #    the middle row and the middle column contain no corners at
        #    all, so a corner taking opponent can never steal them.
        if empty:
            return max(empty, key=lambda cell: (
                self._threatsFrom(board, mine, cell), cell not in CORNERS))

        # The game loop only asks for a move while a square is empty, but
        # never raise if handed a full board.
        return (1, 1)

    def _myMark(self, board: List[List[bool]]) -> bool:
        '''Player one (True) moves first, so an equal number of marks on the
           board means it is player one's turn.'''
        trues = sum(cell is True for row in board for cell in row)
        falses = sum(cell is False for row in board for cell in row)
        return trues <= falses

    def _winningMove(self, board: List[List[bool]],
                     mark: bool) -> Tuple[int, int]:
        '''The empty square of a line that already holds two of `mark`.'''
        for line in LINES:
            values = [board[row][col] for row, col in line]
            if values.count(mark) == 2 and values.count(None) == 1:
                return line[values.index(None)]
        return None

    def _forkMove(self, board: List[List[bool]],
                  mark: bool) -> Tuple[int, int]:
        '''An empty square that creates two threats at once.'''
        for row in range(3):
            for col in range(3):
                if board[row][col] is None:
                    cell = (row, col)
                    if self._threatsFrom(board, mark, cell) >= 2:
                        return cell
        return None

    def _threatsFrom(self, board: List[List[bool]], mark: bool,
                     cell: Tuple[int, int]) -> int:
        '''How many lines would be a single square away from completion for
           `mark` if `mark` were played on `cell`?'''
        threats = 0
        for line in LINES:
            if cell not in line:
                continue
            values = [mark if square == cell else board[square[0]][square[1]]
                      for square in line]
            if values.count(mark) == 2 and values.count(None) == 1:
                threats += 1
        return threats


if __name__ == "__main__":
    result = Game(GoodStrategy(), CornerStrategy()).player1Won()
    assert result is True
    print("GoodStrategy beats CornerStrategy:", result)
