import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def combo_count(line):
    words = prepare_string(line).split()
    combos = 0

    for first, second in zip(words, words[1:]):
        first_ends_with_vowel = first[-1:] in "aeiouy"
        first_ends_with_vowel_m = (
            len(first) >= 2 and first[-2] in "aeiouy" and first[-1] == "m"
        )
        second_starts_with_vowel = second[:1] in "aeiouy"
        second_starts_with_h_vowel = (
            len(second) >= 2 and second[0] == "h" and second[1] in "aeiouy"
        )

        if (first_ends_with_vowel or first_ends_with_vowel_m) and (
            second_starts_with_vowel or second_starts_with_h_vowel
        ):
            combos += 1

    return combos

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count - combo_count(line)

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count += combo_count(line)

    return syllable_count
