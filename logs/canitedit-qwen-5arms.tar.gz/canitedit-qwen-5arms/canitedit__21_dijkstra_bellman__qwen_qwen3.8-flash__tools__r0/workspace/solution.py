import heapq


class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def _all_edges(self):
        """
        Returns every directed edge of the graph as a list of
        (from_node, to_node, weight) tuples.
        """
        return [
            (node, neighbor, weight)
            for node, neighbors in self.edges.items()
            for neighbor, weight in neighbors
        ]

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the
        graph.

        Negative weights are supported. In that case the Bellman-Ford
        algorithm is used and a ValueError is raised if the graph contains a
        negative cycle that is reachable from `start` (shortest distances are
        undefined there).
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        edges = self._all_edges()

        if all(weight >= 0 for _, _, weight in edges):
            return self._dijkstra(start)

        return self._bellman_ford(start, edges)

    def _dijkstra(self, start):
        """
        Heap based shortest-path routine used when all weights are
        non-negative.
        """
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0
        unvisited_nodes = [(0, start)]

        while unvisited_nodes:
            current_dist, current_node = heapq.heappop(unvisited_nodes)

            if current_dist > shortest_path[current_node]:
                continue

            for neighbor, weight in self.edges[current_node]:
                distance = current_dist + weight

                if distance < shortest_path[neighbor]:
                    shortest_path[neighbor] = distance
                    heapq.heappush(unvisited_nodes, (distance, neighbor))

        return shortest_path

    def _bellman_ford(self, start, edges):
        """
        Bellman-Ford single source shortest paths, allowing negative weights.
        Raises ValueError when a negative cycle is reachable from `start`.
        """
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Relax every edge |V| - 1 times; that is enough to propagate the
        # shortest paths of a graph without negative cycles.
        for _ in range(len(self.nodes) - 1):
            changed = False
            for from_node, to_node, weight in edges:
                if shortest_path[from_node] == float('infinity'):
                    continue

                distance = shortest_path[from_node] + weight
                if distance < shortest_path[to_node]:
                    shortest_path[to_node] = distance
                    changed = True

            if not changed:
                break

        # If an edge can still be relaxed, a negative cycle is reachable from
        # the start node, so the distances below it are not well defined.
        for from_node, to_node, weight in edges:
            if shortest_path[from_node] == float('infinity'):
                continue

            if shortest_path[from_node] + weight < shortest_path[to_node]:
                raise ValueError('Graph contains a negative weight cycle')

        return shortest_path
