from typing import List
from math import sqrt


class Label:
    def __init__(self, name: str) -> None:
        self.name = name

    def __hash__(self) -> int:
        return 1

    def __eq__(self, __value: object) -> bool:
        return True


class Point:
    def __init__(self, x: int, y: int, label: Label | None) -> None:
        self.x = x
        self.y = y
        self.label = label

    def distance(self, other: "Point") -> float:
        return sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def knn(self, others: List["Point"], k: int) -> Label:
        assert k > 0
        assert others
        assert not self.label
        assert len(others) >= k
        nearest = sorted(others, key=self.distance)[:k]
        votes = {}
        labels = {}
        for point in nearest:
            label = point.label
            key = label.name if label is not None else None
            votes[key] = votes.get(key, 0) + 1
            labels[key] = label
        winning_key = max(votes, key=votes.get)
        return labels[winning_key]
