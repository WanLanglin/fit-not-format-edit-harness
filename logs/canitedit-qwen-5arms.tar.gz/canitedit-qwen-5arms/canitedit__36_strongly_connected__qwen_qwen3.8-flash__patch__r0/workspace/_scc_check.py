"""Auxiliary self-check for Graph.strongly_connected_components.

Run with `python _scc_check.py`.  This file is not part of the library; it can
be deleted.  NOTE: Node hashes/compares by `id`, so node ids must be ints.
"""
import random

from solution import Graph, Node


def build(ids, edges):
    nodes = {i: Node(i) for i in ids}
    g = Graph(list(nodes.values()))
    for a, b in edges:
        g.add_edge(nodes[a], nodes[b])
    return g, nodes


def reference_partition(g):
    """Brute-force SCC partition via the transitive closure of the out-edges."""
    reachable = {}
    for source in g.nodes:
        seen = {source.id}
        to_visit = [source]
        while to_visit:
            first = to_visit.pop()
            for nxt in first.out_edges:
                if nxt.id not in seen:
                    seen.add(nxt.id)
                    to_visit.append(nxt)
        reachable[source.id] = seen

    classes = {}
    for a in g.nodes:
        key = frozenset(x for x in g.nodes
                        if a.id in reachable[x.id] and x.id in reachable[a.id])
        classes.setdefault(key, len(classes))
    out = {}
    for a in g.nodes:
        key = frozenset(x for x in g.nodes
                        if a.id in reachable[x.id] and x.id in reachable[a.id])
        out.setdefault(classes[key], set()).add(a.id)
    return out


def check(name, ids, edges, expected_num_components=None):
    """Compare the induced partition; the specific integer labels are free."""
    g, nodes = build(ids, edges)
    comps = g.strongly_connected_components()
    assert set(comps.keys()) == set(nodes.values()), (name, "missing/extra nodes")
    assert all(isinstance(label, int) and not isinstance(label, bool)
               for label in comps.values()), (name, comps)
    groups = {}
    for node, label in comps.items():
        groups.setdefault(label, set()).add(node.id)
    expected = reference_partition(g)
    assert groups == expected, (name, groups, expected)
    assert set(groups) == set(range(len(groups))), (name, "labels not contiguous")
    if expected_num_components is not None:
        assert len(groups) == expected_num_components, (name, groups)
    print(name, "OK", sorted(map(sorted, groups.values())))
    return g, nodes


# --- hand-written cases -------------------------------------------------------
check("two-cycles", [0, 1, 2, 3], [(0, 1), (1, 0), (1, 2), (2, 3), (3, 2)], 2)
check("single", [7], [], 1)
check("empty", [], [], 0)
check("dag", [0, 1, 2, 3], [(0, 1), (1, 2), (2, 3), (0, 3)], 4)
check("one-component", [0, 1, 2],
      [(0, 1), (1, 0), (1, 2), (2, 1), (0, 2), (2, 0)], 1)
# 0->1->2->0, 2->3, 3->4->5->3
check("classic", list(range(6)),
      [(0, 1), (1, 2), (2, 0), (2, 3), (3, 4), (4, 5), (5, 3)], 2)
check("selfloop", [0, 1], [(0, 0), (0, 1)], 2)
check("mutual-selfloops", [0, 1], [(0, 0), (1, 1)], 2)
check("tail-into-cycle", list(range(5)),
      [(0, 1), (1, 2), (2, 3), (3, 4), (4, 2)], 3)
check("duplicate-edges", [0, 1], [(0, 1), (1, 0), (0, 1)], 1)
check("disjoint-cycles", list(range(6)),
      [(0, 1), (1, 0), (2, 3), (3, 2), (4, 5), (5, 4)], 3)
check("cross-edge-pair", list(range(4)),
      [(0, 1), (1, 2), (2, 3), (3, 1)], 3)
check("nested-cycles", list(range(7)),
      [(0, 1), (1, 2), (2, 0), (1, 3), (3, 4), (4, 1), (4, 5), (5, 6), (6, 4)], 3)

# --- stress: deep graphs (the DFS is iterative, so no recursion limit) --------
K = 20000
g, n = build(range(K), [(i, i + 1) for i in range(K - 1)])
assert len(set(g.strongly_connected_components().values())) == K
print("long-chain OK")
g, n = build(range(K), [(i, (i + 1) % K) for i in range(K)])
assert len(set(g.strongly_connected_components().values())) == 1
print("large-cycle OK")

# --- the new method must not disturb the existing ones -----------------------
g, n = build([0, 1, 2, 3], [(0, 1), (1, 2), (2, 0), (2, 3)])
before = g.strongly_connected_components()
assert set(g.DFS(n[0])) == {n[0], n[1], n[2], n[3]}
assert [(x.id, sorted(y.id for y in x.out_edges), sorted(y.id for y in x.in_edges))
        for x in g.nodes] == [(0, [1], [2]), (1, [2], [0]), (2, [0, 3], [1]),
                              (3, [], [2])], "graph mutated"
r = g.reverse_edges()
assert g.strongly_connected_components() == before, "mutated graph state"
assert set(r.DFS(r.nodes[3])) == {r.nodes[3]}, "reverse_edges broken"
print("DFS / reverse_edges untouched OK")

# --- randomised cross-check against the transitive closure -------------------
for seed, num_nodes, prob in [(1, 8, 0.3), (2, 12, 0.12), (3, 30, 0.05),
                              (4, 20, 0.5), (5, 40, 0.02), (6, 12, 1.0),
                              (7, 60, 0.01)]:
    rng = random.Random(seed)
    ids = list(range(num_nodes))
    edges = [(a, b) for a in ids for b in ids if a != b and rng.random() < prob]
    check(f"random(seed={seed}, n={num_nodes}, p={prob})", ids, edges)

print("ALL CHECKS PASSED")
