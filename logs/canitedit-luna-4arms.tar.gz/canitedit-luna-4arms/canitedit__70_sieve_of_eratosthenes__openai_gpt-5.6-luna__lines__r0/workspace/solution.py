def find_primes(end: int):
    """Return all prime numbers up to and including ``end``."""
    if end < 2:
        return []

    is_prime = [True] * (end + 1)
    is_prime[0] = is_prime[1] = False

    for num in range(2, int(end**0.5) + 1):
        if is_prime[num]:
            for multiple in range(num * num, end + 1, num):
                is_prime[multiple] = False

    return [num for num in range(2, end + 1) if is_prime[num]]
