from typing import Any, Hashable, Optional

class KeyValueCache:
    def __init__(self) -> None:
        self.primary_cache = {}
        self.secondary_key_map = {}
        self.stats = {"hits": 0, "misses": 0, "num_entries": 0}

    def _record_hit(self) -> None:
        self.stats["hits"] += 1

    def _record_miss(self) -> None:
        self.stats["misses"] += 1

    def _update_num_entries(self) -> None:
        self.stats["num_entries"] = len(self.primary_cache)

    def put(self, primary_key: Hashable, value: Any, secondary_keys: Optional[list[Hashable]] = None) -> None:
        self.primary_cache[primary_key] = value
        self._update_num_entries()
        if secondary_keys:
            for key in secondary_keys:
                self.secondary_key_map[key] = primary_key

    def get_by_primary(self, primary_key: Hashable) -> Any:
        self._update_num_entries()
        if primary_key in self.primary_cache:
            self._record_hit()
            return self.primary_cache[primary_key]
        self._record_miss()
        return None

    def get_by_secondary(self, secondary_key: Hashable) -> Any:
        self._update_num_entries()
        if secondary_key not in self.secondary_key_map:
            self._record_miss()
            return None
        return self.get_by_primary(self.secondary_key_map[secondary_key])

    def delete(self, primary_key: Hashable) -> None:
        if primary_key in self.primary_cache:
            del self.primary_cache[primary_key]
            secondary_keys_to_delete = [k for k, v in self.secondary_key_map.items() if v == primary_key]
            for key in secondary_keys_to_delete:
                del self.secondary_key_map[key]
            self._update_num_entries()

    def get_hits(self) -> int:
        return self.stats["hits"]

    def get_misses(self) -> int:
        return self.stats["misses"]

    def get_num_entries(self) -> int:
        return self.stats["num_entries"]
