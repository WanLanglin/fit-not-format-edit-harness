from typing import List

class CycleError(RuntimeError, ValueError):
    '''Raised when a graph contains a cycle and therefore cannot be topologically sorted'''

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node.id in uniques:
                raise RuntimeError
            else:
                uniques[node.id] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Kahn's algorithm: repeatedly emit nodes with no unresolved predecessors.

        Every node appears after all of the nodes that can reach it in one step,
        so each node is only reachable from nodes earlier in the returned list.
        Raises CycleError if the graph is not acyclic.
        '''
        node_by_id = {}
        in_degree = {}
        for node in self.nodes:
            node_by_id[node.id] = node
            in_degree[node.id] = 0

        # Edges pointing at ids that are not part of the graph are ignored.
        for node in self.nodes:
            for target in node.out_edges:
                if target in in_degree:
                    in_degree[target] += 1

        ordered = []
        # Seed with the sources, keeping the order they were declared in.
        ready = [node for node in self.nodes if in_degree[node.id] == 0]
        head = 0
        while head < len(ready):
            current = ready[head]
            head += 1
            ordered.append(current)
            for target in current.out_edges:
                if target not in in_degree:
                    continue
                in_degree[target] -= 1
                if in_degree[target] == 0:
                    ready.append(node_by_id[target])

        if len(ordered) != len(self.nodes):
            remaining = [node.id for node in self.nodes if in_degree[node.id] > 0]
            raise CycleError('Graph contains a cycle involving node ids: {}'.format(remaining))

        return ordered
