from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort ``lst`` in ascending order, in place, and return it.

    This is a top-down merge sort that takes advantage of input that is
    already (partially) sorted.  After the two halves of a segment have
    been sorted, an early termination condition checks whether the
    sub-arrays are already ordered relative to each other, i.e. whether
    the largest element of the left half is not greater than the smallest
    element of the right half.  When that is the case the merge step is
    skipped completely: one comparison and zero copies instead of a full
    merge.

    Consequences:
    * already sorted input (or input built from large sorted runs) costs
      only n-1 comparisons and no element copies at all,
    * the merge itself only copies the left run into scratch space (the
      right run is already sitting at its final positions), and
    * a single auxiliary buffer is allocated per sort instead of two
      lists per recursive call.

    Only ``<`` is used to compare elements, exactly like the plain version
    of this algorithm, so element types that define ``__lt__`` only keep
    working, and equal elements keep their original relative order (the
    sort is stable).
    """
    n = len(lst)
    if n > 1:
        _merge_sort(lst, 0, n, [0] * n)
    return lst


def _merge_sort(lst: List[int], left: int, right: int, buffer: List[int]) -> None:
    """Sort the half-open slice ``lst[left:right]`` using ``buffer`` as scratch."""
    if right - left <= 1:
        return

    mid = (left + right) // 2
    _merge_sort(lst, left, mid, buffer)
    _merge_sort(lst, mid, right, buffer)

    # Early termination: both halves are sorted and they are already
    # ordered relative to each other, so lst[left:right] needs no merge.
    if not lst[mid] < lst[mid - 1]:
        return

    # Only the left run has to be staged: during the merge the write index
    # never passes the read index of the right run, so the right run can be
    # read from (and stays in) lst itself, and whatever is left of it at the
    # end is already in its final place.
    buffer[left:mid] = lst[left:mid]

    i, j, k = left, mid, left
    while i < mid and j < right:
        if lst[j] < buffer[i]:
            # Smallest remaining element is in the right run.
            lst[k] = lst[j]
            j += 1
        else:
            # Take from the left run when the two are equal, which keeps
            # the merge (and therefore the whole sort) stable.
            lst[k] = buffer[i]
            i += 1
        k += 1
    # Any element left in the right run is already in its final position.
    while i < mid:
        lst[k] = buffer[i]
        i += 1
        k += 1
