class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.

        Negative edge weights are supported: the Bellman-Ford algorithm is used
        instead of Dijkstra's algorithm. A ValueError is raised when the graph
        contains a negative cycle, since the shortest distances are not defined
        in that case.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        edges = [
            (node, neighbor, weight)
            for node in self.nodes
            for neighbor, weight in self.edges.get(node, [])
        ]

        # A shortest path contains at most len(self.nodes) - 1 edges, so
        # relaxing every edge that many times is enough to compute all of the
        # shortest distances.
        for _ in range(max(len(self.nodes) - 1, 0)):
            updated = False

            for node, neighbor, weight in edges:
                distance = shortest_path[node]

                if distance == float('infinity'):
                    continue

                distance += weight

                if distance < shortest_path[neighbor]:
                    shortest_path[neighbor] = distance
                    updated = True

            if not updated:
                break

        # If an edge can still be relaxed, the graph contains a negative cycle
        # and at least one of the distances can be decreased indefinitely.
        for node, neighbor, weight in edges:
            distance = shortest_path[node]

            if distance == float('infinity'):
                continue

            if distance + weight < shortest_path[neighbor]:
                raise ValueError('Graph contains a negative cycle')

        return shortest_path
