def concatenate_nums(message):
    """Return a subject-verb-object message in object-verb-subject order."""
    parts = message.split("  ")
    if len(parts) == 3:
        return "  ".join((parts[2], parts[1], parts[0]))

    # Also support messages whose three components use single spaces.
    parts = message.split(" ")
    return " ".join((parts[2], parts[1], parts[0]))


def format_string(name1, name2, message):
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {concatenate_nums(message)}'
    return formattedString
