from abc import ABC, abstractmethod
import math


class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


class MyVector(Vector):
    def manhattan_distance(self, other: Vector) -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError("Vectors must have the same length")

        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def cosine_similarity(self, other: Vector) -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError("Vectors must have the same length")

        self_magnitude = math.sqrt(sum(value * value for value in self.vals))
        other_magnitude = math.sqrt(sum(value * value for value in other.vals))
        if self_magnitude == 0 or other_magnitude == 0:
            raise ValueError("Cosine similarity is undefined for a zero vector")

        dot_product = sum(a * b for a, b in zip(self.vals, other.vals))
        cosine = dot_product / (self_magnitude * other_magnitude)
        # Guard against small floating-point errors outside acos's domain.
        cosine = max(-1.0, min(1.0, cosine))
        return float(math.acos(cosine))
