from typing import List, Union

class Manager:
    def __init__(self, name: str, direct_reports: List[Union["Manager", "IC"]]):
        self.name = name
        self.team = direct_reports
    
    def find_manager_n(self, name: str, n: int) -> List[str]:
        """Return the sorted names of the managers exactly n levels above name.

        n must be at least 1: n=1 is the direct manager, n=2 is the manager's
        manager, and so on. Managers above the root the search starts from are
        unknown, so they are never returned.
        """
        if n < 1:
            raise ValueError("n must be at least 1")
        manager_names = self.find_manager_n_help(name, n, [])
        return sorted(list(set(manager_names)))

    def find_manager_n_help(self, name: str, n: int, path: List[str]) -> List[str]:
        """Collect the managers n levels above name.

        path holds the manager names above self, ordered from the search root
        down to self's parent, so the manager n levels above self is path[-n].
        """
        manager_names = []
        if self.name == name and len(path) >= n:
            # self is a Manager, so its own manager is already the last path entry.
            manager_names.append(path[-n])
        for direct_report in self.team:
            if isinstance(direct_report, Manager):
                manager_names.extend(direct_report.find_manager_n_help(name, n, path + [self.name]))
            elif direct_report.name == name and len(path) + 1 >= n:
                # An IC has no team, so treat its own manager (self) as part of the
                # chain: the manager n levels above it is (path + [self.name])[-n].
                manager_names.append((path + [self.name])[-n])
        return manager_names
    
class IC:
    def __init__(self, name: str):
        self.name = name
