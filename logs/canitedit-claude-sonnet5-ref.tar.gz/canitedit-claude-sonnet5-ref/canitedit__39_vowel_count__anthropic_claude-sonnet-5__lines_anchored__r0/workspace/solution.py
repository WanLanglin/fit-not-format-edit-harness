import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    diphthongs = sorted(
        ["ae", "oe", "ei", "ea", "ia", "io", "aea"],
        key=len,
        reverse=True,
    )
    prepared = prepare_line(line)
    count = 0
    i = 0
    while i < len(prepared):
        matched = False
        for diphthong in diphthongs:
            if prepared[i:i + len(diphthong)] == diphthong:
                i += len(diphthong)
                matched = True
                break
        if not matched:
            if prepared[i] in "aeiouy":
                count += 1
            i += 1
    return count
