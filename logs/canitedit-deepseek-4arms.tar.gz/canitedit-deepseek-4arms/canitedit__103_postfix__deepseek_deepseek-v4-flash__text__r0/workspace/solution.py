from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        Raises an Exception when the input is malformed, i.e. when applying the
        postfix reduction leaves more than one number in the resulting sequence.
        """
        stack: List[float] = []
        for token in inputs:
            if isinstance(token, int):
                stack.append(token)
            else:
                if len(stack) < 2:
                    raise Exception("Malformed postfix expression")
                right = stack.pop()
                left = stack.pop()
                match token:
                    case "+":
                        stack.append(left + right)
                    case "-":
                        stack.append(left - right)
                    case "*":
                        stack.append(left * right)
                    case "/":
                        stack.append(left / right)
        if len(stack) != 1:
            raise Exception("Malformed postfix expression")
        return stack[0]
