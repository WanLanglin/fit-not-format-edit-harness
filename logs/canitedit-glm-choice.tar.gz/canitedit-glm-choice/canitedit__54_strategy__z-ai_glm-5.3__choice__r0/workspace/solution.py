from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception
        
class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True


class GoodStrategy(Strategy):
    '''A strategy that plays a strong game of tic-tac-toe.

    On every turn it takes the first available move from this list:

        1. A move that wins the game immediately.
        2. A move that stops the opponent winning on their next turn.
        3. A move that creates a fork (two winning threats at once).
        4. The move the opponent would use to create a fork.
        5. The centre square.
        6. A side square.
        7. A corner square.

    Sides are preferred to corners so that an opponent which only ever
    plays corners (such as CornerStrategy) always has a corner available
    and so never runs out of moves.  Following these rules this strategy
    beats CornerStrategy in five of its own moves.
    '''

    LINES = (
        ((0, 0), (0, 1), (0, 2)),
        ((1, 0), (1, 1), (1, 2)),
        ((2, 0), (2, 1), (2, 2)),
        ((0, 0), (1, 0), (2, 0)),
        ((0, 1), (1, 1), (2, 1)),
        ((0, 2), (1, 2), (2, 2)),
        ((0, 0), (1, 1), (2, 2)),
        ((2, 0), (1, 1), (0, 2)),
    )
    CENTER = (1, 1)
    SIDES = ((0, 1), (1, 0), (1, 2), (2, 1))
    CORNERS = ((0, 0), (0, 2), (2, 0), (2, 2))

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        emptySquares = self._emptySquares(board)
        if not emptySquares:
            # The board is full; Game stops asking before this can happen.
            return self.CENTER

        mine, theirs = self._marks(board)

        # 1. Win the game outright.
        move = self._winningSquare(board, mine)
        if move is not None:
            return move

        # 2. Block the opponent from winning on their next move.
        move = self._winningSquare(board, theirs)
        if move is not None:
            return move

        # 3. Create two winning threats at the same time.
        move = self._forkSquare(board, mine)
        if move is not None:
            return move

        # 4. Take the square the opponent would fork with.
        move = self._forkSquare(board, theirs)
        if move is not None:
            return move

        # 5. The center.
        if board[1][1] is None:
            return self.CENTER

        # 6. A side square, or 7. a corner square.
        for square in self.SIDES + self.CORNERS:
            if board[square[0]][square[1]] is None:
                return square

        return emptySquares[0]

    @classmethod
    def _emptySquares(cls, board):
        '''Every (row, column) that nobody has played yet.'''
        return [(row, col) for row in range(3) for col in range(3)
                if board[row][col] is None]

    @staticmethod
    def _marks(board):
        '''The marks this strategy plays with, as (mine, theirs).

        Player one marks its squares with True and always moves first, so
        when the board holds as many True marks as False marks it is player
        one's turn, and when it holds one more True than False it is player
        two's turn.'''
        trues = sum(row.count(True) for row in board)
        falses = sum(row.count(False) for row in board)
        return (True, False) if trues == falses else (False, True)

    @classmethod
    def _winningSquare(cls, board, mark):
        '''An empty square that completes a line of three for `mark`.'''
        for line in cls.LINES:
            values = [board[row][col] for row, col in line]
            if values.count(mark) == 2 and values.count(None) == 1:
                return line[values.index(None)]
        return None

    @classmethod
    def _threats(cls, board, mark):
        '''How many lines `mark` is one square away from winning.'''
        threats = 0
        for line in cls.LINES:
            values = [board[row][col] for row, col in line]
            if values.count(mark) == 2 and values.count(None) == 1:
                threats += 1
        return threats

    @classmethod
    def _forkSquare(cls, board, mark):
        '''An empty square that would give `mark` two winning threats.'''
        for row, col in cls._emptySquares(board):
            trial = [cells[:] for cells in board]
            trial[row][col] = mark
            if cls._threats(trial, mark) >= 2:
                return (row, col)
        return None


if __name__ == '__main__':
    print(Game(GoodStrategy(), CornerStrategy()).player1Won())
