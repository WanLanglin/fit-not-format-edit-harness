import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    diphthongs = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]
    count = 0
    i = 0
    while i < len(line):
        matched = False
        for diph in diphthongs:
            if line[i:i+len(diph)] == diph:
                count += 1
                i += len(diph)
                matched = True
                break
        if not matched:
            if line[i] in "aeiouy":
                count += 1
            i += 1
    return count
