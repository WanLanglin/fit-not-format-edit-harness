class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output

    def next_n_fibs(self, n: int):
        prev_prev = self.prev_prev
        prev = self.prev
        fibs = []

        for _ in range(n):
            output = prev + prev_prev
            fibs.append(output)
            prev_prev, prev = prev, output

        return fibs
