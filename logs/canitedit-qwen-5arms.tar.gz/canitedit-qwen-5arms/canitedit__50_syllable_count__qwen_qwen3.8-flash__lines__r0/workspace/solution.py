import string

VOWELS = "aeiouy"

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in VOWELS:
            vowel_count += 1
    return vowel_count

def combo_count(line):
    """Count the elisions ("combos") in a line of text.

    A combo happens across two neighbouring words when the first word ends in
    a vowel (optionally followed by 'm') and the next word begins with a vowel
    (optionally preceded by 'h'):

      V  + V    e.g. mare et
      VM + V    e.g. repostum iudicium
      V  + hV   e.g. pondere habentia
      VM + hV   e.g. sam henry
    """
    def ends_with_vowel(word):
        if word and word[-1] in VOWELS:
            return True
        return len(word) > 1 and word[-1] == "m" and word[-2] in VOWELS

    def starts_with_vowel(word):
        if word and word[0] in VOWELS:
            return True
        return len(word) > 1 and word[0] == "h" and word[1] in VOWELS

    words = line.split(" ")
    combos = 0
    for first, second in zip(words, words[1:]):
        if ends_with_vowel(first) and starts_with_vowel(second):
            combos += 1
    return combos

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    # every vowel is a syllable, except that a "combo" of two vowels across a
    # word boundary is sung/pronounced as a single syllable.
    syllable_count += vowel_count(line) - combo_count(line)

    return syllable_count
