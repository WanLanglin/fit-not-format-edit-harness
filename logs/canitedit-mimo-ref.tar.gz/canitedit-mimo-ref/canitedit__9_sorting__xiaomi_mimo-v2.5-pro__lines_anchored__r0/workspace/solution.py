class Sorter:
    def __init__(self):
        pass

    def sort(self, nums: list[int]) -> None:
        for i in range(1, len(nums)):
            self.insert(nums, i)

    def insert(self, nums: list[int], index: int) -> None:
        key = nums[index]
        j = index - 1
        while j >= 0 and nums[j] > key:
            nums[j + 1] = nums[j]
            j -= 1
        nums[j + 1] = key
