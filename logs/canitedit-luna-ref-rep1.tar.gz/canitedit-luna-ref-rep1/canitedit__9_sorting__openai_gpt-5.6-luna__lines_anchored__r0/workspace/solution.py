class Sorter:
    def __init__(self):
        pass

    def sort(self, nums: list[int]):
        for i in range(1, len(nums)):
            value = nums[i]
            j = i - 1
            while j >= 0 and nums[j] > value:
                nums[j + 1] = nums[j]
                j -= 1
            nums[j + 1] = value
        
    def insert(self, nums: list[int], num: int) -> list[int]:
        output = []
        for i, n in enumerate(nums):
            if num < n:
                output.append(num)
                return output + nums[i:]
            else:
                output.append(n)
        return output + [num]
