from abc import ABC, abstractmethod


class Message(ABC):
    """Base class for all message types."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Return the processed representation of the message."""


class TextMessage(Message):
    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        messages = {
            "text": TextMessage,
            "image": ImageMessage,
        }
        try:
            message_class = messages[message_type]
        except KeyError:
            raise ValueError(f"Unknown message type: {message_type}")
        return message_class(content)


def process_message(message, message_type):
    if message_type not in ("text", "image"):
        return "Unknown message type"
    return MessageFactory.get_message(message_type, message).process()
