class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """Compute shortest distances from ``start`` using Bellman-Ford.

        Bellman-Ford supports negative edge weights and can detect a negative
        cycle reachable from the source.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Relax every edge at most |V| - 1 times.  Stop early when a complete
        # pass makes no changes.
        for _ in range(len(self.nodes) - 1):
            changed = False
            for current_node in self.nodes:
                if shortest_path[current_node] == float('infinity'):
                    continue

                for neighbor, weight in self.edges[current_node]:
                    distance = shortest_path[current_node] + weight
                    if distance < shortest_path[neighbor]:
                        shortest_path[neighbor] = distance
                        changed = True

            if not changed:
                break

        # An additional possible relaxation means a reachable negative cycle
        # exists, so shortest distances are not well-defined.
        for current_node in self.nodes:
            if shortest_path[current_node] == float('infinity'):
                continue

            for neighbor, weight in self.edges[current_node]:
                if shortest_path[current_node] + weight < shortest_path[neighbor]:
                    raise ValueError('Graph contains a negative cycle')

        return shortest_path
