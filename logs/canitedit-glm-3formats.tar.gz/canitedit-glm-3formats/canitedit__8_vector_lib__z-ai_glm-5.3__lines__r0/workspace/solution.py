from abc import ABC, abstractmethod
import math


class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


class MyVector(Vector):
    """Concrete vector implementation of the ``Vector`` interface."""

    def _check_same_length(self, other: Vector) -> None:
        """Raise if ``self`` and ``other`` do not have the same number of values."""
        if len(self.vals) != len(other.vals):
            raise ValueError(
                "Vectors must have the same length: "
                f"{len(self.vals)} != {len(other.vals)}"
            )

    @staticmethod
    def _magnitude(vals) -> float:
        """Return the Euclidean magnitude (L2 norm) of ``vals``."""
        return math.sqrt(sum(val * val for val in vals))

    def manhattan_distance(self, other: Vector) -> float:
        """Return the sum of absolute differences of both vectors' values.

        Raises:
            ValueError: if the two vectors differ in length.
        """
        self._check_same_length(other)
        return float(
            sum(abs(a - b) for a, b in zip(self.vals, other.vals))
        )

    def cosine_similarity(self, other: Vector) -> float:
        """Return the angle (in radians) between the two vectors.

        Raises:
            ValueError: if the two vectors differ in length.
            ValueError: if either vector has a magnitude of zero.
        """
        self._check_same_length(other)

        self_magnitude = self._magnitude(self.vals)
        other_magnitude = self._magnitude(other.vals)

        if self_magnitude == 0 or other_magnitude == 0:
            raise ValueError("Vectors must have a non-zero magnitude")

        dot_product = sum(a * b for a, b in zip(self.vals, other.vals))
        cosine = dot_product / (self_magnitude * other_magnitude)

        # Guard against floating point drift outside the valid acos range.
        cosine = max(-1.0, min(1.0, cosine))
        return float(math.acos(cosine))
