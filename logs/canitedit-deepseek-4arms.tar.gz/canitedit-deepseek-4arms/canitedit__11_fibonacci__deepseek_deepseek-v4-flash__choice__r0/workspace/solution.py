class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int) -> list:
        if hasattr(self, 'prev_prev') and hasattr(self, 'prev'):
            prev_prev, prev = self.prev_prev, self.prev
        else:
            prev_prev, prev = 0, 1
        result = []
        for _ in range(n):
            output = prev + prev_prev
            prev_prev, prev = prev, output
            result.append(output)
        return result
