import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    vowels = "aeiouy"
    words = line.split(" ")
    for word, next_word in zip(words, words[1:]):
        if not word or not next_word or next_word[0] not in vowels:
            continue

        if (word[-1] in vowels or
                (len(word) >= 2 and word[-2] in vowels and word[-1] in "mh") or
                (len(word) >= 3 and word[-3] in vowels and word[-2:] == "mh")):
            syllable_count += 1

    return syllable_count
