import string

VOWELS = "aeiouy"


def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()


def _combo_ending_length(word):
    """Length of the word ending that starts a combo (0 when there is none).

    A combo starts with a vowel at the end of a word, optionally followed
    by 'm' or 'h'.
    """
    if not word:
        return 0
    if word[-1] in VOWELS:
        return 1
    if len(word) > 1 and word[-1] in "mh" and word[-2] in VOWELS:
        return 2
    return 0


def _combo_beginning_length(word):
    """Length of the word beginning that ends a combo (0 when there is none).

    A combo ends with a vowel at the beginning of a word, optionally
    preceded by 'h'.
    """
    if not word:
        return 0
    if word[0] in VOWELS:
        return 1
    if len(word) > 1 and word[0] == "h" and word[1] in VOWELS:
        return 2
    return 0


def _is_combo(first, second):
    """Return True when the words `first` and `second` form a combo."""
    return bool(_combo_ending_length(first) and _combo_beginning_length(second))


def combo_count(line):
    """Return the number of combos in `line`."""
    words = line.split(" ")
    combos = 0
    for first, second in zip(words, words[1:]):
        if _is_combo(first, second):
            combos += 1
    return combos


def _combo_vowel_indexes(line):
    """Return the indexes of the vowels that take part in a combo."""
    words = line.split(" ")
    indexes = set()
    start = 0
    for first, second in zip(words, words[1:]):
        second_start = start + len(first) + 1
        ending = _combo_ending_length(first)
        beginning = _combo_beginning_length(second)
        if ending and beginning:
            # Vowel at the end of the first word.
            indexes.add(start + len(first) - ending)
            # Vowel at the beginning of the second word.
            indexes.add(second_start + beginning - 1)
        start = second_start
    return indexes


def vowel_count(line):
    combo_vowels = _combo_vowel_indexes(line)
    vowel_count = 0
    for index, char in enumerate(line):
        if char in VOWELS and index not in combo_vowels:
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count += combo_count(line)

    return syllable_count
