from operator import add, sub, mul, truediv
from typing import Callable, Dict, List, Literal

Op = Literal["+", "-", "*", "/"]
Token = int | Op

OPERATIONS: Dict[Op, Callable[[float, float], float]] = {
    "+": add,
    "-": sub,
    "*": mul,
    "/": truediv,
}


class MalformedExpressionError(ValueError):
    """Raised when a postfix expression does not reduce to a single number."""


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        The sequence is reduced by scanning it for its first operator, applying that
        operator to the two numbers in front of it and replacing them with the result,
        then repeating from the start until no operators are left.

        Raises:
            MalformedExpressionError: if the input is malformed, i.e. if an operator is
                reached before two numbers are available to apply it to, or if reducing
                the sequence leaves more than one number behind.
        """
        numbers: List[float] = []

        for token in inputs:
            match token:
                case "+" | "-" | "*" | "/":
                    if len(numbers) < 2:
                        raise MalformedExpressionError(
                            f"cannot apply {token!r}: only {len(numbers)} "
                            f"number(s) available in front of it"
                        )
                    right = numbers.pop()
                    left = numbers.pop()
                    numbers.append(OPERATIONS[token](left, right))
                case _:
                    if isinstance(token, (int, float)):
                        numbers.append(token)
                    else:
                        raise MalformedExpressionError(
                            f"unexpected token {token!r}: tokens must be numbers or "
                            f"one of +, -, *, /"
                        )

        if len(numbers) != 1:
            raise MalformedExpressionError(
                f"malformed expression: {len(numbers)} numbers left over after "
                f"applying every operator, expected exactly 1"
            )

        return numbers[0]
