

class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """Compute shortest distances from start using Bellman-Ford.

        Raises ValueError when a negative-weight cycle reachable from start
        exists.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Relax every edge at most |V| - 1 times.  This handles negative
        # weights, unlike the greedy ordering used by Dijkstra's algorithm.
        for _ in range(len(self.nodes) - 1):
            changed = False
            for node in self.nodes:
                if shortest_path[node] == float('infinity'):
                    continue
                for neighbor, weight in self.edges[node]:
                    distance = shortest_path[node] + weight
                    if distance < shortest_path[neighbor]:
                        shortest_path[neighbor] = distance
                        changed = True
            if not changed:
                break

        # A further relaxation means a reachable negative cycle exists.
        for node in self.nodes:
            if shortest_path[node] == float('infinity'):
                continue
            for neighbor, weight in self.edges[node]:
                if shortest_path[node] + weight < shortest_path[neighbor]:
                    raise ValueError('Graph contains a negative cycle')

        return shortest_path
