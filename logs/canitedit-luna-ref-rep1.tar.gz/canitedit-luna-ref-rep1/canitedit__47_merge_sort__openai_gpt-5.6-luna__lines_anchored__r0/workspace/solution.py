from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort *lst* using merge sort, skipping already ordered merges."""

    def sort(start: int, end: int) -> None:
        if end - start <= 1:
            return

        middle = (start + end) // 2
        sort(start, middle)
        sort(middle, end)

        # Both halves are sorted at this point.  If their boundary is already
        # ordered, the whole range is sorted and no copying is necessary.
        if lst[middle - 1] <= lst[middle]:
            return

        left = lst[start:middle]
        right = lst[middle:end]
        left_index = right_index = 0
        destination = start

        while left_index < len(left) and right_index < len(right):
            if left[left_index] <= right[right_index]:
                lst[destination] = left[left_index]
                left_index += 1
            else:
                lst[destination] = right[right_index]
                right_index += 1
            destination += 1

        while left_index < len(left):
            lst[destination] = left[left_index]
            left_index += 1
            destination += 1

        while right_index < len(right):
            lst[destination] = right[right_index]
            right_index += 1
            destination += 1

    sort(0, len(lst))
    return lst
