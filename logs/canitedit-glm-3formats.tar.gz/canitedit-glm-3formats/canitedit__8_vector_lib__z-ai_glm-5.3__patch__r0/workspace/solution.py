from abc import ABC, abstractmethod
import math

class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass

class MyVector(Vector):
    def __init__(self, *args: int):
        super().__init__(*args)

    def _check_same_length(self, other: Vector) -> None:
        if len(self.vals) != len(other.vals):
            raise ValueError(
                "Vectors must have the same length: "
                f"{len(self.vals)} != {len(other.vals)}"
            )

    def manhattan_distance(self, other: Vector) -> float:
        self._check_same_length(other)
        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def cosine_similarity(self, other: Vector) -> float:
        self._check_same_length(other)

        dot = sum(a * b for a, b in zip(self.vals, other.vals))
        mag_self = math.sqrt(sum(a * a for a in self.vals))
        mag_other = math.sqrt(sum(b * b for b in other.vals))

        if mag_self == 0 or mag_other == 0:
            raise ValueError("Cannot compute the angle of a zero-magnitude vector")

        cosine = max(-1.0, min(1.0, dot / (mag_self * mag_other)))
        return float(math.acos(cosine))
