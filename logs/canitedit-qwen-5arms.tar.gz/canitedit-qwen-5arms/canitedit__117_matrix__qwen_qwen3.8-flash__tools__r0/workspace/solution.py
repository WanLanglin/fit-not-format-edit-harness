from typing import List


class Matrix:
    def __init__(self, content: List[List[int]]) -> None:
        num_cols = None
        for row in content:
            if num_cols is None:
                num_cols = len(row)
            else:
                if len(row) != num_cols:
                    raise ValueError
        self.content = content

    def transpose(self) -> None:
        new_content = [
            [0 for i in range(len(self.content))] for i in range(len(self.content[0]))
        ]
        for row in range(len(self.content)):
            for col in range(len(self.content[row])):
                new_content[col][row] = self.content[row][col]
        self.content = new_content

    def determinant(self) -> int:
        rows = self.content
        # A determinant only exists for a genuine square matrix. Matrix.__init__
        # only checks that every row has the same length as the first row, so
        # ragged input such as [[1, 2], [3]] or [[1, 2], [3, 4, 5]] can reach
        # here; verify each row has as many entries as there are rows.
        assert rows and all(len(row) == len(rows) for row in rows)

        if len(rows) == 2:
            return rows[0][0] * rows[1][1] - rows[0][1] * rows[1][0]
        elif len(rows) == 3:
            return (
                rows[0][0] * (rows[1][1] * rows[2][2] - rows[1][2] * rows[2][1])
                - rows[1][0] * (rows[0][1] * rows[2][2] - rows[0][2] * rows[2][1])
                + rows[2][0] * (rows[0][1] * rows[1][2] - rows[0][2] * rows[1][1])
            )
        else:
            raise NotImplementedError
