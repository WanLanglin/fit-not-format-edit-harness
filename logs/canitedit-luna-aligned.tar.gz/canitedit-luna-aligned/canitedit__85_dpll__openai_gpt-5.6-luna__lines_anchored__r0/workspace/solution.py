from copy import deepcopy
from typing import Optional


class DPLLSolver:
    def __init__(self, cnf):
        """
        initializes the DPLL Solver with a given CNF (Conjunctive Normal Form) input.

        :param cnf: a string representing the CNF, where each clause is on a new line,
                    literals are separated by spaces, negation is denoted by '!', and
                    variables are single characters.
        """
        self.assign_true = set()  # set of literals assigned True
        self.assign_false = set()  # set of literals assigned False
        self.n_props = 0          # count of propositions made
        self.n_splits = 0         # count of splits (decisions) made
        self.cnf = cnf            # the CNF input

    def print_cnf(self):
        """
        prints the CNF in a more readable format, where clauses are enclosed in parentheses
        and literals are separated by '+'.
        """
        s = ''
        for i in self.cnf:
            if len(i) > 0:
                s += '(' + i.replace(' ', '+') + ')'
        print(s)

    def solve(self, cnf, literals):
        """
        recursively solves the CNF using the DPLL algorithm.

        :param cnf: the CNF in its current state (as clauses get simplified).
        :param literals: list of literals that haven't been assigned yet.
        :return: True if the CNF is satisfiable, False otherwise.
        """
        new_true = []  # literals assigned True in this decision level
        new_false = []  # literals assigned False in this decision level
        self.n_splits += 1
        cnf = list(set(cnf))  # remove duplicate clauses

        def undo_level():
            """Undo assignments made while solving this decision level."""
            for literal in new_true:
                self.assign_true.discard(literal)
            for literal in new_false:
                self.assign_false.discard(literal)

        # An empty clause is a contradiction.  It must be checked before the
        # empty-CNF (satisfied) case below.
        if any(not clause.strip() for clause in cnf):
            undo_level()
            return False

        # Unit propagation
        while True:
            units = [clause for clause in cnf if len(clause.split()) == 1]
            if not units:
                break

            unit = units[0].split()[0]
            variable = unit[-1]
            assigning_true = not unit.startswith('!')

            # A variable cannot be assigned both values.
            if ((assigning_true and variable in self.assign_false) or
                    (not assigning_true and variable in self.assign_true)):
                undo_level()
                return False

            self.n_props += 1
            if assigning_true:
                if variable not in self.assign_true:
                    self.assign_true.add(variable)
                    new_true.append(variable)
                opposite = '!' + variable
            else:
                if variable not in self.assign_false:
                    self.assign_false.add(variable)
                    new_false.append(variable)
                opposite = variable

            # Remove satisfied clauses and the falsified literal from the
            # remaining clauses.  Removing it can create an empty clause.
            simplified = []
            for clause in cnf:
                clause_literals = clause.split()
                if unit in clause_literals:
                    continue
                if opposite in clause_literals:
                    clause_literals.remove(opposite)
                simplified.append(' '.join(clause_literals))
            cnf = list(set(simplified))

            if any(not clause.strip() for clause in cnf):
                undo_level()
                return False

        # check if CNF is solved
        if len(cnf) == 0:
            return True

        # splitting (choose a literal and try both True and False)
        literals = [literal for clause in cnf for literal in clause.split()
                    if literal[-1].isalpha()]
        if not literals:
            undo_level()
            return False
        x = literals[0][-1]
        if self.solve(deepcopy(cnf) + [x], deepcopy(literals)):
            return True
        if self.solve(deepcopy(cnf) + ['!' + x], deepcopy(literals)):
            return True

        # Both branches failed, so undo assignments made at this level.
        undo_level()
        return False

    def dpll(self) -> Optional[dict]:
        """
        public method to solve the CNF using the DPLL algorithm.

        :return: a dictionary mapping each literal to its boolean value if the CNF is satisfiable,
                 or None if the CNF is unsatisfiable.
        """
        cnf = self.cnf.splitlines()
        literals = [literal for clause in cnf for literal in clause.split()
                    if literal[-1].isalpha()]
        res = {}
        if self.solve(cnf, literals):
            # assign values to literals based on the assignments made during solving
            for i in self.assign_true:
                res[i] = True
            for i in self.assign_false:
                res[i] = False

            return res
        else:
            return None  # unsat!
