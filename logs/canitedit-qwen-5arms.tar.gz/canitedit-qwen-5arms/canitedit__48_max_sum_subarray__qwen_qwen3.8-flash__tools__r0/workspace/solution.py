from typing import List, Tuple


def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Kadane's algorithm that also tracks the bounds of the best subarray.

    Returns a tuple of (sum, start_idx, end_idx), where ``start_idx`` and
    ``end_idx`` are the inclusive indices of the maximum-sum subarray.
    """
    max_so_far = lst[0]
    curr_max = lst[0]
    start_idx = 0
    end_idx = 0
    curr_start = 0
    for i in range(1, len(lst)):
        if curr_max + lst[i] < lst[i]:
            curr_max = lst[i]
            curr_start = i
        else:
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            start_idx = curr_start
            end_idx = i
    return max_so_far, start_idx, end_idx
