from solution import Node, Leaf

# Build a tree: root(3) with leaf(1), leaf(2), and node(7) with leaf(4), leaf(5)
tree = Node(3, [Leaf(1), Leaf(2), Node(7, [Leaf(4), Leaf(5)])])
assert tree.count_leaves() == 4, tree.count_leaves()

# Single leaf
assert Leaf(9).count_leaves() == 1

# Empty node has no leaves
assert Node(0, []).count_leaves() == 0

print("All count_leaves assertions passed")
