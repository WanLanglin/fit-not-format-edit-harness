from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        The tokens are scanned until an operator is found, that operator is applied to the
        last two numbers and the result replaces them; the process repeats until no
        operators are left.  An ``Exception`` is raised when the input is malformed, i.e.
        when this process leaves something other than exactly one number behind.
        """

        def pop_operands(stack: List[float], op: str) -> tuple[float, float]:
            """Return the two most recently seen numbers, in the original binding order."""
            if len(stack) < 2:
                raise Exception(
                    f"malformed input: operator '{op}' has {len(stack)} operand(s), needs 2"
                )
            return stack.pop(), stack.pop()

        def parseHelp(inputs: List[Token], stack: List[float]) -> float:
            if not inputs:
                if len(stack) != 1:
                    raise Exception(
                        "malformed input: expression leaves "
                        f"{len(stack)} numbers instead of 1"
                    )
                return stack[0]
            next = inputs.pop()
            match next:
                case "+":
                    first, second = pop_operands(stack, next)
                    stack.insert(0, first + second)
                case "-":
                    first, second = pop_operands(stack, next)
                    stack.insert(0, first - second)
                case "*":
                    first, second = pop_operands(stack, next)
                    stack.insert(0, first * second)
                case "/":
                    first, second = pop_operands(stack, next)
                    stack.insert(0, first / second)
                case _:
                    stack.insert(0, next)
            return parseHelp(inputs, stack)

        return parseHelp(list(inputs), [])
