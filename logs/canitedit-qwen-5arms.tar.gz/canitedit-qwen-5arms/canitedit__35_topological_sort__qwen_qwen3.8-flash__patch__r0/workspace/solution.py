from typing import Dict, List, Tuple
import heapq

class CycleError(RuntimeError, ValueError):
    '''Raised when a graph that is not acyclic is sorted topologically'''

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges
        # Legacy alias: the constructor is given the outgoing edges only, the
        # incoming edges of a node cannot be known without the whole graph.
        self.in_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Return the nodes ordered so that every node appears after all the
        nodes it can be reached from, i.e. for each edge u -> v, u comes
        before v.  Raises CycleError if the graph contains a cycle.
        '''
        # Collapse duplicate ids so the bookkeeping below stays consistent.
        nodes: Dict[int, Node] = {node.id: node for node in self.nodes}

        # indegree[id] = number of not yet emitted predecessors of id
        indegree: Dict[int, int] = {node_id: 0 for node_id in nodes}
        # successors[id] = neighbours reachable from id in one step (inside graph)
        successors: Dict[int, List[int]] = {node_id: [] for node_id in nodes}
        for node_id, node in nodes.items():
            # The constructor is documented as taking the outgoing edges; fall
            # back to the legacy alias if a node only carries that attribute.
            edges = getattr(node, 'out_edges', None)
            if edges is None:
                edges = getattr(node, 'in_edges', ())
            for target in edges:
                if target in nodes:
                    successors[node_id].append(target)
                    indegree[target] += 1

        # Kahn's algorithm: a node can be emitted once all of its predecessors
        # have been emitted.  The heap keeps ties ordered by id, so the result
        # is deterministic (lexicographically smallest valid order).
        ready: List[Tuple[int, int]] = [(node_id, node_id)
                                        for node_id in nodes if indegree[node_id] == 0]
        heapq.heapify(ready)

        ordered: List[Node] = []
        while ready:
            _, current = heapq.heappop(ready)
            ordered.append(nodes[current])
            for target in successors[current]:
                indegree[target] -= 1
                if indegree[target] == 0:
                    heapq.heappush(ready, (target, target))

        if len(ordered) != len(nodes):
            # Some nodes kept waiting on a predecessor that never became
            # emit-able: those nodes form (or lead into) a cycle.
            cyclic = sorted(node_id for node_id, degree in indegree.items() if degree > 0)
            raise CycleError(
                'Graph is not acyclic, node ids with unresolved predecessors: %s' % cyclic)

        return ordered
