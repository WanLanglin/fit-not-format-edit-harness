class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def same_size(self, other) -> bool:
        """Return True when this matrix and ``other`` have the same dimensions."""
        if len(self.matrix) != len(other.matrix):
            return False
        return all(len(row) == len(other_row)
                   for row, other_row in zip(self.matrix, other.matrix))

    def add(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must have the same size to be added")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[i])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)
    
    def subtract(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must have the same size to be subtracted")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[i])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)
