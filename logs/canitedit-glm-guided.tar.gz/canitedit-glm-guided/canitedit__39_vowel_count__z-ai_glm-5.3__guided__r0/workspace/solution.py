import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    """Count the vowels in a line of text, skipping diphthongs.

    A diphthong is one of "ae", "oe", "ei", "ea", "ia", "io", "aea";
    the letters of a diphthong are not counted as vowels.

    Example: vowel_count('adspirate meis primaque ab origine mundi') == 15
    Example: vowel_count('in nova fert animus mutatas dicere formas') == 15
    """
    # Longer diphthongs are listed first so that "aea" is skipped as a
    # whole instead of being read as "ae" followed by a lone "a".
    diphthongs = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]
    text = prepare_line(line)
    count = 0
    i = 0
    while i < len(text):
        diphthong = None
        for candidate in diphthongs:
            if text.startswith(candidate, i):
                diphthong = candidate
                break
        if diphthong is not None:
            # Diphthongs are not counted, so skip every letter of the match.
            i += len(diphthong)
        else:
            if text[i] in "aeiouy":
                count += 1
            i += 1
    return count
