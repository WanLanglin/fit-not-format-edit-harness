from typing import List, Literal

Op = Literal["+", "-", "*", "/"]
Token = int | Op

OPERATORS = ("+", "-", "*", "/")


class MalformedExpressionError(ValueError):
    """raised when a token list is not a well formed postfix expression

    it derives from ValueError, so `except ValueError` and `except Exception` both
    catch a malformed input
    """

    def __init__(self, tokens: List[Token] | None = None) -> None:
        self.tokens = list(tokens) if tokens else []
        detail = f": {self.tokens}" if self.tokens else ""
        super().__init__(f"malformed postfix expression{detail}")


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        the tokens are scanned from left to right; every operator is applied to the last
        two numbers in front of it and those three tokens collapse into the result. the
        scan is malformed - and MalformedExpressionError is raised - unless exactly one
        number is left over once every operator has been applied.
        """

        def apply(operator: Op, first: float, second: float) -> float:
            match operator:
                case "+":
                    return first + second
                case "-":
                    return first - second
                case "*":
                    return first * second
                case _:
                    return first / second

        def parseHelp(inputs: List[Token], stack: List[float]) -> float:
            for token in inputs:
                if token in OPERATORS:
                    if len(stack) < 2:
                        # the operator has fewer than two numbers in front of it
                        raise MalformedExpressionError(inputs)
                    second = stack.pop()
                    first = stack.pop()
                    stack.append(apply(token, first, second))
                elif isinstance(token, (int, float)):
                    stack.append(token)
                else:
                    # neither an operator nor a number: the token can never collapse
                    raise MalformedExpressionError(inputs)
            if len(stack) != 1:
                # more than one number remaining, or nothing at all for empty input
                raise MalformedExpressionError(inputs)
            return stack[0]

        return parseHelp(list(inputs), [])
