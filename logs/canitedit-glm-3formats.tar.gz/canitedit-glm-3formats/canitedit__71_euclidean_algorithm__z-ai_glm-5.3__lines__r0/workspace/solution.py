def gcd(a, b):
    return abs(a) if b == 0 else gcd(b, a % b)


def lcm(a, b):
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // gcd(a, b)
