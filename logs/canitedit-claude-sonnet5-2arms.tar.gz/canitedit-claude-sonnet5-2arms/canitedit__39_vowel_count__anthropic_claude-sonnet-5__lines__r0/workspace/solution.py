import string

DIPHTHONGS = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    vowel_count = 0
    i = 0
    n = len(line)
    while i < n:
        matched_diphthong = None
        for diphthong in DIPHTHONGS:
            if line[i:i + len(diphthong)] == diphthong:
                matched_diphthong = diphthong
                break
        if matched_diphthong is not None:
            i += len(matched_diphthong)
            continue
        if line[i] in "aeiouy":
            vowel_count += 1
        i += 1
    return vowel_count
