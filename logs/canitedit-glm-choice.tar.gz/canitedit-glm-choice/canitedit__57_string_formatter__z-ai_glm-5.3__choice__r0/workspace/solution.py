import re


def concatenate_nums(message):
    """Return ``message`` with its word order changed from
    subject-verb-object to object-verb-subject.

    The subject, verb and object are separated by spaces.  Single-word parts
    ("cat chased mouse") as well as multi-word parts separated by runs of
    spaces ("the cat  chased  the mouse") are supported, and the original
    spacing between the parts is preserved.
    """
    words = message.split(" ")
    if len(words) == 3:
        # Each of the subject, verb and object is a single word.
        subject, verb, obj = words
        return f"{obj} {verb} {subject}"

    # Multi-word parts: split on runs of two or more spaces, keeping the
    # separators so that the original spacing can be reused.
    segments = re.split(r"( {2,})", message)
    parts = segments[0::2]
    separators = segments[1::2]
    if len(parts) == 3:
        subject, verb, obj = parts
        return obj + separators[1] + verb + separators[0] + subject

    # Fallback for ambiguous spacing: assume the verb is the middle word.
    words = message.split()
    if len(words) >= 3 and len(words) % 2 == 1:
        middle = len(words) // 2
        subject = " ".join(words[:middle])
        verb = words[middle]
        obj = " ".join(words[middle + 1:])
        return f"{obj} {verb} {subject}"

    return message


def format_string(name1, name2, message):
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {concatenate_nums(message)}'
    return formattedString
