import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count


def combo_count(line):
    combos = 0
    words = line.split(" ")

    for word, next_word in zip(words, words[1:]):
        if not next_word:
            continue

        ends_in_vowel = word and word[-1] in "aeiouy"
        ends_in_vm = len(word) >= 2 and word[-2] in "aeiouy" and word[-1] == "m"
        ends_in_vh = len(word) >= 2 and word[-2] in "aeiouy" and word[-1] == "h"
        starts_in_vowel = next_word[0] in "aeiouy"
        starts_in_hv = (len(next_word) >= 2 and next_word[0] == "h"
                        and next_word[1] in "aeiouy")

        if ((starts_in_vowel and (ends_in_vowel or ends_in_vm or ends_in_vh))
                or (starts_in_hv and ends_in_vm)):
            combos += 1

    return combos


def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
