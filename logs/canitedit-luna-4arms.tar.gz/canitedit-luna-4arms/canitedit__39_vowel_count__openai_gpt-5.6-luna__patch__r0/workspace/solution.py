import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    diphthongs = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]
    count = 0
    index = 0
    while index < len(line):
        matching_diphthongs = [
            diphthong for diphthong in diphthongs
            if line.startswith(diphthong, index)
        ]
        if matching_diphthongs:
            index += len(max(matching_diphthongs, key=len))
            continue
        elif line[index] in "aeiouy":
            count += 1
        index += 1
    return count
