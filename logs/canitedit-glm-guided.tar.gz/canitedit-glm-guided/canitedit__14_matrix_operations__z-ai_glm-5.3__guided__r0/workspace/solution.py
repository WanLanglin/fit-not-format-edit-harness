class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def add(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must have the same dimensions to be added")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)
    
    def subtract(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must have the same dimensions to be subtracted")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)

    def same_size(self, other) -> bool:
        """Return True if this matrix and ``other`` have the same dimensions."""
        return same_size(self.matrix, other)


def same_size(matrix1, matrix2) -> bool:
    """Return True if two matrices (Matrix instances or nested lists) share the same dimensions."""
    if isinstance(matrix1, Matrix):
        matrix1 = matrix1.matrix
    if isinstance(matrix2, Matrix):
        matrix2 = matrix2.matrix
    return len(matrix1) == len(matrix2) and all(
        len(row1) == len(row2) for row1, row2 in zip(matrix1, matrix2)
    )
