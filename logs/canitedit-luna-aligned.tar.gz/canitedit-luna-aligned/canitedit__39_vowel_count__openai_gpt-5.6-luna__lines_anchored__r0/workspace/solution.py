import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    count = 0
    diphthongs = ("aea", "ae", "oe", "ei", "ea", "ia", "io")
    line = prepare_line(line)
    index = 0
    while index < len(line):
        diphthong = next(
            (value for value in diphthongs if line.startswith(value, index)),
            None,
        )
        if diphthong:
            index += len(diphthong)
        else:
            if line[index] in "aeiouy":
                count += 1
            index += 1
    return count
