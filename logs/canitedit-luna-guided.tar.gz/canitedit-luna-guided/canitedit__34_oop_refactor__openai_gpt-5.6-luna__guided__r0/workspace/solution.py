from abc import ABC, abstractmethod


class Message(ABC):
    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Process the message and return its description."""


class TextMessage(Message):
    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        if message_type == "text":
            return TextMessage(content)
        if message_type == "image":
            return ImageMessage(content)
        raise ValueError(f"Invalid message type: {message_type}")


def process_message(message, message_type):
    """Process a message using the factory (kept for backwards compatibility)."""
    return MessageFactory.get_message(message_type, message).process()
