from typing import List, Literal, Union

Op = Literal["+", "-", "*", "/"]
Token = Union[int, Op]

OPERATORS = ("+", "-", "*", "/")


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result.

        The expression is reduced by scanning the sequence from the start until an
        operator is found, applying that operator to the two numbers in front of it
        and replacing the two numbers and the operator with the result. This is
        repeated from the start on the new sequence until no operator is left.

        An Exception is raised when the input is malformed, that is when this
        process does not leave exactly one number behind, or when an operator is
        reached before two numbers are available to apply it to.
        """

        def apply(op: Op, left, right):
            if op == "+":
                return left + right
            if op == "-":
                return left - right
            if op == "*":
                return left * right
            if op == "/":
                return left / right
            raise Exception("unknown operator: {!r}".format(op))

        # work on a copy so the caller's list is not modified
        tokens = list(inputs)

        while True:
            # 1. scan down the list until there is an operator
            operator_index = next(
                (index for index, token in enumerate(tokens) if token in OPERATORS),
                None,
            )

            # 3. repeat this process ... until there are no operators left
            if operator_index is None:
                if len(tokens) != 1:
                    raise Exception("malformed postfix expression: {!r}".format(inputs))
                return tokens[0]

            # the operator is applied to the two numbers in front of it
            if operator_index < 2:
                raise Exception("malformed postfix expression: {!r}".format(inputs))

            # 2. apply the operator to the last two numbers ...
            result = apply(
                tokens[operator_index],
                tokens[operator_index - 2],
                tokens[operator_index - 1],
            )

            # ... and replace them (and the operator) with the result
            tokens[operator_index - 2 : operator_index + 1] = [result]


def parse(inputs: List[Token]) -> float:
    """computes a postfix expression; raises an Exception when the input is malformed"""
    return PostfixParser().parse(inputs)
