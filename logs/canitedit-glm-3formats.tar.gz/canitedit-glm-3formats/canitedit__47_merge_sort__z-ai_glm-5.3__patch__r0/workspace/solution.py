from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    if len(lst) > 1:
        mid = len(lst) // 2
        L = lst[:mid]
        R = lst[mid:]
        merge_sort(L)
        merge_sort(R)

        # Early termination: if the largest element of the left sub-array is
        # not greater than the smallest element of the right sub-array, then
        # both halves are already ordered relative to each other (every
        # element of L precedes every element of R) and the merge step can be
        # skipped entirely. This avoids the O(n) comparisons and copies of a
        # merge whenever a sorted subsequence straddles the midpoint, so
        # partially sorted inputs cost close to O(n) work instead of O(n log n).
        # Using <= keeps the sort stable: equal keys stay in left-before-right
        # order, exactly as the merge below would place them.
        if L[-1] <= R[0]:
            return lst

        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                lst[k] = L[i]
                i += 1
            else:
                lst[k] = R[j]
                j += 1
            k += 1
        while i < len(L):
            lst[k] = L[i]
            i += 1
            k += 1

        # When the left sub-array is exhausted, the remaining elements of R
        # are already sitting in their final positions (k == mid + j), so the
        # tail-copy loop for R can be skipped as well.

    return lst
