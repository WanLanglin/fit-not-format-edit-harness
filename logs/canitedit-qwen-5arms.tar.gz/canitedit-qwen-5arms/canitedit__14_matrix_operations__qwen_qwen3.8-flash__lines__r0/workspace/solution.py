class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def same_size(self, other) -> bool:
        """Return True when both matrices have the same dimensions.

        Usable as an instance method (``a.same_size(b)``) or unbound
        (``Matrix.same_size(a, b)``), with ``Matrix`` objects or raw lists.
        """
        a = getattr(self, "matrix", self)
        b = getattr(other, "matrix", other)
        if len(a) != len(b):
            return False
        return all(len(row_a) == len(row_b) for row_a, row_b in zip(a, b))

    def add(self, other):
        if not Matrix.same_size(self, other):
            raise ValueError("Matrices must be the same size to be added")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)
    
    def subtract(self, other):
        if not Matrix.same_size(self, other):
            raise ValueError("Matrices must be the same size to be subtracted")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)
