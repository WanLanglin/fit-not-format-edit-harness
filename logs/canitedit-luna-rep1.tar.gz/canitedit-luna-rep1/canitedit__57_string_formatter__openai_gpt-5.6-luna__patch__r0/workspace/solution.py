def concatenate_nums(message):
    """Return an SVO message with its parts arranged as OVS.

    The examples use two spaces between the subject, verb, and object, while
    allowing ordinary spaces inside each part.  Keeping the separators when
    rearranging the parts also keeps the message's formatting intact.
    """
    parts = message.split("  ")
    if len(parts) == 3:
        return "  ".join((parts[2], parts[1], parts[0]))

    # For a message made up of one word for each part, the separators are
    # single spaces instead.
    words = message.split(" ")
    if len(words) == 3:
        return " ".join((words[2], words[1], words[0]))

    return message


def format_string(name1, name2, message):
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {concatenate_nums(message)}'
    return formattedString
