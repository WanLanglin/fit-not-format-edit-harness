import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    vowel_count = 0
    line = prepare_line(line)
    diphthongs = ("aea", "ae", "oe", "ei", "ea", "ia", "io")
    position = 0
    while position < len(line):
        diphthong = next(
            (diphthong for diphthong in diphthongs if line.startswith(diphthong, position)),
            None,
        )
        if diphthong:
            position += len(diphthong)
            continue
        letter = line[position]
        if letter in "aeiouy":
            vowel_count += 1
        position += 1
    return vowel_count
