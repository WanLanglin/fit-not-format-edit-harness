from solution import Matrix

# 2x2
m = Matrix([[1, 2], [3, 4]])
assert m.determinant() == 1*4 - 2*3 == -2

# 3x3
m = Matrix([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
assert m.determinant() == 0

m = Matrix([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
assert m.determinant() == 1

# non-square -> AssertionError
for rows, cols in [(2, 3), (3, 2), (4, 3), (1, 2), (2, 1)]:
    content = [[0]*cols for _ in range(rows)]
    try:
        Matrix(content).determinant()
        raise SystemExit(f'FAIL: no error for {rows}x{cols}')
    except AssertionError:
        pass
    except Exception as e:
        raise SystemExit(f'FAIL: wrong error {type(e).__name__} for {rows}x{cols}')

# square non-2/3 -> NotImplementedError
for n in [1, 4, 5]:
    content = [[0]*n for _ in range(n)]
    try:
        Matrix(content).determinant()
        raise SystemExit(f'FAIL: no error for {n}x{n}')
    except NotImplementedError:
        pass
    except Exception as e:
        raise SystemExit(f'FAIL: wrong error {type(e).__name__} for {n}x{n}')

print('ALL OK')
