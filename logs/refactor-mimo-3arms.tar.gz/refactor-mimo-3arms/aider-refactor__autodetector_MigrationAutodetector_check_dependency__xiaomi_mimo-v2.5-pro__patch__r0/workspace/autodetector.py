import copy
@@ -19,6 +19,72 @@
 
 
+def check_dependency(operation, dependency):
+    """
+    Return True if the given operation depends on the given dependency,
+    False otherwise.
+    """
+    # Created model
+    if dependency[2] is None and dependency[3] is True:
+        return (
+            isinstance(operation, operations.CreateModel)
+            and operation.name_lower == dependency[1].lower()
+        )
+    # Created field
+    elif dependency[2] is not None and dependency[3] is True:
+        return (
+            isinstance(operation, operations.CreateModel)
+            and operation.name_lower == dependency[1].lower()
+            and any(dependency[2] == x for x, y in operation.fields)
+        ) or (
+            isinstance(operation, operations.AddField)
+            and operation.model_name_lower == dependency[1].lower()
+            and operation.name_lower == dependency[2].lower()
+        )
+    # Removed field
+    elif dependency[2] is not None and dependency[3] is False:
+        return (
+            isinstance(operation, operations.RemoveField)
+            and operation.model_name_lower == dependency[1].lower()
+            and operation.name_lower == dependency[2].lower()
+        )
+    # Removed model
+    elif dependency[2] is None and dependency[3] is False:
+        return (
+            isinstance(operation, operations.DeleteModel)
+            and operation.name_lower == dependency[1].lower()
+        )
+    # Field being altered
+    elif dependency[2] is not None and dependency[3] == "alter":
+        return (
+            isinstance(operation, operations.AlterField)
+            and operation.model_name_lower == dependency[1].lower()
+            and operation.name_lower == dependency[2].lower()
+        )
+    # order_with_respect_to being unset for a field
+    elif dependency[2] is not None and dependency[3] == "order_wrt_unset":
+        return (
+            isinstance(operation, operations.AlterOrderWithRespectTo)
+            and operation.name_lower == dependency[1].lower()
+            and (operation.order_with_respect_to or "").lower()
+            != dependency[2].lower()
+        )
+    # Field is removed and part of an index/unique_together
+    elif dependency[2] is not None and dependency[3] == "foo_together_change":
+        return (
+            isinstance(
+                operation,
+                (operations.AlterUniqueTogether, operations.AlterIndexTogether),
+            )
+            and operation.name_lower == dependency[1].lower()
+        )
+    # Unknown dependency. Raise an error.
+    else:
+        raise ValueError("Can't handle dependency %r" % (dependency,))
+
+
 class MigrationAutodetector:
@@ -306,7 +372,7 @@
                             for other_operation in self.generated_operations.get(
                                 dep[0], []
                             ):
-                                if self.check_dependency(other_operation, dep):
+                                if check_dependency(other_operation, dep):
                                     deps_satisfied = False
@@ -395,7 +461,7 @@
                     if dep[0] == app_label:
                         for op2 in ops:
-                            if self.check_dependency(op2, dep):
+                            if check_dependency(op2, dep):
                                 dependency_graph[op].add(op2)
@@ -421,68 +487,6 @@
 
-    def check_dependency(self, operation, dependency):
-        """
-        Return True if the given operation depends on the given dependency,
-        False otherwise.
-        """
-        # Created model
-        if dependency[2] is None and dependency[3] is True:
-            return (
-                isinstance(operation, operations.CreateModel)
-                and operation.name_lower == dependency[1].lower()
-            )
-        # Created field
-        elif dependency[2] is not None and dependency[3] is True:
-            return (
-                isinstance(operation, operations.CreateModel)
-                and operation.name_lower == dependency[1].lower()
-                and any(dependency[2] == x for x, y in operation.fields)
-            ) or (
-                isinstance(operation, operations.AddField)
-                and operation.model_name_lower == dependency[1].lower()
-                and operation.name_lower == dependency[2].lower()
-            )
-        # Removed field
-        elif dependency[2] is not None and dependency[3] is False:
-            return (
-                isinstance(operation, operations.RemoveField)
-                and operation.model_name_lower == dependency[1].lower()
-                and operation.name_lower == dependency[2].lower()
-            )
-        # Removed model
-        elif dependency[2] is None and dependency[3] is False:
-            return (
-                isinstance(operation, operations.DeleteModel)
-                and operation.name_lower == dependency[1].lower()
-            )
-        # Field being altered
-        elif dependency[2] is not None and dependency[3] == "alter":
-            return (
-                isinstance(operation, operations.AlterField)
-                and operation.model_name_lower == dependency[1].lower()
-                and operation.name_lower == dependency[2].lower()
-            )
-        # order_with_respect_to being unset for a field
-        elif dependency[2] is not None and dependency[3] == "order_wrt_unset":
-            return (
-                isinstance(operation, operations.AlterOrderWithRespectTo)
-                and operation.name_lower == dependency[1].lower()
-                and (operation.order_with_respect_to or "").lower()
-                != dependency[2].lower()
-            )
-        # Field is removed and part of an index/unique_together
-        elif dependency[2] is not None and dependency[3] == "foo_together_change":
-            return (
-                isinstance(
-                    operation,
-                    (operations.AlterUniqueTogether, operations.AlterIndexTogether),
-                )
-                and operation.name_lower == dependency[1].lower()
-            )
-        # Unknown dependency. Raise an error.
-        else:
-            raise ValueError("Can't handle dependency %r" % (dependency,))
-
     def add_operation(self, app_label, operation, dependencies=None, beginning=False):
*** End Patch
