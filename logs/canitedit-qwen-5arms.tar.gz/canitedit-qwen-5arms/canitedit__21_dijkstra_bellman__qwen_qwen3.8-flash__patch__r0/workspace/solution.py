import heapq


class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.

        Negative weights are supported: graphs containing them are solved with the
        Bellman-Ford algorithm, which raises ValueError when a negative weight cycle
        is reachable from `start`. Graphs whose weights are all non-negative keep
        using the faster Dijkstra implementation.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        if self._has_negative_weights():
            return self._bellman_ford(start)
        return self._dijkstra(start)

    def _has_negative_weights(self):
        return any(
            weight < 0
            for neighbors in self.edges.values()
            for _, weight in neighbors
        )

    def _dijkstra(self, start):
        """Single-source shortest paths, for graphs without negative weights."""
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0
        unvisited_nodes = [(0, start)]

        while unvisited_nodes:
            current_dist, current_node = heapq.heappop(unvisited_nodes)

            if current_dist > shortest_path[current_node]:
                continue

            for neighbor, weight in self.edges[current_node]:
                distance = current_dist + weight

                if distance < shortest_path[neighbor]:
                    shortest_path[neighbor] = distance
                    heapq.heappush(unvisited_nodes, (distance, neighbor))

        return shortest_path

    def _bellman_ford(self, start):
        """Single-source shortest paths supporting negative weights."""
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        edge_list = [
            (from_node, to_node, weight)
            for from_node, neighbors in self.edges.items()
            for to_node, weight in neighbors
        ]

        # |V| - 1 rounds of relaxation settle every shortest path as long as no
        # negative cycle is involved. Stop early once nothing changes.
        for _ in range(max(len(self.nodes) - 1, 0)):
            changed = False
            for from_node, to_node, weight in edge_list:
                if shortest_path[from_node] == float('infinity'):
                    continue
                distance = shortest_path[from_node] + weight
                if distance < shortest_path[to_node]:
                    shortest_path[to_node] = distance
                    changed = True
            if not changed:
                break

        # If an edge can still be relaxed, a negative cycle is reachable from start.
        for from_node, to_node, weight in edge_list:
            if shortest_path[from_node] == float('infinity'):
                continue
            if shortest_path[from_node] + weight < shortest_path[to_node]:
                raise ValueError(
                    'Graph contains a negative weight cycle reachable from the start node'
                )

        return shortest_path
