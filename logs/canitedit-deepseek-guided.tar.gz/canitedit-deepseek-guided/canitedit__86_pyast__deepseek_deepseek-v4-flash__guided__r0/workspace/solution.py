import ast


def _collect_names(nodes):
    """Collect all Name ids from a list of nodes, recursing into Tuples."""
    names = []
    for node in nodes:
        if isinstance(node, ast.Name):
            names.append(node.id)
        elif isinstance(node, ast.Tuple):
            names.extend(_collect_names(node.elts))
    return names


def _arg_names(arguments):
    """Collect all argument names from an ast.arguments node."""
    names = []
    for arg in arguments.posonlyargs:
        names.append(arg.arg)
    for arg in arguments.args:
        names.append(arg.arg)
    if arguments.vararg:
        names.append(arguments.vararg.arg)
    for arg in arguments.kwonlyargs:
        names.append(arg.arg)
    if arguments.kwarg:
        names.append(arguments.kwarg.arg)
    return names


class UsageCounter(ast.NodeVisitor):
    """
    Counts the usages of each identifier in the given AST.
    An usage does not count the definition or assignment itself;
    only identifiers that are used after their definition/assignment are counted.
    NOTE: This class does not handle the scoping rules of Python;
    it simply counts the usages based on the name of the identifiers.
    It also only supports identifiers defined in either a function or assignment operation.
    """

    def __init__(self):
        self.usages = {}

    def visit_Name(self, node):
        if node.id in self.usages:
            self.usages[node.id] += 1
            self.generic_visit(node)

    def visit_FunctionDef(self, node):
        names = [node.name] + _arg_names(node.args)
        for name in names:
            if name not in self.usages:
                self.usages[name] = 0
        self.generic_visit(node)

    def visit_Assign(self, node):
        defined = _collect_names(node.targets)
        for name in defined:
            if name not in self.usages:
                self.usages[name] = 0

        self.generic_visit(node)
        for name in defined:
            self.usages[name] -= 1
