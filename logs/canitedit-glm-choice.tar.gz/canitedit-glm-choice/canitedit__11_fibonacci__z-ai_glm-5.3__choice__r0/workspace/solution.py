class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int) -> list:
        """Return the next ``n`` Fibonacci numbers without advancing the iterator.

        The first element is what ``__next__`` would return if called now.
        The object's internal state is left untouched.
        """
        prev_prev = getattr(self, "prev_prev", 0)
        prev = getattr(self, "prev", 1)
        result = []
        for _ in range(max(n, 0)):
            prev_prev, prev = prev, prev_prev + prev
            result.append(prev)
        return result
