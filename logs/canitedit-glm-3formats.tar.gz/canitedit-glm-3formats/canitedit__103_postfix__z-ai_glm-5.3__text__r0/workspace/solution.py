from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        Raises an Exception when the input is malformed, i.e. when repeatedly applying
        each operator to the two numbers preceding it does not reduce the sequence to
        exactly one number.
        """

        def apply(operator: Op, left: float, right: float) -> float:
            match operator:
                case "+":
                    return left + right
                case "-":
                    return left - right
                case "*":
                    return left * right
                case "/":
                    return left / right

        sequence: List[float | Op] = list(inputs)
        index = 0
        while index < len(sequence):
            token = sequence[index]
            if token in ("+", "-", "*", "/"):
                if index < 2:
                    raise Exception("malformed input: not enough operands")
                sequence[index - 2 : index + 1] = [
                    apply(token, sequence[index - 2], sequence[index - 1])
                ]
                # restart the scan from the start of the new sequence
                index = 0
            else:
                index += 1

        if len(sequence) != 1:
            raise Exception(
                "malformed input: "
                f"{len(sequence)} numbers remaining instead of 1"
            )
        return float(sequence[0])
