class Comparators:
    """
    A class for that allows for custom comparator actions that work in conjuction with Python's default sorted function
    Example usage: `sorted(lorem_ipsum, key=Comparators.by_length)`
    """

    def by_length(obj):
        """Comparing by length of object"""
        return len(obj)

    def by_num_vowels(obj):
        """Comparing by the number of vowels"""
        vowels = "aeiou"
        return sum(1 for char in obj if char.lower() in vowels)

    def by_numerical_value(obj):
        """Comparing by the numerical value of the object"""
        return obj

    def by_word_count(obj):
        """Comparison by the number of words in the object"""
        return len(obj.split())

    def sort_with_tiebreaker(items, primary, tiebreaker):
        """
        Sort a list of items by a primary sorting method, using a tiebreaker
        sorting method for items that tie under the primary method.

        Example usage:
        `Comparators.sort_with_tiebreaker(lorem_ipsum, Comparators.by_length, Comparators.by_num_vowels)`
        """
        # Python's sort is stable, so sorting by the tiebreaker first and then
        # by the primary key leaves tied items ordered by the tiebreaker.
        return sorted(sorted(items, key=tiebreaker), key=primary)
