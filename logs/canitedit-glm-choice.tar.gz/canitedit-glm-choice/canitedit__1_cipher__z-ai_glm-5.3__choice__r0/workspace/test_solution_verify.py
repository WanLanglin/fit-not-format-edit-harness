from solution import Cipher


def test_caesar_cipher_creates_and_stores_shifted_alphabet():
    c = Cipher()

    assert 'caesar4' not in c.ciphers
    returned = c.caesar_cipher(4)

    assert 'caesar4' in c.ciphers
    assert c.ciphers['caesar4'] is returned


def test_caesar_cipher_shifts_each_character():
    c = Cipher()
    c.caesar_cipher(4)

    expected = {
        'a': 'e', 'b': 'f', 'c': 'g', 'd': 'h', 'e': 'i', 'f': 'j', 'g': 'k',
        'h': 'l', 'i': 'm', 'j': 'n', 'k': 'o', 'l': 'p', 'm': 'q', 'n': 'r',
        'o': 's', 'p': 't', 'q': 'u', 'r': 'v', 's': 'w', 't': 'x', 'u': 'y',
        'v': 'z', 'w': 'a', 'x': 'b', 'y': 'c', 'z': 'd'}
    assert c.ciphers['caesar4'] == expected
    assert c.translate('caesar4', 'abc') == 'efg'
    assert c.translate('caesar4', 'wxyz') == 'abcd'


def test_caesar_cipher_wraps_for_other_shifts():
    c = Cipher()
    c.caesar_cipher(-1)
    assert c.ciphers['caesar-1']['a'] == 'z'

    c.caesar_cipher(30)
    assert c.ciphers['caesar30']['a'] == 'e'


def test_caesar_cipher_keeps_other_ciphers_and_honours_alphabet():
    c = Cipher()
    c.caesar_cipher(4)
    assert 'default' in c.ciphers
    assert c.ciphers['default']['a'] == 'b'

    c2 = Cipher()
    c2.alphabet = ['a', 'b', 'c']
    c2.caesar_cipher(1)
    assert c2.ciphers['caesar1'] == {'a': 'b', 'b': 'c', 'c': 'a'}
