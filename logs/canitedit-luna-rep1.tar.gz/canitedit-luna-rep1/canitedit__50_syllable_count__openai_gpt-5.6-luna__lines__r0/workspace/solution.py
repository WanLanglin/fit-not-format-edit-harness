import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    # A combo is a vowel transition across a word boundary.  The m/h
    # variants are included because they are part of the preceding word's
    # ending (or, for the last case, the following word's beginning).
    vowels = "aeiouy"
    words = line.split(" ")
    combos = 0
    for word, next_word in zip(words, words[1:]):
        if not word or not next_word:
            continue
        if next_word[0] in vowels:
            if word[-1] in vowels:
                combos += 1
            elif len(word) >= 2 and word[-2] in vowels and word[-1] in "mh":
                combos += 1
        elif (word.endswith("am") or word.endswith("em") or
              word.endswith("im") or word.endswith("om") or
              word.endswith("um") or word.endswith("ym")):
            if len(next_word) >= 2 and next_word[0] == "h" and next_word[1] in vowels:
                combos += 1

    syllable_count += vowel_count(line) + combos

    return syllable_count
