import csv as csv_module


def header(csv: str) -> list[str]:
    """Return the columns in the first row of a CSV string."""
    return next(csv_module.reader(csv.splitlines()), [])


class CSVParser:
    def __init__(self, csv: str):
        self.csv = csv

    def contents(self) -> list[list[str]]:
        lines = self.csv.split("\n")
        output = []
        for line in lines:
            output.append(line.split(","))
        return output
