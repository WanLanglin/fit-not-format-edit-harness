from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        tokens = list(inputs)
        operators = {"+", "-", "*", "/"}

        while True:
            operator_index = next(
                (index for index, token in enumerate(tokens) if token in operators),
                None,
            )
            if operator_index is None:
                if len(tokens) != 1:
                    raise Exception("Malformed postfix expression")
                return tokens[0]

            if operator_index < 2 or any(
                not isinstance(token, (int, float))
                for token in tokens[operator_index - 2 : operator_index]
            ):
                raise Exception("Malformed postfix expression")

            left, right = tokens[operator_index - 2 : operator_index]
            operator = tokens[operator_index]
            match operator:
                case "+":
                    result = left + right
                case "-":
                    result = left - right
                case "*":
                    result = left * right
                case "/":
                    result = left / right
            tokens[operator_index - 2 : operator_index + 1] = [result]
