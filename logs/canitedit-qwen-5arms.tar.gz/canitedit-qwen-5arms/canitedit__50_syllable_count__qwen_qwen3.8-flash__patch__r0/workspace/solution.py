import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def ends_word_with_vowel_or_vowel_m(word):
    """True if a word can open a 'combo': it ends in a vowel, or in vowel + 'm'."""
    if not word:
        return False
    if word[-1] in "aeiouy":
        return True
    return len(word) > 1 and word[-1] == "m" and word[-2] in "aeiouy"

def starts_word_with_vowel_or_h_vowel(word):
    """True if a word can close a 'combo': it starts with a vowel, or with 'h' + vowel."""
    if not word:
        return False
    if word[0] in "aeiouy":
        return True
    return len(word) > 1 and word[0] == "h" and word[1] in "aeiouy"

def count_combos(line):
    """Count 'combo's (elisions) between consecutive words of an already prepared line."""
    words = [word for word in line.split(" ") if word]
    combos = 0
    for previous, following in zip(words, words[1:]):
        if ends_word_with_vowel_or_vowel_m(previous) and starts_word_with_vowel_or_h_vowel(following):
            combos += 1
    return combos

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    # vowels minus the number of 'combo' (each combo fuses two vowels into one syllable)
    syllable_count += vowel_count(line) - count_combos(line)

    return syllable_count
