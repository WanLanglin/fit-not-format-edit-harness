import re


def concatenate_nums(message):
    """Return `message` with its word order changed from
    subject-verb-object to object-verb-subject.

    `message` is assumed to be made up only of a subject, a verb and an
    object, separated by spaces. The spacing that separates the three parts
    is preserved exactly as it appeared in `message`.
    """
    # Runs of two or more spaces separate the subject, the verb and the
    # object, each of which may itself contain single spaces
    # (e.g. "the cat  chased  the mouse").
    pieces = re.split(r'( {2,})', message)
    if len(pieces) == 5 and pieces[0] and pieces[4]:
        # pieces == [subject, separator, verb, separator, object]
        subject, first_separator, verb, second_separator, obj = pieces
        return obj + first_separator + verb + second_separator + subject

    # Subject, verb and object that are single words separated by single
    # spaces (e.g. "cat chased mouse").
    words = message.split(' ')
    if len(words) == 3:
        subject, verb, obj = words
        return f'{obj} {verb} {subject}'

    return message


def format_string(name1, name2, message):
    reordered_message = concatenate_nums(message)
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {reordered_message}'
    return formattedString
