from solution import BPETokenizerTrainer


def run(training_set: str, max_num_merges: int, max_num_tokens=None):
    trainer = BPETokenizerTrainer(training_set, max_num_merges, max_num_tokens)
    trainer.train()
    return trainer.get_lookup_table()


# Baseline: no cap. Merges continue while more than one symbol remains.
t = run("aaabdaaabac", 10)
assert len(t) == 11, t  # 4 base chars + 7 merges

# Cap reached mid-training.
t = run("aaabdaaabac", 10, max_num_tokens=5)
assert len(t) == 5, t

# Cap equal to the initial vocab (4 base chars) -> no merges.
t = run("aaabdaaabac", 10, max_num_tokens=4)
assert len(t) == 4, t

# Cap smaller than the initial vocab: table is never truncated, only growth stops.
t = run("aaabdaaabac", 10, max_num_tokens=1)
assert len(t) == 4, t

# Old two-arg call still works.
t = run("aaabdaaabac", 2)
assert len(t) == 6, t

print("all assertions passed")
