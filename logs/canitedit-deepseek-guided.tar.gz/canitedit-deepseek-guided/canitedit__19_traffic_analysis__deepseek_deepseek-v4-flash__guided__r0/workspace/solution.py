from typing import Optional, Literal
from abc import ABC, abstractmethod


class Visitor(ABC):
    """
    A visitor.
    """

    @abstractmethod
    def visit(self, city_intersection: 'CityIntersection'):
        """
        Visit a city intersection.
        """
        pass


class City:
    """
    A city with a name, population, and typical traffic. The traffic is a
    measure of typical vehicular volume.
    """

    def __init__(self, name: str, population: int, traffic: float):
        self.name = name
        self.population = population
        self.traffic = traffic


IntersectionType = Literal[
    'FourWayIntersection',
    'ThreeWayIntersection',
    'Roundabout',
]


class CityIntersection:
    """
    A city intersection. Each intersection has a type and a traffic volume.
    """

    def __init__(
        self,
        name: str,
        type: IntersectionType,
        traffic_volume: float,
        children: Optional[list['CityIntersection']] = None,
    ):
        self.name = name
        self.type = type
        self.traffic_volume = traffic_volume
        self.children = children if children is not None else []

    def accept(self, visitor: Visitor):
        visitor.visit(self)


class TrafficAnalysisVisitor(Visitor):
    """
    Test the traffic analysis for the various types of intersections.
    """

    def visit(self, city_intersection: CityIntersection):
        """
        Perform traffic analysis on a city intersection and its children.

        Returns an adjusted traffic volume based on the intersection type and
        recursively visits the children of the intersection.
        """
        if city_intersection.type == 'FourWayIntersection':
            traffic_volume = city_intersection.traffic_volume
            adjusted_traffic = traffic_volume * 1.2
            print(
                'FourWayIntersection: '
                f'{city_intersection.name} adjusted traffic: {adjusted_traffic}'
            )
            return {
                'type': city_intersection.type,
                'name': city_intersection.name,
                'traffic_volume': adjusted_traffic,
            }
        elif city_intersection.type == 'ThreeWayIntersection':
            traffic_volume = city_intersection.traffic_volume
            adjusted_traffic = traffic_volume * 1.1
            print(
                'ThreeWayIntersection: '
                f'{city_intersection.name} adjusted traffic: {adjusted_traffic}'
            )
            return {
                'type': city_intersection.type,
                'name': city_intersection.name,
                'traffic_volume': adjusted_traffic,
            }
        elif city_intersection.type == 'Roundabout':
            traffic_volume = city_intersection.traffic_volume
            adjusted_traffic = traffic_volume * 0.7
            print(
                'Roundabout: '
                f'{city_intersection.name} adjusted traffic: {adjusted_traffic}'
            )
            return {
                'type': city_intersection.type,
                'name': city_intersection.name,
                'traffic_volume': adjusted_traffic,
            }
        else:
            raise ValueError(f'Unsupported intersection type: {city_intersection.type}')
