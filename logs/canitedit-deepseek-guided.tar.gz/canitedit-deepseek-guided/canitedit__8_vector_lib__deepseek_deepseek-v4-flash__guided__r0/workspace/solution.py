from abc import ABC, abstractmethod

class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass

class MyVector(Vector):
    def __init__(self, *args: int):
        super().__init__(*args)

    def _check_same_length(self, other):
        if len(self.vals) != len(other.vals):
            raise ValueError("Vectors must have the same length")

    def manhattan_distance(self, other) -> float:
        self._check_same_length(other)
        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def cosine_similarity(self, other) -> float:
        self._check_same_length(other)
        dot = sum(a * b for a, b in zip(self.vals, other.vals))
        mag_self = sum(a * a for a in self.vals) ** 0.5
        mag_other = sum(b * b for b in other.vals) ** 0.5
        if mag_self == 0 or mag_other == 0:
            raise ValueError("Vectors must have non-zero magnitude")
        return float(dot / (mag_self * mag_other))
