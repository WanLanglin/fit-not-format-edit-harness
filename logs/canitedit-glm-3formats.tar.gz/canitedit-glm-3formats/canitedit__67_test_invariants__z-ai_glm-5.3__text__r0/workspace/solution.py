class Employer:
    """
    Represents an entity that employs workers.
    """

    def __init__(self, name, funds):
        self.name = name
        self.funds = funds


class Worker:
    """
    Represents a person who does work for an employer.
    Name should be "[first name] [last name]" and pay 
    should be positive.
    """

    def __init__(self, name, pay, company):
        self.name = name
        self.pay = pay
        self.company = company
        self.money = 0

    def lastName(self):
        """
        Returns the last name of the worker.
        """
        return self.name.split()[-1]

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay
        self.company.funds -= self.pay

    def giveRaise(self, percent):
        """
        Gives the worker a raise in pay, given as a percentage of
        the current pay.
        """
        self.pay *= (1.0 + percent)


class PublicWorker(Worker):
    """
    Represents a worker who works for the government.
    People who work for the government are special
    because they are paid with public funds, which
    are virtually unlimited because of public debt.
    """

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay


def test_worker_invariants(w: Worker):
    """
    Check, using assert, every invariant that must hold for the Worker w.

    * w.name is a first name and a last name separated by a space;
    * w.pay is non-negative (and since money starts at 0 and only ever
      grows by non-negative amounts of pay, w.money is non-negative too);
    * w.lastName() returns the last name of the worker;
    * givePay() adds exactly w.pay to the worker's money, subtracts exactly
      w.pay from the company's funds, and changes nothing else;
    * giveRaise(percent) multiplies the pay by (1.0 + percent) and changes
      nothing else.

    The checks exercise the worker's methods, but the worker and its
    company are left exactly as they were found.
    """
    # None until the current state has been successfully saved below.
    saved = None
    try:
        # Remember the current state so that it can be restored at the end.
        saved = (w.pay, w.money, w.company.funds)

        # The name must be "[first name] [last name]".
        name_parts = w.name.split()
        assert len(name_parts) == 2, (
            "name must be a first name and a last name separated by a "
            "space, got %r" % (w.name,)
        )

        # The pay must be non-negative.
        assert w.pay >= 0, "pay must be non-negative, got %r" % (w.pay,)

        # The money must be non-negative.
        assert w.money >= 0, (
            "money must be non-negative, got %r" % (w.money,)
        )

        # lastName() must return the last name.
        assert w.lastName() == name_parts[-1], (
            "lastName() must return the last name, got %r" % (w.lastName(),)
        )

        # givePay() must move exactly the pay from the company's funds into
        # the worker's money (and change nothing else).  Known, non-zero
        # starting values are used so that every effect is observable.
        test_pay, test_money, test_funds = 100, 40, 700
        w.pay, w.money, w.company.funds = test_pay, test_money, test_funds
        w.givePay()
        assert w.pay == test_pay, "givePay() must not change the pay"
        assert w.money == test_money + test_pay, (
            "givePay() must add exactly the pay to the worker's money"
        )
        assert w.company.funds == test_funds - test_pay, (
            "givePay() must subtract exactly the pay from the company's funds"
        )

        # giveRaise() must multiply the pay by (1.0 + percent) (and change
        # nothing else).
        for percent in (0.1, 0.5):
            pay_before = w.pay
            w.giveRaise(percent)
            assert w.pay == pay_before * (1.0 + percent), (
                "giveRaise(%r) must multiply the pay by (1.0 + percent)"
                % (percent,)
            )
            assert w.money == test_money + test_pay, (
                "giveRaise() must not change the worker's money"
            )
            assert w.company.funds == test_funds - test_pay, (
                "giveRaise() must not change the company's funds"
            )
    except AssertionError:
        raise
    except Exception as exc:
        # A method that misbehaves by raising is an invariant violation too.
        raise AssertionError(
            "checking the Worker invariants raised %r" % (exc,)
        )
    finally:
        if saved is not None:
            w.pay, w.money, w.company.funds = saved


def test_public_worker_invariants(w: PublicWorker):
    """
    Check, using assert, every invariant that must hold for the
    PublicWorker w.

    * w.name is a first name and a last name separated by a space;
    * w.pay is non-negative (and so w.money is non-negative too);
    * w.lastName() returns the last name of the worker;
    * givePay() adds exactly w.pay to the worker's money, leaves the
      company's funds untouched (public funds are unlimited), and changes
      nothing else;
    * giveRaise(percent) multiplies the pay by (1.0 + percent) and changes
      nothing else.

    The checks exercise the worker's methods, but the worker and its
    company are left exactly as they were found.
    """
    # None until the current state has been successfully saved below.
    saved = None
    try:
        # Remember the current state so that it can be restored at the end.
        saved = (w.pay, w.money, w.company.funds)

        # The name must be "[first name] [last name]".
        name_parts = w.name.split()
        assert len(name_parts) == 2, (
            "name must be a first name and a last name separated by a "
            "space, got %r" % (w.name,)
        )

        # The pay must be non-negative.
        assert w.pay >= 0, "pay must be non-negative, got %r" % (w.pay,)

        # The money must be non-negative.
        assert w.money >= 0, (
            "money must be non-negative, got %r" % (w.money,)
        )

        # lastName() must return the last name.
        assert w.lastName() == name_parts[-1], (
            "lastName() must return the last name, got %r" % (w.lastName(),)
        )

        # givePay() must add exactly the pay to the worker's money; because a
        # PublicWorker is paid out of unlimited public funds, the company's
        # funds must not change.  Known, non-zero starting values are used
        # so that every effect is observable.
        test_pay, test_money, test_funds = 100, 40, 700
        w.pay, w.money, w.company.funds = test_pay, test_money, test_funds
        w.givePay()
        assert w.pay == test_pay, "givePay() must not change the pay"
        assert w.money == test_money + test_pay, (
            "givePay() must add exactly the pay to the worker's money"
        )
        assert w.company.funds == test_funds, (
            "givePay() must not change the company's funds, because a "
            "PublicWorker is paid from unlimited public funds"
        )

        # giveRaise() (inherited from Worker) must multiply the pay by
        # (1.0 + percent) (and change nothing else).
        for percent in (0.1, 0.5):
            pay_before = w.pay
            w.giveRaise(percent)
            assert w.pay == pay_before * (1.0 + percent), (
                "giveRaise(%r) must multiply the pay by (1.0 + percent)"
                % (percent,)
            )
            assert w.money == test_money + test_pay, (
                "giveRaise() must not change the worker's money"
            )
            assert w.company.funds == test_funds, (
                "giveRaise() must not change the company's funds"
            )
    except AssertionError:
        raise
    except Exception as exc:
        # A method that misbehaves by raising is an invariant violation too.
        raise AssertionError(
            "checking the PublicWorker invariants raised %r" % (exc,)
        )
    finally:
        if saved is not None:
            w.pay, w.money, w.company.funds = saved
