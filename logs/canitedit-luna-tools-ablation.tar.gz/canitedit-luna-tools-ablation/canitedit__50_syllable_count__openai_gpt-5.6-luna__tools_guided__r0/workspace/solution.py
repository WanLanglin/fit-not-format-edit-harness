import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def _combo_count(line):
    """Return the number of vowel combinations across word boundaries."""
    vowels = "aeiouy"
    words = line.split(" ")
    combo_count = 0

    for first, second in zip(words, words[1:]):
        if not first or not second:
            continue

        second_starts_with_vowel = second[0] in vowels
        if (first[-1] in vowels and second_starts_with_vowel) or \
                (len(first) >= 2 and first[-2] in vowels and
                 first[-1] in "mh" and second_starts_with_vowel) or \
                (len(first) >= 2 and first[-2] in vowels and
                 first[-1] == "m" and len(second) >= 2 and
                 second[0] == "h" and second[1] in vowels):
            combo_count += 1

    return combo_count


def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count - _combo_count(line)


def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    combo_count = _combo_count(line)
    syllable_count += vowel_count(line)
    syllable_count += combo_count

    return syllable_count
