import subprocess, sys

r = subprocess.run([sys.executable, "verify_caesar.py"], capture_output=True, text=True)
print("exit code:", r.returncode)
if r.stdout:
    print("--- stdout ---")
    print(r.stdout, end="")
if r.stderr:
    print("--- stderr ---", file=sys.stderr)
    print(r.stderr, end="", file=sys.stderr)
