from typing import List

def sum_of_prime_products_in_range(start: int, end: int) -> int:
    """
    Find the sum of all distinct products formed by multiplying any three
    different primes in the inclusive range from start to end.
    """
    def is_prime(n: int) -> bool:
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i * i <= n:
            if n % i == 0 or n % (i + 2) == 0:
                return False
            i += 6
        return True
    def primes_in_range(start: int, end: int) -> List[int]:
        return [num for num in range(max(2, start), end + 1) if is_prime(num)]

    primes = primes_in_range(start, end)
    products = set()
    for i in range(len(primes)):
        for j in range(i + 1, len(primes)):
            for k in range(j + 1, len(primes)):
                products.add(primes[i] * primes[j] * primes[k])
    return sum(products)
