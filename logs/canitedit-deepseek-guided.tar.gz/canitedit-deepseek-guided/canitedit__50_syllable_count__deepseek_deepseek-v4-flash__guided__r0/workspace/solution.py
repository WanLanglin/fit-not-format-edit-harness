import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    words = line.split()
    vowels = "aeiouy"

    def is_vowel(c):
        return c in vowels

    combos = 0
    for i in range(len(words) - 1):
        a = words[i]
        b = words[i + 1]

        end_a = a[-1]
        start_b = b[0]

        combo = False
        # vowel at end + vowel at start
        if is_vowel(end_a) and is_vowel(start_b):
            combo = True
        # vowel + 'm' at end + vowel at start
        elif len(a) >= 2 and a[-1] == 'm' and is_vowel(a[-2]) and is_vowel(start_b):
            combo = True
        # vowel + 'h' at end + vowel at start
        elif len(a) >= 2 and a[-1] == 'h' and is_vowel(a[-2]) and is_vowel(start_b):
            combo = True
        # vowel + 'm' at end + 'h' + vowel at start
        elif (len(a) >= 2 and a[-1] == 'm' and is_vowel(a[-2])
              and b[0] == 'h' and len(b) >= 2 and is_vowel(b[1])):
            combo = True

        if combo:
            combos += 1

    return syllable_count - combos
