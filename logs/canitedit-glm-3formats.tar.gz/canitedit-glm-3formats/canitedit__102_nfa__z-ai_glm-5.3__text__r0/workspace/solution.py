from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic finite automaton equivalent to the original NFA.

    The original NFA accepts exactly the language ``a b*`` -- an "a" followed
    by any number of "b"s -- and nothing else.  This automaton recognises the
    same language with a single successor state per input:

        * ``0`` is the start state (nothing read yet, non-accepting),
        * ``1`` is reached once an "a" has been read and loops on "b"
          (accepting),
        * ``2`` is the dead state reached by any non-matching continuation
          such as a leading "b" or a second "a" (non-accepting).

    The empty input behaves like the NFA's epsilon transitions, which were all
    trivial self loops, so it leaves the current state unchanged.
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        return table[self.current][input]

    def accepted(self):
        return self.current in self.accept
