import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

VOWELS = "aeiouy"

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in VOWELS:
            vowel_count += 1
    return vowel_count

def count_combos(line):
    """Count the number of 'combo' (elided vowel) pairs in a prepared line."""
    combo_count = 0
    words = line.split(" ")

    for index in range(len(words) - 1):
        current = words[index]
        following = words[index + 1]
        if current == "" or following == "":
            continue

        # vowel, or vowel followed by 'm', at the end of a word
        ends_in_vowel = current[-1] in VOWELS
        ends_in_vowel_m = (len(current) > 1 and current[-1] == "m"
                           and current[-2] in VOWELS)

        # vowel, or 'h' followed by a vowel, at the beginning of the next word
        starts_with_vowel = following[0] in VOWELS
        starts_with_h_vowel = (len(following) > 1 and following[0] == "h"
                               and following[1] in VOWELS)

        if (ends_in_vowel or ends_in_vowel_m) and (starts_with_vowel or starts_with_h_vowel):
            combo_count += 1

    return combo_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line) - count_combos(line)

    return syllable_count
