def minLength(password):
    assert type(password) == str
    return len(password) >= 8

def containsSpecialChar(password):
    special_characters = "!@#$%^&*"
    for character in password:
        if character in special_characters:
            return True
    return False


def isPasswordStrong(password):
    return minLength(password) and containsSpecialChar(password)
