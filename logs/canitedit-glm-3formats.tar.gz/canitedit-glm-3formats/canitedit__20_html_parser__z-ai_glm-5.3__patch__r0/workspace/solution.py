from typing import List, Optional, Union
import re


class HTMLElement:
    def __init__(self, name, content: List[Union[str, 'HTMLElement']],
                 attributes: Optional[dict] = None):
        self.name = name
        self.content = content
        self.attributes = attributes if attributes is not None else {}

    def __str__(self):
        attributes = ''.join(
            f' {name}="{value}"' for name, value in self.attributes.items()
        )
        return (
            f"<{self.name}{attributes}>"
            f"{''.join(str(c) for c in self.content)}</{self.name}>"
        )

    def __repr__(self):
        return f"HTMLElement(name={self.name}, content={repr(self.content)})"


def parse(content: str) -> List[HTMLElement]:
    """
    Parses the given HTML content and returns a list of HTMLElements.
    """
    tokens = tokenize(content)
    stack = []
    result = []

    for token in tokens:
        if is_start_tag(token):
            stack.append(
                HTMLElement(get_tag_name(token), [], get_attributes(token))
            )
        elif is_end_tag(token):
            element = stack.pop()
            if stack:
                stack[-1].content.append(element)
            else:
                result.append(element)
        else:
            if stack:
                stack[-1].content.append(token)

    return result


def tokenize(content: str) -> List[str]:
    # This regex splits the content into tags and text.
    # It looks for anything that starts with '<' and ends with '>', and treats it as a tag.
    # Everything else is treated as text.
    return re.findall(r'<[^>]+>|[^<]+', content)


def is_start_tag(token: str) -> bool:
    # A start tag starts with '<' but does not start with '</'.
    return token.startswith('<') and not token.startswith('</')


def is_end_tag(token: str) -> bool:
    # An end tag starts with '</'.
    return token.startswith('</')


def get_tag_name(token: str) -> str:
    # Extracts the tag name from a token.
    # It removes '<', '>', and '/' from the token and takes the first word,
    # so that any attributes that follow the tag name are ignored.
    words = token.strip('</>').split()
    return words[0] if words else ''


# Matches a single attribute: a name optionally followed by a value.
# The value may be double quoted, single quoted or unquoted, which allows
# values to contain spaces as long as they are quoted.
ATTRIBUTE_PATTERN = re.compile(
    r"""
    ([^\s=/>]+)                    # attribute name
    (?:                            # optional value
        \s*=\s*
        (?:
            "([^"]*)"              # double quoted value
            |'([^']*)'             # single quoted value
            |([^\s>]+)             # unquoted value
        )
    )?
    """,
    re.VERBOSE,
)


def get_attributes(token: str) -> dict:
    # Extracts the attributes from a start tag token.
    # The tag name itself is skipped, everything after it is scanned for
    # attribute name/value pairs.
    parts = token.strip('</>').split(maxsplit=1)
    if len(parts) < 2:
        return {}

    attributes = {}
    for match in ATTRIBUTE_PATTERN.finditer(parts[1]):
        name = match.group(1)
        value = next(
            (group for group in match.groups()[1:] if group is not None), ''
        )
        attributes[name] = value
    return attributes
