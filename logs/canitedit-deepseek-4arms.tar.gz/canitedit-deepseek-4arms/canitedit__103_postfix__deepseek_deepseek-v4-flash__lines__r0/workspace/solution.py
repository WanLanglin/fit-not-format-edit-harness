from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


def _is_op(token: Token) -> bool:
    return isinstance(token, str)


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        seq: List[Token] = list(inputs)

        # Scan for an operator, apply it to the last two numbers and replace
        # them with the result, then repeat from the start until no operators
        # remain.
        while any(_is_op(token) for token in seq):
            op_index = next(i for i, token in enumerate(seq) if _is_op(token))
            number_indexes = [i for i in range(op_index) if not _is_op(seq[i])]
            if len(number_indexes) < 2:
                raise Exception("malformed postfix expression")
            a = seq[number_indexes[-2]]
            b = seq[number_indexes[-1]]
            op = seq[op_index]
            if op == "+":
                result = b + a
            elif op == "-":
                result = b - a
            elif op == "*":
                result = b * a
            else:  # "/"
                result = b / a
            # Replace the operator with the computed result and drop the two
            # numbers it consumed.
            seq[op_index] = result
            del seq[number_indexes[-1]]
            del seq[number_indexes[-2]]

        if len(seq) != 1:
            raise Exception("malformed postfix expression")
        return float(seq[0])
