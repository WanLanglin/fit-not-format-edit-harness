from collections import deque
from typing import List

class CyclicGraphError(RuntimeError, ValueError):
    '''Raised when a topological sort is attempted on a graph with a cycle.

    It derives from both RuntimeError (the error type raised for invalid input
    elsewhere in this module) and ValueError, so either of them catches it.
    '''

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges
        # The edge list is also exposed as in_edges for backwards compatibility.
        self.in_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Return the nodes of the graph in topological order.

        Each node in the result is preceded by every node it can be reached
        from, so a node can only be reached from nodes previous to it in the
        list. A CyclicGraphError is raised for cyclic graphs, because those
        cannot be sorted topologically.
        '''
        # Index the nodes by id, since edges are stored as target ids.
        nodes_by_id = {}
        for node in self.nodes:
            nodes_by_id[node.id] = node

        # Kahn's algorithm: count the incoming edges of every node and then
        # repeatedly take a node whose predecessors have all been placed.
        incoming = {node.id: 0 for node in self.nodes}
        for node in self.nodes:
            for target in node.out_edges:
                if target in incoming:
                    incoming[target] += 1

        sorted_nodes = []
        ready = deque(node for node in self.nodes if incoming[node.id] == 0)
        while ready:
            node = ready.popleft()
            sorted_nodes.append(node)
            for target in node.out_edges:
                if target in incoming:
                    incoming[target] -= 1
                    if incoming[target] == 0:
                        ready.append(nodes_by_id[target])

        # Nodes that never became ready are part of a cycle.
        if len(sorted_nodes) != len(self.nodes):
            raise CyclicGraphError(
                "The graph contains a cycle, so it cannot be sorted topologically")
        return sorted_nodes
