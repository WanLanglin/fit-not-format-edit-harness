class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph,
        using the Bellman-Ford algorithm so that negative edge weights are supported.

        Raises a ValueError if the graph contains a negative cycle, since shortest
        paths are not defined in that case.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        infinity = float('infinity')
        distances = {node: infinity for node in self.nodes}
        distances[start] = 0

        edges = [
            (from_node, to_node, weight)
            for from_node, edge_list in self.edges.items()
            for to_node, weight in edge_list
        ]

        # Relax every edge once per round; after at most (number of nodes - 1)
        # rounds the distances are final, unless a negative cycle keeps improving
        # them forever. Each undirected edge appears twice, once per direction.
        for _ in range(max(len(self.nodes) - 1, 0)):
            updated = False

            for from_node, to_node, weight in edges:
                distance = distances[from_node]

                if distance == infinity:
                    continue

                if distance + weight < distances[to_node]:
                    distances[to_node] = distance + weight
                    updated = True

            if not updated:
                break

        for from_node, to_node, weight in edges:
            distance = distances[from_node]

            if distance != infinity and distance + weight < distances[to_node]:
                raise ValueError('Graph contains a negative cycle')

        return distances
