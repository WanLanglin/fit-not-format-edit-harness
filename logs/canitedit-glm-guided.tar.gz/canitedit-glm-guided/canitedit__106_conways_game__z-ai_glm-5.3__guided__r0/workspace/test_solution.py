from solution import ConwaysGameOfLife


def test_corner_cell_does_not_wrap_or_error():
    # Cluster in the top-left corner; a buggy wrap-around or out-of-bounds
    # access would either raise IndexError or count the wrong neighbors.
    grid = [
        [1, 1, 0],
        [1, 0, 0],
        [0, 0, 0],
    ]
    game = ConwaysGameOfLife(grid)
    assert game.compute_alive_nearby_cells(0, 0) == 2
    assert game.compute_alive_nearby_cells(2, 2) == 0
    assert game.compute_alive_nearby_cells(2, 0) == 1
    assert game.compute_alive_nearby_cells(0, 2) == 1


def test_step_on_edges_and_corners():
    # A 3x3 block shifted into the corner stays alive (stable still life).
    grid = [
        [1, 1, 0],
        [1, 1, 0],
        [0, 0, 0],
    ]
    game = ConwaysGameOfLife(grid)
    game.step()
    assert game.grid == [
        [1, 1, 0],
        [1, 1, 0],
        [0, 0, 0],
    ]


def test_wrap_around_is_not_counted():
    # Single column grid: with a horizontal wrap-around bug, cell (1,0) would
    # see its own column twice; without bounds checks it would raise IndexError.
    grid = [[1], [1], [1]]
    game = ConwaysGameOfLife(grid)
    assert game.compute_alive_nearby_cells(1, 0) == 2
    assert game.compute_alive_nearby_cells(0, 0) == 1


def test_blinker_oscillation():
    grid = [
        [0, 0, 0, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 0, 0, 0],
    ]
    game = ConwaysGameOfLife(grid)
    game.step()
    assert game.grid == [
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [0, 1, 1, 1, 0],
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
    ]
