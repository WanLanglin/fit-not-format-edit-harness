from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class MalformedExpressionError(ValueError, IndexError):
    """raised when a token sequence does not reduce to exactly one number"""


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        Raises:
            MalformedExpressionError: when the input is malformed, i.e. when the postfix
                computation leaves something other than exactly one number -- either an
                operator is applied to fewer than two numbers, or more than one number is
                left over once every token has been scanned.
        """

        def reduce(stack: List[float], operator: Op) -> float:
            if len(stack) < 2:
                raise MalformedExpressionError(
                    f"malformed postfix expression: operator {operator!r} applied to "
                    f"only {len(stack)} number(s)"
                )
            first = stack.pop()
            second = stack.pop()
            match operator:
                case "+":
                    return first + second
                case "-":
                    return first - second
                case "*":
                    return first * second
                case _:
                    return first / second

        def parseHelp(inputs: List[Token], stack: List[float]) -> float:
            if not inputs:
                if len(stack) != 1:
                    raise MalformedExpressionError(
                        f"malformed postfix expression: {len(stack)} numbers remain "
                        f"after applying every operator, expected exactly one"
                    )
                return stack[0]
            next = inputs.pop()
            match next:
                case "+" | "-" | "*" | "/":
                    stack.insert(0, reduce(stack, next))
                case _:
                    stack.insert(0, next)
            return parseHelp(inputs, stack)

        return parseHelp(list(inputs), [])
