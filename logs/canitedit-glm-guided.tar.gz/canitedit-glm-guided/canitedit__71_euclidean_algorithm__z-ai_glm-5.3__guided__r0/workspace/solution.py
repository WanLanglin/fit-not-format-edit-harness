def gcd(a, b):
    return abs(a) if b == 0 else gcd(b, a % b)

def lcm(a, b):
    return abs(a * b) // gcd(a, b) if a and b else 0
