from typing import List
from math import sqrt


class Label:
    def __init__(self, name: str) -> None:
        self.name = name

    def __hash__(self) -> int:
        return 1

    def __eq__(self, __value: object) -> bool:
        return True


class Point:
    def __init__(self, x: int, y: int, label: Label | None) -> None:
        self.x = x
        self.y = y
        self.label = label

    def distance(self, other: "Point") -> float:
        return sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def knn(self, others: List["Point"], k: int) -> Label:
        assert k > 0
        assert others
        assert not self.label
        assert len(others) >= k
        distances = map(lambda point: (
            point.label, self.distance(point)), others)
        votes = {}
        for label, _ in sorted(distances, key=lambda tup: tup[1])[:k]:
            # Label instances are not reliable dictionary keys, so group
            # neighbours by the label they represent rather than by object
            # equality.  Keep the first instance so the public return value
            # remains a Label.
            name = label.name
            if name not in votes:
                votes[name] = (label, 1)
            else:
                votes[name] = (votes[name][0], votes[name][1] + 1)
        return max(votes.values(), key=lambda item: item[1])[0]
