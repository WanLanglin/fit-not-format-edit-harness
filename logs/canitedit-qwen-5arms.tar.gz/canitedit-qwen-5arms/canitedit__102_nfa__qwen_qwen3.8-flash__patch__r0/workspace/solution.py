from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic automaton accepting the same language as the previous NFA.

    The NFA accepted exactly ``a b*``: an ``a`` followed by zero or more ``b``s.
    Its only epsilon moves were self-loops, so reading ``""`` never changed the
    reachable set of states and stays a no-op here.

    States come from subset construction, minimised by merging the two
    equivalent accepting subsets ``{1, 2}`` and ``{2}``:

    * 0 -- ``{0}``, the start state, not accepting
    * 1 -- ``{1, 2}`` / ``{2}``, accepting
    * 2 -- ``{}``, the rejecting sink for words such as ``b``, ``aa`` or ``abba``
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        """Consume one input symbol and return the state reached by the DFA.

        The automaton remembers where it is: ``self.current`` is advanced to the
        returned state, so feeding a whole word is just repeated calls, and
        ``accepted()`` reports whether the word read so far is accepted.
        """
        table: dict[State, dict[Input, State]] = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self) -> bool:
        return self.current in self.accept
