from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort ``lst`` in ascending order, in place, and return it.

    This merge sort is optimised for partially ordered input, i.e. arrays built
    out of large already-sorted subsequences (runs).  It minimises both the
    number of comparisons and the number of element copies:

    1. Early termination between sub-arrays: before merging, the two recursively
       sorted halves are compared at their boundary.  If the last element of the
       left half is not greater than the first element of the right half then
       the sub-arrays are already ordered *relative to each other*, so the whole
       merge is skipped: none of its comparisons and none of its copies are ever
       executed.
    2. Run detection: a range that is already a non-descending run is spotted by
       one linear scan and then left untouched -- it is not split, not merged and
       not copied at all.  When such a run covers the left half of a range, the
       recursion on that half is skipped too.
    3. Cheaper merges: the recursion works on index ranges of the caller's list
       and merges through a single shared scratch buffer (one allocation per
       sort instead of new left/right lists at every level).  After the merge
       loop only a leftover left half is written back -- a leftover right half
       already sits in its final positions, so copying it would be wasted work.

    Already-sorted or run-ordered input therefore costs O(n) comparisons, no
    element copies and no auxiliary allocation, while the general case stays
    O(n log n) comparisons and O(n) extra space.  The sort is stable: equal
    elements keep their original relative order.
    """
    n = len(lst)
    if n < 2:
        return lst

    # Fast path for fully sorted input: nothing to split or merge, and no
    # scratch buffer needs to be allocated at all.
    if _run_end(lst, 0, n) == n - 1:
        return lst

    _merge_sort_range(lst, 0, n, [0] * n)
    return lst


def _run_end(lst: List[int], lo: int, hi: int) -> int:
    """Return the last index of the non-descending run starting at ``lo``.

    The scan stops at the first descent (or at ``hi``), so ``lst[lo:run + 1]``
    is sorted.  ``run == hi - 1`` means the whole range was already a run.
    """
    i = lo
    while i + 1 < hi and lst[i] <= lst[i + 1]:
        i += 1
    return i


def _merge_sort_range(lst: List[int], lo: int, hi: int, scratch: List[int]) -> None:
    """Sort ``lst[lo:hi]`` in place, merging through ``scratch``."""
    if hi - lo <= 1:
        return

    # Nothing to do for a range that is already one sorted run.
    run = _run_end(lst, lo, hi)
    if run == hi - 1:
        return

    mid = (lo + hi) // 2

    # The detected run reaches into (or past) the middle, so the left half is
    # already sorted: skip its recursion entirely.
    if run < mid - 1:
        _merge_sort_range(lst, lo, mid, scratch)
    _merge_sort_range(lst, mid, hi, scratch)

    # Early termination: the two sorted halves are already ordered relative to
    # each other, so ``lst[lo:hi]`` is sorted and the merge can be skipped.
    if lst[mid - 1] <= lst[mid]:
        return

    # Merge lst[lo:mid] with lst[mid:hi] through the shared scratch buffer.
    scratch[lo:hi] = lst[lo:hi]
    i = lo
    j = mid
    k = lo
    while i < mid and j < hi:
        if scratch[i] <= scratch[j]:
            lst[k] = scratch[i]
            i += 1
        else:
            lst[k] = scratch[j]
            j += 1
        k += 1
    # Leftover left-half items still have to be written back; leftover
    # right-half items are already in place, since nothing was written to
    # lst[k:hi].
    while i < mid:
        lst[k] = scratch[i]
        i += 1
        k += 1
