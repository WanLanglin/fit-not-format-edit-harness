from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""

        sequence = list(inputs)
        operators = {"+", "-", "*", "/"}

        while True:
            operator_index = next(
                (index for index, token in enumerate(sequence) if token in operators),
                None,
            )
            if operator_index is None:
                break
            if operator_index < 2:
                raise Exception("Malformed postfix expression")

            left, right = sequence[operator_index - 2 : operator_index]
            operator = sequence[operator_index]
            if not isinstance(left, (int, float)) or not isinstance(
                right, (int, float)
            ):
                raise Exception("Malformed postfix expression")

            match operator:
                case "+":
                    result = left + right
                case "-":
                    result = left - right
                case "*":
                    result = left * right
                case "/":
                    result = left / right

            sequence[operator_index - 2 : operator_index + 1] = [result]

        if len(sequence) != 1 or not isinstance(sequence[0], (int, float)):
            raise Exception("Malformed postfix expression")
        return sequence[0]
