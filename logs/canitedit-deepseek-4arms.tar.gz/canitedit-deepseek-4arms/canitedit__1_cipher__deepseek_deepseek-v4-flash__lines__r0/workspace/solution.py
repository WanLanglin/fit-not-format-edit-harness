class Cipher:

    def __init__(self):
        self.alphabet = 'abcdefghijklmnopqrstuvwxyz'
        self.ciphers = {
            "default": {
                'a': 'b',
                'b': 'a',
                'c': 'e',
                'd': 'd',
                'e': 'c',
                'f': 'g',
                'g': 'f',
                'h': 'i',
                'i': 'h',
                'j': 'k',
                'k': 'j',
                'l': 'm',
                'm': 'l',
                'n': 'o',
                'o': 'n',
                'p': 'q',
                'q': 'p',
                'r': 's',
                's': 'r',
                't': 'u',
                'u': 't',
                'v': 'w',
                'w': 'v',
                'x': 'y',
                'y': 'x',
                'z': 'z'}
        }

    def caesar_cipher(self, shift):
        cipher = {
            let: self.alphabet[(i + shift) % 26]
            for i, let in enumerate(self.alphabet)
        }
        self.ciphers["caesar" + str(shift)] = cipher
        return cipher

    def add_cipher(self, name, cipher):
        dic = {}
        for let, c in zip(self.alphabet, cipher):
            dic[let] = c
        self.ciphers[name] = dic
        return dic
