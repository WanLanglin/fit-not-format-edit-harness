def reverseString(originalString):
    return originalString[::-1]

def isPalindrome(originalString):
    return originalString.lower() == reverseString(originalString.lower())
