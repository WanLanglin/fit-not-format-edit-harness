import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    for char in " \t\n\r\v\f":
        line = line.replace(char, "")
    return line

def vowel_count(line):
    diphthongs = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]
    cleaned = prepare_line(line)
    count = 0
    i = 0
    while i < len(cleaned):
        matched = False
        for d in diphthongs:
            if cleaned[i:i+len(d)] == d:
                i += len(d)
                matched = True
                break
        if not matched:
            if cleaned[i] in "aeiouy":
                count += 1
            i += 1
    return count

if __name__ == "__main__":
    print(vowel_count('adspirate meis primaque ab origine mundi'))
    print(vowel_count('in nova fert animus mutatas dicere formas'))
