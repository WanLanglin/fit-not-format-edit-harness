class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int):
        """Return the next ``n`` fibonacci numbers this iterator would yield.

        The iterator's own state is left untouched, so a subsequent call to
        ``__next__`` returns the same value it would have returned if this
        method had never been called.
        """
        prev_prev = getattr(self, "prev_prev", 0)
        prev = getattr(self, "prev", 1)
        result = []
        for _ in range(n):
            output = prev_prev + prev
            prev_prev = prev
            prev = output
            result.append(output)
        return result
