def same_size(matrix_a: list[list[int]], matrix_b: list[list[int]]) -> bool:
    """Return True if both matrices have the same dimensions."""
    if len(matrix_a) != len(matrix_b):
        return False
    for row_a, row_b in zip(matrix_a, matrix_b):
        if len(row_a) != len(row_b):
            return False
    return True


class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def add(self, other):
        if not same_size(self.matrix, other.matrix):
            raise ValueError("Matrices must have the same dimensions to be added")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)
    
    def subtract(self, other):
        if not same_size(self.matrix, other.matrix):
            raise ValueError("Matrices must have the same dimensions to be subtracted")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)
