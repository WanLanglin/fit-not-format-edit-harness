from typing import List, Union

class Manager:
    def __init__(self, name: str, direct_reports: List[Union["Manager", "IC"]]):
        self.name = name
        self.team = direct_reports
    
    def find_manager_n(self, name: str, n: int) -> List[str]:
        if n < 1:
            raise ValueError("n must be at least 1")
        all_manager_names = []
        for direct_report in self.team:
            if isinstance(direct_report, Manager):
                all_manager_names.extend(direct_report._find_manager_n(name, n, [self.name]))
            elif direct_report.name == name and n == 1:
                all_manager_names.append(self.name)
        return sorted(list(set(all_manager_names)))

    def _find_manager_n(self, name: str, n: int, path: List[str]) -> List[str]:
        managers_names = []
        if self.name == name and len(path) >= n:
            managers_names.append(path[-n])
        for direct_report in self.team:
            if isinstance(direct_report, Manager):
                managers_names.extend(direct_report._find_manager_n(name, n, path + [self.name]))
            elif direct_report.name == name:
                if n == 1:
                    managers_names.append(self.name)
                elif len(path) >= n - 1:
                    managers_names.append(path[-(n - 1)])
        return managers_names
    
class IC:
    def __init__(self, name: str):
        self.name = name
