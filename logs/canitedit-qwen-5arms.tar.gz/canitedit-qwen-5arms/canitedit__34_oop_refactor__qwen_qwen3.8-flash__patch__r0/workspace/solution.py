from abc import ABC, abstractmethod


class Message(ABC):
    """Abstract base class for a message with some text content."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Return the processed representation of the message."""


class TextMessage(Message):
    """A plain text message."""

    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    """An image message described by its content string."""

    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    """Create Message subclasses from a message type string."""

    _TYPES = {"text": TextMessage, "image": ImageMessage}

    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        try:
            message_class = MessageFactory._TYPES[message_type]
        except KeyError:
            raise ValueError(f"Unknown message type: {message_type}")
        return message_class(content)


def process_message(message, message_type):
    try:
        handler = MessageFactory.get_message(message_type, message)
    except ValueError:
        return "Unknown message type"
    return handler.process()
