import heapq
from typing import List


class Node:
    '''Simple node (No duplicate edges between nodes)'''

    def __init__(self, id: int):
        self.id = id
        self.out_edges = []
        self.in_edges = []

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Node):
            return False
        else:
            return self.id == __value.id

    def __hash__(self) -> int:
        return self.id


class Edge:
    def __init__(self, src: Node, dest: Node, weight: int):
        assert weight > 0

        self.src = src
        self.dest = dest
        self.weight = weight

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Edge):
            return False
        else:
            return self.dest == __value.dest and self.src == __value.src


class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''

    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques.keys():
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        self.edges = []

    def add_edge(self, edge: Edge):
        assert edge not in self.edges
        self.edges.append(edge)

    def fibonacci(self, x: Node):
        '''Shortest-path distances from node x to every node of the graph.

        Returns a dictionary whose keys are all the Nodes in self.nodes and
        whose values are the length of the shortest path (the smallest sum of
        the weights of the edges) leading from x to the key. Nodes which
        cannot be reached from x map to None, while the distance from x to
        itself is 0. All edge weights are positive, so Dijkstra's algorithm
        is used.
        '''
        # Adjacency list: source node -> list of (destination, weight) pairs.
        adjacency = {}
        for edge in self.edges:
            adjacency.setdefault(edge.src, []).append((edge.dest, edge.weight))
        # Edges registered directly on the nodes are considered as well.
        for node in self.nodes:
            for edge in getattr(node, "out_edges", None) or ():
                adjacency.setdefault(edge.src, []).append((edge.dest, edge.weight))

        # Dijkstra's algorithm. Every node of the graph becomes a key of the
        # result; nodes which are never reached keep the value None. Nodes
        # which are only passed through (they carry an edge but are not part
        # of self.nodes) are followed but not reported.
        dist = {x: 0}
        # The counter breaks ties in the heap because Node defines no ordering.
        order = 0
        heap = [(0, order, x)]
        settled = set()
        while heap:
            distance, _, node = heapq.heappop(heap)
            if node in settled:
                continue
            settled.add(node)
            for neighbor, weight in adjacency.get(node, ()):
                if neighbor in settled:
                    continue
                candidate = distance + weight
                if neighbor not in dist or candidate < dist[neighbor]:
                    dist[neighbor] = candidate
                    order += 1
                    heapq.heappush(heap, (candidate, order, neighbor))

        return {node: dist.get(node) for node in self.nodes}
