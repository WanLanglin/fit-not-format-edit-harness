from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class MalformedExpression(ValueError):
    """raised when a postfix token sequence does not reduce to a single number"""


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parse a sequence of input tokens in postfix notation and return the result

        The sequence is scanned until an operator is found, that operator is applied to the
        last two numbers and they are replaced with its result, and the process is repeated
        from the start on the new sequence until no operators are left.

        The input is malformed when that process does not leave exactly one number, e.g.
        ``[1, 2, 3]`` or ``["+", 1, 2, 3]`` leave several numbers behind and ``[]`` leaves
        none; a ``MalformedExpression`` (an ``Exception``) is raised for those instead of
        returning a result.

        >>> PostfixParser().parse(["*", 1, 2, "+"])
        2
        """

        def parseHelp(inputs: List[Token], stack: List[float]) -> float:
            if not inputs:
                if len(stack) != 1:
                    raise MalformedExpression(
                        f"expected one number to remain, got {len(stack)}: {stack}"
                    )
                return stack[0]
            stack_len = len(stack)
            next = inputs.pop()
            match next:
                case _ if stack_len >= 2:
                    match next:
                        case "+":
                            stack.insert(0, stack.pop() + stack.pop())
                        case "-":
                            stack.insert(0, stack.pop() - stack.pop())
                        case "*":
                            stack.insert(0, stack.pop() * stack.pop())
                        case "/":
                            stack.insert(0, stack.pop() / stack.pop())
                case _:
                    stack.insert(0, next)
            return parseHelp(inputs, stack)

        return parseHelp(list(inputs), [])
