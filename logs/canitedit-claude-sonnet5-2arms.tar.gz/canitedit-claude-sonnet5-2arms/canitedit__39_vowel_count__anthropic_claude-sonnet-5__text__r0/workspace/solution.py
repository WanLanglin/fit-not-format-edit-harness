import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

DIPHTHONGS = sorted(
    ["ae", "oe", "ei", "ea", "ia", "io", "aea"],
    key=len,
    reverse=True,
)

def vowel_count(line):
    vowel_count = 0
    for word in prepare_line(line).split():
        index = 0
        while index < len(word):
            for diphthong in DIPHTHONGS:
                if word[index:index + len(diphthong)] == diphthong:
                    index += len(diphthong)
                    break
            else:
                if word[index] in "aeiouy":
                    vowel_count += 1
                index += 1
    return vowel_count
