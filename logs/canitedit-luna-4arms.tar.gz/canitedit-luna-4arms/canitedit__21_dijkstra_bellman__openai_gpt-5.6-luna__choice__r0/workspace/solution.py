class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """Compute the shortest distances from ``start`` to all nodes.

        Bellman-Ford is used instead of Dijkstra so that negative edge weights
        are supported.  A negative cycle reachable from ``start`` means that
        there is no finite shortest distance, so it is reported as an error.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Relax every edge at most |V| - 1 times.  Iterating over the
        # adjacency lists also handles the undirected edges created by
        # add_edge.
        for _ in range(len(self.nodes) - 1):
            changed = False
            for node in self.nodes:
                if shortest_path[node] == float('infinity'):
                    continue
                for neighbor, weight in self.edges[node]:
                    distance = shortest_path[node] + weight
                    if distance < shortest_path[neighbor]:
                        shortest_path[neighbor] = distance
                        changed = True

            if not changed:
                break

        # If an edge can still be relaxed, it is part of (or reachable from)
        # a negative-weight cycle reachable from the source.
        for node in self.nodes:
            if shortest_path[node] == float('infinity'):
                continue
            for neighbor, weight in self.edges[node]:
                if shortest_path[node] + weight < shortest_path[neighbor]:
                    raise ValueError('Graph contains a negative cycle')

        return shortest_path
