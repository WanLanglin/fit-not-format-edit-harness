class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def same_size(self, other) -> bool:
        """Return True if ``other`` has the same dimensions as this matrix."""
        # Accept either a Matrix or a plain list of lists.
        matrix_a = getattr(self, "matrix", self)
        matrix_b = getattr(other, "matrix", other)

        if len(matrix_a) != len(matrix_b):
            return False
        return all(
            len(row) == len(other_row)
            for row, other_row in zip(matrix_a, matrix_b)
        )

    def add(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must have the same dimensions to be added")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)
    
    def subtract(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must have the same dimensions to be subtracted")
        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)
