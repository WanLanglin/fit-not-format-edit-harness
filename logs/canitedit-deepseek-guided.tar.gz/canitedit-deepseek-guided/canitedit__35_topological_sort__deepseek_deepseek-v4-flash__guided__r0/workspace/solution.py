from typing import List
from collections import deque

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.in_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        # The stored list on each node holds the ids of nodes reachable
        # from it (out-edges). Build lookup maps and run Kahn's algorithm.
        node_map = {node.id: node for node in self.nodes}

        # in_degree counts how many nodes point to each node.
        in_degree = {node.id: 0 for node in self.nodes}
        for node in self.nodes:
            for neighbor_id in node.in_edges:
                if neighbor_id not in node_map:
                    raise RuntimeError("Edge references unknown node")
                in_degree[neighbor_id] += 1

        # Nodes with no incoming edges can be processed first.
        queue = deque(node.id for node in self.nodes if in_degree[node.id] == 0)
        sorted_ids = []

        while queue:
            current_id = queue.popleft()
            sorted_ids.append(current_id)
            for neighbor_id in node_map[current_id].in_edges:
                in_degree[neighbor_id] -= 1
                if in_degree[neighbor_id] == 0:
                    queue.append(neighbor_id)

        # If we couldn't process all nodes, the graph contains a cycle.
        if len(sorted_ids) != len(self.nodes):
            raise RuntimeError("Graph contains a cycle, cannot perform topological sort")

        return [node_map[nid] for nid in sorted_ids]
