def minLength(password):
    assert type(password) == str
    return len(password) >= 8

SPECIAL_CHARACTERS = set("!@#$%^&*()_+-=[]{};':\"\\,.<>/?~`")

def containsSpecialChar(password):
    assert type(password) == str
    for char in password:
        if char in SPECIAL_CHARACTERS:
            return True
    return False

def isPasswordStrong(password):
    return minLength(password) and containsSpecialChar(password)
