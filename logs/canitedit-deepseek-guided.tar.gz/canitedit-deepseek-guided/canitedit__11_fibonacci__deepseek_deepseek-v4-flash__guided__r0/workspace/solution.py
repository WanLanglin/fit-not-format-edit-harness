class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int):
        p_prev = self.prev_prev
        p = self.prev
        results = []
        for _ in range(n):
            output = p + p_prev
            results.append(output)
            p_prev = p
            p = output
        return results
