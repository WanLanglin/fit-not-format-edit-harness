class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int) -> list:
        prev_prev = getattr(self, "prev_prev", 0)
        prev = getattr(self, "prev", 1)
        output = []
        for _ in range(n):
            nxt = prev + prev_prev
            output.append(nxt)
            prev_prev = prev
            prev = nxt
        return output
