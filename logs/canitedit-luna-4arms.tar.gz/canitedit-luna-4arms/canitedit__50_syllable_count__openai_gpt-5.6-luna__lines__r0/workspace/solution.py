import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

VOWELS = "aeiouy"


def combo_count(line):
    words = prepare_string(line).split(" ")
    count = 0

    for first, second in zip(words, words[1:]):
        if not first or not second:
            continue

        next_is_vowel = second[0] in VOWELS
        next_is_h_vowel = (
            second[0] == "h" and len(second) >= 2 and second[1] in VOWELS
        )

        if first[-1] in VOWELS and next_is_vowel:
            count += 1
        elif len(first) >= 2 and first[-2] in VOWELS and first[-1] == "m":
            if next_is_vowel or next_is_h_vowel:
                count += 1
        elif len(first) >= 2 and first[-2] in VOWELS and first[-1] == "h":
            if next_is_vowel:
                count += 1

    return count


def vowel_count(line):
    line = prepare_string(line)
    count = 0
    for c in line:
        if c in VOWELS:
            count += 1
    return count - combo_count(line)


def syllable_count(line):
    syllable_count = vowel_count(line)
    syllable_count += combo_count(line)
    return syllable_count
