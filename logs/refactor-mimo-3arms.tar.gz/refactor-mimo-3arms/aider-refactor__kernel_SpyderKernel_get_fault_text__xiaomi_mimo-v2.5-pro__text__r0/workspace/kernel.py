# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) 2009- Spyder Kernels Contributors
#
# Licensed under the terms of the MIT License
# (see spyder_kernels/__init__.py for details)
# -----------------------------------------------------------------------------


"""
Spyder kernel for Jupyter.
"""

# Standard library imports
import faulthandler
import json
import logging
import os
import re
import sys
import traceback
import tempfile
import threading

# Third-party imports
from ipykernel.ipkernel import IPythonKernel
from ipykernel import eventloops, get_connection_info
from traitlets.config.loader import LazyConfigValue
import zmq
from zmq.utils.garbage import gc

# Local imports
import spyder_kernels
from spyder_kernels.comms.frontendcomm import FrontendComm
from spyder_kernels.comms.decorators import (
    register_comm_handlers, comm_handler)
from spyder_kernels.utils.iofuncs import iofunctions
from spyder_kernels.utils.mpl import automatic_backend, MPL_BACKENDS_TO_SPYDER
from spyder_kernels.utils.nsview import (
    get_remote_data, make_remote_view, get_size)
from spyder_kernels.console.shell import SpyderShell
from spyder_kernels.comms.utils import WriteContext


logger = logging.getLogger(__name__)


# Excluded variables from the Variable Explorer (i.e. they are not
# shown at all there)
EXCLUDED_NAMES = ['In', 'Out', 'exit', 'get_ipython', 'quit']


def get_fault_text(fault_filename, main_id, ignore_ids):
    """Get fault text from old run."""
    # Read file
    try:
        with open(fault_filename, 'r') as f:
            fault = f.read()
    except FileNotFoundError:
        return
    except UnicodeDecodeError as e:
        return (
            "Can not read fault file!\n"
            + "UnicodeDecodeError: " + str(e))

    # Remove file
    try:
        os.remove(fault_filename)
    except FileNotFoundError:
        pass
    except PermissionError:
        pass

    # Process file
    if not fault:
        return

    thread_regex = (
        r"(Current thread|Thread) "
        r"(0x[\da-f]+) \(most recent call first\):"
        r"(?:.|\r\n|\r|\n)+?(?=Current thread|Thread|\Z)")
    # Keep line for future improvements
    # files_regex = r"File \"([^\"]+)\", line (\d+) in (\S+)"

    text = ""
    start_idx = 0
    for idx, match in enumerate(re.finditer(thread_regex, fault)):
        # Add anything non-matched
        text += fault[start_idx:match.span()[0]]
        start_idx = match.span()[1]
        thread_id = int(match.group(2), base=16)
        if thread_id != main_id:
            if thread_id in ignore_ids:
                continue
            if "wurlitzer.py" in match.group(0):
                # Wurlitzer threads are launched later
                continue
            text += "\n" + match.group(0) + "\n"
        else:
            try:
                pattern = (r".*(?:/IPython/core/interactiveshell\.py|"
                           r"\\IPython\\core\\interactiveshell\.py).*")
                match_internal = next(re.finditer(pattern, match.group(0)))
                end_idx = match_internal.span()[0]
            except StopIteration:
                end_idx = None
            text += "\nMain thread:\n" + match.group(0)[:end_idx] + "\n"

    # Add anything after match
    text += fault[start_idx:]
    return text


class SpyderKernel(IPythonKernel):
    pass

