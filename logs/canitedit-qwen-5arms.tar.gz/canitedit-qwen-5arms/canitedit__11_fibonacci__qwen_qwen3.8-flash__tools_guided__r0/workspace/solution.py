class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output

    def next_n_fibs(self, n: int):
        """Return a list of the next `n` Fibonacci numbers.

        The sequence produced starts with the value that `__next__` would
        return right now, and the state of the object is left untouched, so a
        later call to `__next__` still yields the same value it would have
        yielded had this method never been called.
        """
        if n <= 0:
            return []
        prev_prev = self.prev_prev
        prev = self.prev
        result = []
        for _ in range(n):
            output = prev + prev_prev
            prev_prev = prev
            prev = output
            result.append(output)
        return result
