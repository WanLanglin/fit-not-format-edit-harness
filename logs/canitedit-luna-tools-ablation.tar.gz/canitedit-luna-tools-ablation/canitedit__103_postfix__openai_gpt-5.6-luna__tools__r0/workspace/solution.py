from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """Parse a sequence of input tokens using postfix notation."""
        sequence = list(inputs)

        while True:
            operator_index = next(
                (index for index, token in enumerate(sequence)
                 if token in ("+", "-", "*", "/")),
                None,
            )
            if operator_index is None:
                break
            if operator_index < 2:
                raise Exception("Malformed postfix expression")

            left, right = sequence[operator_index - 2:operator_index]
            operator = sequence[operator_index]
            match operator:
                case "+":
                    result = left + right
                case "-":
                    result = left - right
                case "*":
                    result = left * right
                case "/":
                    result = left / right
            sequence[operator_index - 2:operator_index + 1] = [result]

        if len(sequence) != 1:
            raise Exception("Malformed postfix expression")
        return sequence[0]
