from typing import List, Tuple

def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Return (max_subarray_sum, srt_idx, end_idx) using Kadane's algorithm."""
    max_so_far = lst[0]
    curr_max = lst[0]
    srt_idx = 0
    end_idx = 0
    curr_srt = 0
    for i in range(1, len(lst)):
        if lst[i] > curr_max + lst[i]:
            # Starting a new subarray at i beats extending the current one.
            curr_max = lst[i]
            curr_srt = i
        else:
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            srt_idx = curr_srt
            end_idx = i
    return (max_so_far, srt_idx, end_idx)
