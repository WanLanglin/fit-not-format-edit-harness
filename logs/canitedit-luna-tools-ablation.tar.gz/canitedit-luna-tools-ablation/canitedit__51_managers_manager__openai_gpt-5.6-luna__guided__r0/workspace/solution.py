from typing import List, Union

class Manager:
    def __init__(self, name: str, direct_reports: List[Union["Manager", "IC"]]):
        self.name = name
        self.team = direct_reports
    
    def find_manager_n(self, name: str, n: int) -> List[str]:
        if n < 1:
            raise ValueError("n must be at least 1")

        manager_names = self.find_manager_n_help(name, n, [])
        return sorted(set(manager_names))
    
    def find_manager_n_help(self, name: str, n: int, path: List[str]) -> List[str]:
        manager_names = []
        manager_path = path + [self.name]

        if self.name == name and len(manager_path) > n:
            manager_names.append(manager_path[-n - 1])

        for direct_report in self.team:
            if isinstance(direct_report, Manager):
                manager_names.extend(direct_report.find_manager_n_help(name, n, manager_path))
            elif direct_report.name == name and len(manager_path) >= n:
                manager_names.append(manager_path[-n])
        return manager_names
    
class IC:
    def __init__(self, name: str):
        self.name = name
