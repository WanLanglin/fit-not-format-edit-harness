class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the
        graph, using the Bellman-Ford algorithm so that negative weights are
        supported. Raises a ValueError if the graph contains a negative cycle
        that is reachable from the start node.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        edges = [
            (from_node, to_node, weight)
            for from_node in self.nodes
            for to_node, weight in self.edges.get(from_node, [])
            if to_node in self.nodes
        ]

        # Relax every edge up to |nodes| - 1 times. Once a full pass makes no
        # update the distances have converged and we can stop early.
        for _ in range(len(self.nodes) - 1):
            updated = False
            for from_node, to_node, weight in edges:
                if shortest_path[from_node] == float('infinity'):
                    continue

                distance = shortest_path[from_node] + weight
                if distance < shortest_path[to_node]:
                    shortest_path[to_node] = distance
                    updated = True

            if not updated:
                break

        # If an edge can still be relaxed, a negative cycle is reachable from
        # the start node, so no shortest distances are well defined.
        for from_node, to_node, weight in edges:
            if shortest_path[from_node] == float('infinity'):
                continue

            if shortest_path[from_node] + weight < shortest_path[to_node]:
                raise ValueError('Graph contains a negative cycle')

        return shortest_path
