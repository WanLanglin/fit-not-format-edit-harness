from solution import Manager, IC

# Tree: CEO -> [VP1, VP2, ic_root]; VP1 -> [M1, M2, ic_a]; VP2 -> [M3]
# M1 -> [ic_b, ic_c]; M2 -> [ic_d]; M3 -> [ic_e]
ceo = Manager("CEO", [
    Manager("VP1", [
        Manager("M1", [IC("ic_b"), IC("ic_c")]),
        Manager("M2", [IC("ic_d")]),
        IC("ic_a"),
    ]),
    Manager("VP2", [Manager("M3", [IC("ic_e")])]),
    IC("ic_root"),
])

# n=2 matches the old find_managers_manager behavior
assert ceo.find_manager_n("ic_b", 2) == ["VP1"]
assert ceo.find_manager_n("ic_a", 2) == ["CEO"]
assert ceo.find_manager_n("M1", 2) == ["CEO"]
assert ceo.find_manager_n("ic_e", 2) == ["VP2"]

# n=1: immediate manager
assert ceo.find_manager_n("ic_b", 1) == ["M1"]
assert ceo.find_manager_n("M1", 1) == ["VP1"]
assert ceo.find_manager_n("VP1", 1) == ["CEO"]

# n=3
assert ceo.find_manager_n("ic_b", 3) == ["CEO"]
assert ceo.find_manager_n("ic_e", 3) == ["CEO"]

# Root of the searched tree has no manager above it
assert ceo.find_manager_n("CEO", 1) == []
assert ceo.find_manager_n("CEO", 2) == []

# Root's direct IC report: manager 1 up is the root; none 2 up
assert ceo.find_manager_n("ic_root", 1) == ["CEO"]
assert ceo.find_manager_n("ic_root", 2) == []

# Name absent
assert ceo.find_manager_n("nobody", 1) == []
assert ceo.find_manager_n("nobody", 4) == []

# n beyond the top of the hierarchy
assert ceo.find_manager_n("VP1", 5) == []
assert ceo.find_manager_n("ic_b", 4) == []

# Search is rooted at self, same as the original method
m1 = ceo.team[0].team[0]
assert m1.find_manager_n("ic_b", 1) == ["M1"]
assert m1.find_manager_n("ic_b", 2) == []  # no second manager above ic_b inside M1's tree
assert m1.find_manager_n("VP1", 1) == []   # VP1 is outside M1's subtree
assert m1.find_manager_n("M1", 1) == []    # M1 is the root of the searched tree

# Repeated names: every occurrence contributes its own chain of managers
both = Manager("top", [Manager("X", [IC("dup")]), Manager("Y", [Manager("X", [IC("dup")])])])
assert both.find_manager_n("dup", 1) == ["X"]
assert both.find_manager_n("dup", 2) == ["Y", "top"]
assert both.find_manager_n("dup", 3) == ["top"]

# n must be at least 1
for bad in (0, -1):
    try:
        ceo.find_manager_n("ic_b", bad)
    except ValueError:
        pass
    else:
        raise AssertionError(f"expected ValueError for n={bad}")

print("all assertions passed")
