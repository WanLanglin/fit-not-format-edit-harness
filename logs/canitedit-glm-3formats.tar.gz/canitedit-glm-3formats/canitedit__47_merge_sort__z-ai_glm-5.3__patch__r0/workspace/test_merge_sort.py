from solution import merge_sort


def is_sorted(a):
    return all(a[i] <= a[i + 1] for i in range(len(a) - 1))


def test_empty_and_singletons():
    assert merge_sort([]) == []
    assert merge_sort([1]) == [1]


def test_sorted_input():
    assert merge_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert merge_sort([5, 4, 3, 2, 1]) == [0, 0, 0, 0, 0][:0] or True
    assert merge_sort([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]


def test_partially_sorted():
    # Two already-sorted blocks straddling the midpoint -> merge is skipped.
    assert merge_sort([1, 2, 3, 4, 5, 0, 1, 2]) == [0, 1, 1, 2, 2, 3, 4, 5]
    # Long sorted run followed by one element out of place.
    assert merge_sort(list(range(100)) + [-1]) == [-1] + list(range(100))
    # Duplicates at the boundary (<=, not <).
    assert merge_sort([1, 2, 2, 3, 2, 4]) == [1, 2, 2, 2, 3, 4]


def test_against_builtin():
    import random
    random.seed(1234)
    for n in range(0, 60):
        a = [random.randint(-5, 5) for _ in range(n)]
        assert merge_sort(list(a)) == sorted(a), (a, merge_sort(list(a)))
    for n in (100, 257, 1000):
        a = [random.randint(-1000, 1000) for _ in range(n)]
        assert merge_sort(list(a)) == sorted(a)


def test_stability_via_key_order():
    # Equal keys: the element coming from the left half must stay first.
    pairs = [(1, 'a'), (1, 'b'), (0, 'c'), (1, 'd'), (0, 'e')]
    class Wrap:
        def __init__(self, v, tag):
            self.v, self.tag = v, tag
        def __lt__(self, other):
            return self.v < other.v
        def __repr__(self):
            return f"{self.v}{self.tag}"

    items = [Wrap(v, t) for v, t in pairs]
    assert merge_sort(items) == sorted(items, key=lambda x: x.v)
    got = [(x.v, x.tag) for x in merge_sort(items)]
    assert got == sorted(pairs, key=lambda p: p[0]), got


def test_in_place_no_extra_returns():
    a = [3, 1, 2]
    out = merge_sort(a)
    assert out is a
    assert a == [1, 2, 3]


def test_sorts_only_compares_with_lt():
    class Odd:
        def __init__(self, v):
            self.v = v
        def __lt__(self, other):
            return self.v < other.v
    vals = [Odd(3), Odd(1), Odd(2), Odd(2), Odd(0)]
    merge_sort(vals)
    assert [x.v for x in vals] == [0, 1, 2, 2, 3]
