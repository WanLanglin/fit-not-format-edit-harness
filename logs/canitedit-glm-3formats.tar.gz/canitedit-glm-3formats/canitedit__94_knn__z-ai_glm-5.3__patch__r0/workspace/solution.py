from typing import List
from math import sqrt


class Label:
    def __init__(self, name: str) -> None:
        self.name = name

    def __hash__(self) -> int:
        return 1

    def __eq__(self, __value: object) -> bool:
        return True


class Point:
    def __init__(self, x: int, y: int, label: Label | None) -> None:
        self.x = x
        self.y = y
        self.label = label

    def distance(self, other: "Point") -> float:
        return sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def knn(self, others: List["Point"], k: int) -> Label:
        assert k > 0
        assert others
        assert not self.label
        assert len(others) >= k

        # ``Label`` implements ``__eq__``/``__hash__`` so that every instance
        # equals (and hashes like) every other instance.  Labels therefore
        # cannot be used as dictionary keys: every vote would collapse onto a
        # single entry and the vote tally would be meaningless.  Tally the
        # votes by the label's name instead, so distinct labels stay distinct.
        nearest = sorted(others, key=lambda point: self.distance(point))[:k]

        counts = {}
        first_seen = {}
        representative = {}
        for index, point in enumerate(nearest):
            label = point.label
            key = label.name if label is not None else None
            counts[key] = counts.get(key, 0) + 1
            if key not in first_seen:
                first_seen[key] = index
                representative[key] = label

        # The label with the most votes wins; ties are broken in favour of the
        # label whose closest neighbour lies nearest to this point, i.e. the
        # label that was seen first among the k nearest neighbours.
        best = min(counts, key=lambda key: (-counts[key], first_seen[key]))
        return representative[best]
