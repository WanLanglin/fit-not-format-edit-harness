from typing import Dict, List, Union
import re


# Matches a single attribute inside a start tag: an attribute name optionally
# followed by "=value". The value may be double quoted, single quoted (both of
# which may contain spaces) or unquoted.
ATTRIBUTE_PATTERN = re.compile(
    r"""([^\s=/>]+)          # attribute name
        (?:\s*=\s*          # optional value
            (?:"([^"]*)"     # double quoted value
              |'([^']*)'     # single quoted value
              |([^\s"'<>]+)  # unquoted value
            )
        )?""",
    re.VERBOSE,
)

# HTML elements that never have a closing tag. They are complete as soon as
# their start tag has been seen.
VOID_ELEMENTS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
}


class HTMLElement:
    def __init__(self, name, content: List[Union[str, 'HTMLElement']],
                 attributes: Dict[str, str] = None):
        self.name = name
        self.content = content
        self.attributes = attributes if attributes is not None else {}

    def __str__(self):
        attributes = ''.join(
            f' {name}="{value}"' if value else f' {name}'
            for name, value in self.attributes.items()
        )
        return (
            f"<{self.name}{attributes}>"
            f"{''.join(str(c) for c in self.content)}"
            f"</{self.name}>"
        )

    def __repr__(self):
        return f"HTMLElement(name={self.name}, content={self.content})"


def parse(content: str) -> List[HTMLElement]:
    """
    Parses the given HTML content and returns a list of HTMLElements.
    """
    tokens = tokenize(content)
    stack = []
    result = []

    for token in tokens:
        if is_start_tag(token):
            element = HTMLElement(get_tag_name(token), [], get_attributes(token))
            if is_self_closing(token) or element.name.lower() in VOID_ELEMENTS:
                # Void elements (such as <br> or <input ...>) and self closing
                # elements are already complete, so they are attached to their
                # parent right away instead of waiting for a closing tag.
                attach(element, stack, result)
            else:
                stack.append(element)
        elif is_end_tag(token):
            if stack:
                attach(stack.pop(), stack, result)
        elif stack:
            stack[-1].content.append(token)

    # Elements that are still on the stack were never closed. Instead of
    # dropping them they are attached like any other completed element.
    while stack:
        attach(stack.pop(), stack, result)

    return result


def attach(element: HTMLElement, stack: List[HTMLElement],
           result: List[HTMLElement]) -> None:
    # Adds a completed element to its parent element, or to the top level
    # result if it has no open parent.
    if stack:
        stack[-1].content.append(element)
    else:
        result.append(element)


def tokenize(content: str) -> List[str]:
    # This regex splits the content into tags and text.
    # It looks for anything that starts with '<' and ends with '>', and treats it as a tag.
    # Everything else is treated as text.
    return re.findall(r'<[^>]+>|[^<]+', content)


def is_start_tag(token: str) -> bool:
    # A start tag starts with '<' but does not start with '</'.
    return token.startswith('<') and not token.startswith('</')


def is_end_tag(token: str) -> bool:
    # An end tag starts with '</'.
    return token.startswith('</')


def is_self_closing(token: str) -> bool:
    # A self closing tag ends with '/>'.
    return token.strip().endswith('/>')


def get_tag_body(token: str) -> str:
    # Extracts the inside of a tag token, i.e. everything between the angle
    # brackets, without the leading '<' or '</' and without a trailing '/' or
    # '>'. Quoted attribute values are left untouched.
    body = token.strip()
    if body.startswith('</'):
        body = body[2:]
    elif body.startswith('<'):
        body = body[1:]
    if body.endswith('>'):
        body = body[:-1]
    return body.rstrip('/').strip()


def get_tag_name(token: str) -> str:
    # Extracts the tag name from a token.
    # The tag name is only the first word of the token, so that any attributes
    # that follow it are ignored.
    words = get_tag_body(token).split()
    return words[0] if words else ''


def get_attributes(token: str) -> Dict[str, str]:
    # Extracts the attributes from a start tag token and returns them as a
    # dictionary. The first word of the token is the tag name, so everything
    # after it is treated as attributes. Values may be double quoted, single
    # quoted or unquoted, and quoted values may contain spaces. An attribute
    # without a value gets an empty string as its value.
    words = get_tag_body(token).split(None, 1)
    if len(words) < 2:
        return {}

    attributes = {}
    for match in ATTRIBUTE_PATTERN.finditer(words[1]):
        name = match.group(1)
        double_quoted, single_quoted, unquoted = match.group(2, 3, 4)
        if double_quoted is not None:
            value = double_quoted
        elif single_quoted is not None:
            value = single_quoted
        elif unquoted is not None:
            value = unquoted
        else:
            value = ''
        attributes[name] = value
    return attributes
