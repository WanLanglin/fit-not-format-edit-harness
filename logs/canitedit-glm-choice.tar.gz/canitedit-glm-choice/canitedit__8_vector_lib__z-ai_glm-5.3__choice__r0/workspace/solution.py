import math
from abc import ABC, abstractmethod

class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


class MyVector(Vector):
    def __init__(self, *args: int):
        super().__init__(*args)

    def manhattan_distance(self, other: Vector) -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError(
                "Vectors must have the same length to compute manhattan distance"
            )

        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def cosine_similarity(self, other: Vector) -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError(
                "Vectors must have the same length to compute cosine similarity"
            )

        dot_product = sum(a * b for a, b in zip(self.vals, other.vals))
        self_magnitude = sum(a * a for a in self.vals) ** 0.5
        other_magnitude = sum(b * b for b in other.vals) ** 0.5

        if self_magnitude == 0 or other_magnitude == 0:
            raise ValueError("Cannot compute cosine similarity with a zero vector")

        cosine = dot_product / (self_magnitude * other_magnitude)
        # Clamp to guard against floating point drift outside [-1, 1]
        cosine = max(-1.0, min(1.0, cosine))

        return float(math.acos(cosine))

