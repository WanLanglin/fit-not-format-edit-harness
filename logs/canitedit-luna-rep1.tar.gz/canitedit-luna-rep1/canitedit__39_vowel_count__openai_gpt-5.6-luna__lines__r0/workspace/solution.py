import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

DIPHTHONGS = ("aea", "ae", "oe", "ei", "ea", "ia", "io")


def vowel_count(line):
    """Count vowels while treating the listed diphthongs as single sounds."""
    line = prepare_line(line)
    count = 0
    index = 0
    while index < len(line):
        diphthong = next(
            (item for item in DIPHTHONGS if line.startswith(item, index)), None
        )
        if diphthong:
            index += len(diphthong)
        else:
            if line[index] in "aeiouy":
                count += 1
            index += 1
    return count
