import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    vowels = "aeiouy"
    words = line.split(" ")
    for word, next_word in zip(words, words[1:]):
        if not next_word:
            continue

        starts_with_vowel = next_word[0] in vowels
        starts_with_h_vowel = (
            len(next_word) > 1
            and next_word[0] == "h"
            and next_word[1] in vowels
        )
        ends_with_vowel = bool(word) and word[-1] in vowels
        ends_with_vowel_m = len(word) > 1 and word[-2] in vowels and word[-1] == "m"
        ends_with_vowel_h = len(word) > 1 and word[-2] in vowels and word[-1] == "h"

        if ((ends_with_vowel or ends_with_vowel_m or ends_with_vowel_h)
                and starts_with_vowel):
            syllable_count += 1
        elif ends_with_vowel_m and starts_with_h_vowel:
            syllable_count += 1

    return syllable_count
