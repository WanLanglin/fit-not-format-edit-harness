import hashlib
from typing import Tuple


# Domain separation tag for the Fiat-Shamir challenge: it binds every challenge to
# this exact protocol version so digests can never be reused across protocols.
_CHALLENGE_DOMAIN = b"SCHNORR-NIZK-SHA256-V1"


def keygen(p: int, g: int, x: int) -> Tuple[Tuple[int, int, int], int]:
    """generate public and private key with given prime (p), base (g), and private key (x)."""
    y = pow(g, x, p)  # public key
    return (p, g, y), x


def prover_commitment(p: int, g: int, r: int) -> Tuple[int, int]:
    """step 1: Prover sends a commitment with given random value (r)."""
    t = pow(g, r, p)
    return t, r


def _encode(value: int) -> bytes:
    """canonical, injective and collision-free encoding of an integer (length prefixed)."""
    magnitude = abs(int(value))
    body = magnitude.to_bytes((magnitude.bit_length() + 7) // 8, "big")
    # sign flag + 4 byte length prefix + magnitude bytes, so no two distinct
    # tuples of inputs can ever produce the same byte string.
    sign = b"\x00" if int(value) >= 0 else b"\x01"
    return sign + len(body).to_bytes(4, "big") + body


def _hash_bytes(t: int, y: int, p: int, bits: int) -> bytes:
    """SHA-256 in counter mode over the full public transcript (p, y, t, bits)."""
    needed = max(1, (bits + 7) // 8)
    out = bytearray()
    counter = 0
    while len(out) < needed:
        digest = hashlib.sha256()
        # every supplied value feeds the hash: domain tag, counter, p, y, t, bits
        digest.update(_CHALLENGE_DOMAIN)
        digest.update(_encode(counter))
        digest.update(_encode(p))
        digest.update(_encode(y))
        digest.update(_encode(t))
        digest.update(_encode(bits))
        out += digest.digest()
        counter += 1
    return bytes(out[:needed])


def hash_to_challenge(t: int, y: int, p: int, bits: int = 256) -> int:
    """step 2 (non-interactive): derive the verifier challenge from the transcript.

    Fiat-Shamir heuristic: instead of waiting for the verifier to send a random
    challenge, the prover computes it as ``SHA-256`` over *all* public protocol
    values - the commitment ``t``, the public key ``y`` and the prime ``p`` (plus
    the requested challenge width).  Because the hash input covers ``t``, the
    commitment cannot be chosen after the challenge is known, which makes the
    transcript non-malleable and the protocol non-interactive.

    The returned challenge always satisfies ``1 <= c <= p-1``.
    """
    # a challenge can never be wider than the group order without losing entropy
    bits = min(max(int(bits), 1), max((int(p) - 1).bit_length(), 1))
    candidate = int.from_bytes(_hash_bytes(t, y, p, bits), "big")
    # reduce into [1, p-1]; the bias is negligible for real-size primes and this
    # keeps the challenge valid even for small testing primes.
    return candidate % max(int(p) - 1, 1) + 1


def prover_response(r: int, c: int, x: int, p: int) -> int:
    """step 3: Prover sends a response."""
    s = (r + c * x) % (p-1)
    return s


def verifier_check(p: int, g: int, y: int, t: int, c: int, s: int) -> bool:
    """verifier checks the prover's response.

    ``c`` may be passed as ``None`` so the verifier derives the challenge itself
    from the transcript ``(t, y, p)`` - which is what a non-interactive verifier
    does, since a NIZK proof is only the pair ``(t, s)``.
    """
    # in the non-interactive setting the verifier re-derives the challenge itself
    if c is None:
        c = hash_to_challenge(t, y, p)
    return pow(g, s, p) == (t * pow(y, c, p)) % p


def schnorr_protocol(p: int, g: int, x: int, r: int, bits: int = 256) -> bool:
    """demonstrate the non-interactive (Fiat-Shamir) Schnorr protocol with given values."""
    if (not 2 <= g <= p-1) or (not 2 <= x <= p-2) or (not 2 <= r <= p-2):
        return False
    # key generation
    params, x = keygen(p, g, x)
    p, g, y = params

    # step 1: Commitment
    t, r = prover_commitment(p, g, r)

    # step 2: Challenge - computed by the prover from the transcript (no verifier round)
    c = hash_to_challenge(t, y, p, bits)

    # step 3: Response
    s = prover_response(r, c, x, p)

    # verification: the verifier recomputes c from (t, y, p) and checks the equation
    return verifier_check(p, g, y, t, c, s)
