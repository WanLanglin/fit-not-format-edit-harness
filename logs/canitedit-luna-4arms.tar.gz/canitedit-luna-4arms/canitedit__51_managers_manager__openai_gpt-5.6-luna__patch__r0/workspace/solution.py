from typing import List, Union

class Manager:
    def __init__(self, name: str, direct_reports: List[Union["Manager", "IC"]]):
        self.name = name
        self.team = direct_reports
    
    def find_manager_n(self, name: str, n: int) -> List[str]:
        if n < 1:
            raise ValueError("n must be at least 1")

        manager_names = self._find_manager_n(name, n, [])
        return sorted(list(set(manager_names)))

    def _find_manager_n(self, name: str, n: int, path: List[str]) -> List[str]:
        path = path + [self.name]
        manager_names = []

        if self.name == name and len(path) > n:
            manager_names.append(path[-n - 1])

        for direct_report in self.team:
            if isinstance(direct_report, Manager):
                manager_names.extend(direct_report._find_manager_n(name, n, path))
            elif direct_report.name == name and len(path) >= n:
                manager_names.append(path[-n])

        return manager_names
    
class IC:
    def __init__(self, name: str):
        self.name = name
