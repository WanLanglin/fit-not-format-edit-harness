from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        stack: List[float] = []
        for token in inputs:
            if isinstance(token, str):
                # token is an operator
                if len(stack) < 2:
                    raise Exception("Malformed input: not enough operands")
                b = stack.pop()
                a = stack.pop()
                if token == "+":
                    stack.append(a + b)
                elif token == "-":
                    stack.append(a - b)
                elif token == "*":
                    stack.append(a * b)
                elif token == "/":
                    stack.append(a / b)
            else:
                # token is a number
                stack.append(float(token))

        if len(stack) != 1:
            raise Exception("Malformed input: more than one number remaining")
        return stack[0]
