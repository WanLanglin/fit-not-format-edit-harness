from abc import ABC, abstractmethod


class Message(ABC):
    """Abstract base class for a message carrying some content."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Return the processed representation of this message."""


class TextMessage(Message):
    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    """Create :class:`Message` instances from a message type string."""

    _MESSAGES = {
        "text": TextMessage,
        "image": ImageMessage,
    }

    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        message_class = MessageFactory._MESSAGES.get(message_type)
        if message_class is None:
            raise ValueError(f"Unknown message type: {message_type!r}")
        return message_class(content)
