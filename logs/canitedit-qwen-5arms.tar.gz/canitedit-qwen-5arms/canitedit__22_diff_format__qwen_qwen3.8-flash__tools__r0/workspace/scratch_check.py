"""Scratch harness (not part of the task): apply the emitted rel diff and
verify the result equals `after`.

Two appliers:
  apply_simple - literal format semantics: 0<add> prepends before line 1,
                 x<add> inserts after line x, x<del> removes line x,
                 x<del><add> replaces line x.
  apply_slots  - same, but every op on line x fully rewrites that line's slot
                 (the shape the original code emitted).
"""
import re
import sys
from typing import Dict, List

sys.path.insert(0, "/home/nina/workspace/src")
from solution import create_rel_diff, apply_diff  # noqa: E402


def _parse(text: str, diff: str):
    before_l = [] if text == "" else text.split("\n")
    ops = []
    for chunk in diff.split("\n"):
        m = re.match(r"^(\d+)(<del><add>|<add>|<del>)(.*)$", chunk, re.S)
        assert m, repr(chunk)
        n, op, payload = int(m.group(1)), m.group(2), m.group(3)
        assert 0 <= n <= len(before_l), (repr(chunk), len(before_l))
        if op != "<add>":
            assert n != 0, (repr(chunk), len(before_l))
        if op == "<del>":
            assert payload == "", repr(chunk)
        ops.append((n, op, payload))
    return before_l, ops


def apply_simple(text: str, diff: str) -> List[str]:
    before_l, ops = _parse(text, diff)
    prepend: List[str] = []
    delete = set()
    replace: Dict[int, str] = {}
    after: Dict[int, List[str]] = {i: [] for i in range(len(before_l) + 1)}
    for n, op, payload in ops:
        if op == "<del>":
            delete.add(n)
        elif op == "<del><add>":
            replace[n] = payload
        elif n == 0:
            prepend.append(payload)
        else:
            after[n].append(payload)
    out = list(prepend)
    for i in range(1, len(before_l) + 1):
        if i in replace:
            out.append(replace[i])
        elif i not in delete:
            out.append(before_l[i - 1])
        out.extend(after[i])
    return out


def apply_slots(text: str, diff: str) -> List[str]:
    before_l, ops = _parse(text, diff)
    slot: Dict[int, List[str]] = {i: [] for i in range(len(before_l) + 1)}
    touched = set()
    for n, op, payload in ops:
        if op == "<add>":
            slot[n].append(payload)
        else:
            slot[n] = [] if op == "<del>" else [payload]
        touched.add(n)
    out = list(slot[0])
    for i in range(1, len(before_l) + 1):
        if i in touched:
            out.extend(slot[i])
        else:
            out.append(before_l[i - 1])
    return out


def check(before: str, after: str, expect_prepend: bool = False, label: str = "") -> str:
    diff = create_rel_diff(before, after)
    want = [] if after == "" else after.split("\n")
    got_s = apply_simple(before, diff)
    got_k = apply_slots(before, diff)
    has_pre = bool(diff) and any(l.startswith("0<add>") for l in diff.split("\n"))
    ok = got_s == want and got_k == want
    print(f"{'ok  ' if ok else 'FAIL'} {label:24s} {'prepend' if has_pre else '       '} "
          f"before={before!r} after={after!r} diff={diff!r}")
    if not ok:
        print(f"     want={want!r}\n     simple={got_s!r}\n     slots={got_k!r}")
    assert ok, (label, before, after, diff, got_s, got_k)
    if expect_prepend:
        assert has_pre, (before, after, diff)
    return diff


def fuzz():
    import itertools
    import random

    random.seed(7)
    alpha = "ab"
    count = 0
    for bl in range(0, 5):
        for al in range(1, 5):
            for b_lines in itertools.product(alpha, repeat=bl):
                before = "\n".join(b_lines)
                for _ in range(20):
                    after = "\n".join(random.choice(alpha) for _ in range(al))
                    d = create_rel_diff(before, after)
                    want = after.split("\n")
                    assert apply_simple(before, d) == want, ("simple", before, after, d)
                    assert apply_slots(before, d) == want, ("slots", before, after, d)
                    count += 1
    print(f"fuzz1 ok ({count} pairs)")

    words = [f"w{i}" for i in range(12)]
    random.seed(11)
    for _ in range(500):
        before = "\n".join(random.sample(words, random.randint(0, 8)))
        after = "\n".join(random.sample(words, random.randint(1, 8)))
        d = create_rel_diff(before, after)
        assert apply_simple(before, d) == after.split("\n"), (before, after, d)
    print("fuzz2 ok")

    random.seed(3)
    for _ in range(300):
        b_lines = [random.choice(words) for _ in range(random.randint(1, 6))]
        extra = [random.choice(words) for _ in range(random.randint(1, 3))]
        before, after = "\n".join(b_lines), "\n".join(extra + b_lines)
        d = create_rel_diff(before, after)
        assert apply_simple(before, d) == after.split("\n"), (before, after, d)
        assert apply_slots(before, d) == after.split("\n"), (before, after, d)
        assert all(l.startswith("0<add>") for l in d.split("\n")), (before, after, d)
    print("fuzz3 (prepend-only) ok")

    random.seed(5)
    tiny = ["x", "y"]
    for _ in range(500):
        before = "\n".join(random.choice(tiny) for _ in range(random.randint(1, 7)))
        after = "\n".join(random.choice(tiny) for _ in range(random.randint(1, 7)))
        d = create_rel_diff(before, after)
        assert apply_simple(before, d) == after.split("\n"), (before, after, d)
    print("fuzz4 ok")


if __name__ == "__main__":
    check("abc\ndef\nghi", "abc\nq\nghi", label="replace middle")
    check("abc\ndef\nghi", "abc\ndef\nghi\nq\nr", label="append")
    check("abc\ndef\nghi", "x\ny\nabc\ndef\nghi", expect_prepend=True, label="prepend")
    check("abc\ndef\nghi", "def\nghi", label="del first 2")
    check("abc\ndef\nghi", "abc\ndef", label="del last")
    check("abc\ndef", "abc\ndef", label="identical")
    check("a\nb\nc", "a\nq\nc", label="middle change")
    check("a\nb\nc", "a\nq\nb\nq\nc\nq", label="mixed")
    check("a\nb\nc\nb\na", "b\nc\nb", label="subseq")
    check("a\nb\nc\nb\na", "z\na\nb\nc\nb\na", expect_prepend=True, label="prepend dup-ish")
    check("q\nr\ns", "q\nz\nr\ns", label="insert after first")
    check("q\nr\ns", "q\nr\nz\ns", label="insert before last")
    check("1\n2\n3\n4\n5\n6", "1\nX\n2\n3\nY\nZ\n4\n5\n6\n7", label="mid inserts")
    check("same\nsame\nsame", "same\nsame\nsame", label="all dupes")
    check("a", "b", label="single change")
    check("a", "a\nb", label="single append")
    check("a", "b\na", expect_prepend=True, label="single prepend")
    check("", "x", label="empty before")
    check("abc\ndef", "abc", label="drop one")
    check("Header\nThe quick brown fox", "The quick brown fox", label="del line 1")
    check("The quick brown fox\njumps over\nlazy dogs",
          "Header\nThe quick brown fox\njumps over the\nlazy dogs", label="realistic")

    # the module's own applier must agree on these shapes
    for before, after in [("abc\ndef\nghi", "x\ny\nabc\ndef\nghi"),
                          ("a\nb\nc", "a\nq\nb\nq\nc\nq"),
                          ("1\n2\n3\n4\n5\n6", "1\nX\n2\n3\nY\nZ\n4\n5\n6\n7")]:
        got = apply_diff(before, create_rel_diff(before, after))
        assert got == after.split("\n"), (before, after, got)
    print("solution.apply_diff ok")

    print("all targeted checks passed")
    fuzz()
