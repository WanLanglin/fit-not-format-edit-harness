class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int):
        result = []
        a, b = self.prev_prev, self.prev
        for _ in range(n):
            a, b = b, a + b
            result.append(b)
        return result
