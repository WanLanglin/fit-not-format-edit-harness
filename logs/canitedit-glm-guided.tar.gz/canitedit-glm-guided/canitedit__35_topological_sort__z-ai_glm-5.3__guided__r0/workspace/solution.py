from collections import deque
from typing import List

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Return the nodes ordered so that every node appears after all
        the nodes it can be reached from. Raises RuntimeError if the
        graph contains a cycle.'''
        nodes_by_id = {node.id: node for node in self.nodes}
        if len(nodes_by_id) != len(self.nodes):
            raise RuntimeError("Graph contains duplicate nodes")

        # Count how many edges point at each node (edges leaving the
        # graph are ignored).
        in_degree = {node_id: 0 for node_id in nodes_by_id}
        for node in self.nodes:
            for target in node.out_edges:
                if target in in_degree:
                    in_degree[target] += 1

        # Kahn's algorithm: repeatedly take a node that nothing points at.
        queue = deque(node.id for node in self.nodes if in_degree[node.id] == 0)
        sorted_nodes: List[Node] = []
        while queue:
            node_id = queue.popleft()
            sorted_nodes.append(nodes_by_id[node_id])
            for target in nodes_by_id[node_id].out_edges:
                if target in in_degree:
                    in_degree[target] -= 1
                    if in_degree[target] == 0:
                        queue.append(target)

        if len(sorted_nodes) != len(self.nodes):
            raise RuntimeError("Graph contains a cycle, cannot sort topologically")
        return sorted_nodes
