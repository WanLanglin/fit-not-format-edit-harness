from typing import List, Tuple

def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Return the maximum subarray sum together with its boundaries.

    The result is a tuple of ``(sum, srt_idx, end_idx)`` where ``srt_idx`` and
    ``end_idx`` are the inclusive indices of the subarray that produces the
    maximum sum.
    """
    max_so_far = lst[0]
    curr_max = lst[0]
    srt_idx = 0      # start index of the best subarray seen so far
    curr_srt = 0     # start index of the current running subarray
    end_idx = 0
    for i in range(1, len(lst)):
        if lst[i] > curr_max + lst[i]:
            curr_max = lst[i]
            curr_srt = i
        else:
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            srt_idx = curr_srt
            end_idx = i
    return max_so_far, srt_idx, end_idx
