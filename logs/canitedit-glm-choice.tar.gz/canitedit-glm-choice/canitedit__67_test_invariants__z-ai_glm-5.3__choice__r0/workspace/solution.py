class Employer:
    """
    Represents an entity that employs workers.
    """

    def __init__(self, name, funds):
        self.name = name
        self.funds = funds


class Worker:
    """
    Represents a person who does work for an employer.
    Name should be "[first name] [last name]" and pay 
    should be positive.
    """

    def __init__(self, name, pay, company):
        self.name = name
        self.pay = pay
        self.company = company
        self.money = 0

    def lastName(self):
        """
        Returns the last name of the worker.
        """
        return self.name.split()[-1]

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay
        self.company.funds -= self.pay

    def giveRaise(self, percent):
        """
        Gives the worker a raise in pay, given as a percentage of
        the current pay.
        """
        self.pay *= (1.0 + percent)


class PublicWorker(Worker):
    """
    Represents a worker who works for the government.
    People who work for the government are special
    because they are paid with public funds, which
    are virtually unlimited because of public debt.
    """

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay


def _close(actual, expected):
    """
    True when `actual` equals `expected`, allowing only the tiny
    rounding error that floating point arithmetic can introduce.
    """
    if actual == expected:
        return True
    try:
        return abs(actual - expected) <= 1e-9 * max(1.0, abs(expected)) + 1e-12
    except TypeError:
        return False


def _is_non_negative_number(x):
    """
    True when `x` is a number that is zero or positive.
    """
    if isinstance(x, bool):
        return False
    try:
        return x == x and x >= 0 and x + 0 == x
    except TypeError:
        return False


def test_worker_invariants(w: Worker):
    """
    Check every invariant of the Worker `w` with assert.

    * `name` is a first name and a last name separated by a single
      space, and `lastName()` returns that last name.
    * `pay` is a non-negative number, and so is the `money` the worker
      has been paid so far; the company's `funds` are a number too.
    * `givePay()` adds exactly the worker's pay to the worker's money
      and removes exactly the worker's pay from the company's funds,
      so the pay moves from the company to the worker, and nothing
      else changes.  Paying twice pays twice.
    * `giveRaise(percent)` multiplies the worker's pay by 1.0 + percent
      (a percentage of the current pay, not a flat amount) and changes
      nothing else.

    The payments and raises performed here are undone, so `w` and
    `w.company` are left exactly as they were found.
    """

    # The fields and methods that the invariants talk about exist.
    for field in ("name", "pay", "money", "company"):
        assert hasattr(w, field), ("a Worker must have a '%s' field" % field)
    assert hasattr(w.company, "funds"), (
        "a Worker's company must have a 'funds' field")
    for method in ("lastName", "givePay", "giveRaise"):
        assert callable(getattr(w, method, None)), (
            "a Worker must have a '%s()' method" % method)

    # The name is "[first name] [last name]".
    assert isinstance(w.name, str), "name must be a string"
    parts = w.name.split(" ")
    assert len(parts) == 2, 'name must be "[first name] [last name]"'
    assert parts[0] != "", "the first name must not be empty"
    assert parts[1] != "", "the last name must not be empty"
    assert w.lastName() == parts[1], "lastName() must return the last name"

    # The pay and the money held are non-negative numbers.
    assert _is_non_negative_number(w.pay), "pay must be non-negative"
    assert _is_non_negative_number(w.money), "money must be non-negative"
    assert _is_non_negative_number(w.company.funds), (
        "the company's funds must be a number")

    name, pay, money = w.name, w.pay, w.money
    funds = w.company.funds

    # givePay(): the pay moves from the company to the worker.
    w.givePay()
    assert _close(w.money, money + pay), (
        "givePay() must add exactly the worker's pay to the worker's money")
    assert _close(w.company.funds, funds - pay), (
        "givePay() must remove exactly the worker's pay from the "
        "company's funds")
    assert _close(w.money + w.company.funds, money + funds), (
        "givePay() must move the pay from the company to the worker")
    assert w.name == name, "givePay() must not change the name"
    assert w.pay == pay, "givePay() must not change the pay"
    w.givePay()  # paying again must pay again, not start over
    assert _close(w.money, money + 2 * pay), (
        "givePay() must accumulate the money it pays")
    assert _close(w.company.funds, funds - 2 * pay), (
        "givePay() must accumulate the funds it spends")
    w.money = money              # undo the payments
    w.company.funds = funds

    # giveRaise(percent): the pay is scaled by 1.0 + percent.
    for percent in (0.5, -0.25, 0.0):
        w.giveRaise(percent)
        assert _close(w.pay, pay * (1.0 + percent)), (
            "giveRaise(p) must multiply the pay by 1.0 + p")
        assert w.pay >= 0, "pay must stay non-negative after a raise"
        assert w.name == name, "giveRaise() must not change the name"
        assert w.money == money, "giveRaise() must not change the money"
        assert w.company.funds == funds, (
            "giveRaise() must not change the company's funds")
        w.pay = pay              # undo the raise

    # A raise is a percentage of the current pay, not a flat amount:
    # 123 * 1.5 is 184.5, while 123 + 0.5 is only 123.5.
    w.pay = 123.0
    w.giveRaise(0.5)
    assert _close(w.pay, 184.5), (
        "giveRaise(p) must scale the pay by 1.0 + p, not add p to it")
    w.pay = pay                  # restore the worker's pay


def test_public_worker_invariants(w: PublicWorker):
    """
    Check every invariant of the PublicWorker `w` with assert.

    A PublicWorker is a Worker, so the Worker invariants hold:
    * `name` is a first name and a last name separated by a single
      space, and `lastName()` returns that last name.
    * `pay` is a non-negative number, and so is the `money` the worker
      has been paid so far; the company's `funds` are a number too.
    * `giveRaise(percent)` multiplies the worker's pay by 1.0 + percent
      and changes nothing else.

    The difference is who pays: a PublicWorker is paid with public
    funds, which are virtually unlimited because of public debt, so
    * `givePay()` adds exactly the worker's pay to the worker's money
      while the company's funds are left completely untouched, and
      nothing else changes.  Paying twice pays twice.

    The payments and raises performed here are undone, so `w` and
    `w.company` are left exactly as they were found.
    """

    # The fields and methods that the invariants talk about exist.
    for field in ("name", "pay", "money", "company"):
        assert hasattr(w, field), ("a Worker must have a '%s' field" % field)
    assert hasattr(w.company, "funds"), (
        "a Worker's company must have a 'funds' field")
    for method in ("lastName", "givePay", "giveRaise"):
        assert callable(getattr(w, method, None)), (
            "a Worker must have a '%s()' method" % method)

    # The name is "[first name] [last name]".
    assert isinstance(w.name, str), "name must be a string"
    parts = w.name.split(" ")
    assert len(parts) == 2, 'name must be "[first name] [last name]"'
    assert parts[0] != "", "the first name must not be empty"
    assert parts[1] != "", "the last name must not be empty"
    assert w.lastName() == parts[1], "lastName() must return the last name"

    # The pay and the money held are non-negative numbers.
    assert _is_non_negative_number(w.pay), "pay must be non-negative"
    assert _is_non_negative_number(w.money), "money must be non-negative"
    assert _is_non_negative_number(w.company.funds), (
        "the company's funds must be a number")

    name, pay, money = w.name, w.pay, w.money
    funds = w.company.funds

    # givePay(): the public pays, so the company's funds are untouched.
    w.givePay()
    assert _close(w.money, money + pay), (
        "givePay() must add exactly the worker's pay to the worker's money")
    assert w.company.funds == funds, (
        "a PublicWorker is paid with public funds, so givePay() must "
        "leave the company's funds alone")
    assert w.name == name, "givePay() must not change the name"
    assert w.pay == pay, "givePay() must not change the pay"
    w.givePay()  # paying again must pay again, not start over
    assert _close(w.money, money + 2 * pay), (
        "givePay() must accumulate the money it pays")
    assert w.company.funds == funds, (
        "a PublicWorker is paid with public funds, so givePay() must "
        "leave the company's funds alone")
    w.money = money              # undo the payments

    # giveRaise(percent) is inherited from Worker: the pay is scaled by
    # 1.0 + percent.
    for percent in (0.5, -0.25, 0.0):
        w.giveRaise(percent)
        assert _close(w.pay, pay * (1.0 + percent)), (
            "giveRaise(p) must multiply the pay by 1.0 + p")
        assert w.pay >= 0, "pay must stay non-negative after a raise"
        assert w.name == name, "giveRaise() must not change the name"
        assert w.money == money, "giveRaise() must not change the money"
        assert w.company.funds == funds, (
            "giveRaise() must not change the company's funds")
        w.pay = pay              # undo the raise

    # A raise is a percentage of the current pay, not a flat amount:
    # 123 * 1.5 is 184.5, while 123 + 0.5 is only 123.5.
    w.pay = 123.0
    w.giveRaise(0.5)
    assert _close(w.pay, 184.5), (
        "giveRaise(p) must scale the pay by 1.0 + p, not add p to it")
    w.pay = pay                  # restore the worker's pay
