class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """Compute the shortest distances from ``start`` to all nodes.

        Bellman-Ford is used instead of Dijkstra so that negative edge weights
        are supported.  A negative cycle anywhere in the graph makes shortest
        paths undefined and results in ``ValueError``.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0
        nodes = list(self.nodes)

        # Relax every edge at most |V| - 1 times.  Iterating over the
        # adjacency lists is intentional: add_edge stores both directions.
        for _ in range(len(nodes) - 1):
            changed = False
            for node in nodes:
                if shortest_path[node] == float('infinity'):
                    continue
                for neighbor, weight in self.edges[node]:
                    distance = shortest_path[node] + weight
                    if distance < shortest_path[neighbor]:
                        shortest_path[neighbor] = distance
                        changed = True
            if not changed:
                break

        # A further relaxation means a negative cycle is reachable from the
        # source.  Check unreachable components too, since the contract is to
        # reject any negative cycle in the graph.  Initialising all nodes to
        # zero is equivalent to adding a zero-weight super-source.
        cycle_check = {node: 0 for node in nodes}
        for _ in range(len(nodes)):
            changed = False
            for node in nodes:
                for neighbor, weight in self.edges[node]:
                    if cycle_check[node] + weight < cycle_check[neighbor]:
                        cycle_check[neighbor] = cycle_check[node] + weight
                        changed = True
            if not changed:
                break
        if changed:
            raise ValueError('Graph contains a negative cycle')

        return shortest_path
