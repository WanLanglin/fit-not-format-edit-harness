from solution import FitnessTracker, StepCounter


def test_distance_zero_when_no_steps_recorded():
    tracker = FitnessTracker()
    tracker.record_activity(0)
    assert tracker.step_counter.get_distance() == 0
    assert tracker.get_summary() == "Total steps: 0, Total distance: 0 km"


def test_distance_updates_at_exact_steps_per_km():
    tracker = FitnessTracker()
    tracker.record_activity(1250)  # exactly steps_per_km
    assert tracker.step_counter.get_distance() == 1
    assert tracker.get_summary() == "Total steps: 1250, Total distance: 1 km"


def test_distance_accumulates_across_additions():
    tracker = FitnessTracker()
    tracker.record_activity(1000)
    tracker.record_activity(250)  # reaches exactly 1250 total
    assert tracker.step_counter.get_distance() == 1
    tracker.record_activity(1250)  # 2500 total = 2 km
    assert tracker.step_counter.get_distance() == 2


def test_partial_distance_is_floored():
    tracker = FitnessTracker()
    tracker.record_activity(1249)
    assert tracker.step_counter.get_distance() == 0
    tracker.record_activity(1)
    assert tracker.step_counter.get_distance() == 1
