from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort ``lst`` in ascending order, in place, and return it.

    This is a top-down merge sort tuned for inputs that already contain large
    sorted runs (fully sorted, reverse-ish, "sorted with a few holes", ...):

    * Early termination: after the two halves are sorted, if the greatest
      element of the left half is <= the smallest element of the right half
      the two runs are already ordered relative to each other, so the whole
      merge step is skipped (0 element comparisons, 0 element copies).
      A fully sorted array is therefore sorted in O(n) time.
    * Copy minimisation: the destination buffer is allocated once (an
      auxiliary array reused at every level) and only the left run is
      copied into it before a merge, so each merged element is copied about
      half as often as in the textbook ``L = lst[:mid]; R = lst[mid:]`` form.
      When the left run is exhausted, the remaining right-hand elements are
      already sitting in their final positions and are not touched at all.
    * Only ``<`` is ever used to compare elements, and every merge step does
      a single comparison per placed element. Ties are resolved in favour of
      the left run, which keeps the sort stable (equal elements are never
      needlessly reordered).
    """
    if lst is None or len(lst) < 2:
        return lst
    aux = [0] * len(lst)
    _merge_sort(lst, aux, 0, len(lst))
    return lst


def _merge_sort(a: List[int], aux: List[int], lo: int, hi: int) -> None:
    """Sort the half-open slice ``a[lo:hi]`` using ``aux`` as scratch space."""
    if hi - lo < 2:
        return

    mid = (lo + hi) // 2
    _merge_sort(a, aux, lo, mid)
    _merge_sort(a, aux, mid, hi)

    # Early termination: the runs are already ordered relative to each other,
    # so there is nothing to merge.
    # Expressed with ``<`` only (a single comparison) so the check works for
    # any element type that supports ordering.
    if not (a[mid] < a[mid - 1]):
        return

    # Copy only the left run to the scratch buffer; the right run stays in
    # place inside ``a`` and is read (and, when it is exhausted first, left
    # untouched) directly from there.
    aux[lo:mid] = a[lo:mid]

    i = lo        # cursor into the left run (in ``aux``)
    j = mid       # cursor into the right run (in ``a``)
    for k in range(lo, hi):
        if i >= mid:
            # Left run consumed: the tail of the right run is already in
            # its final position, so no copies are needed.
            return
        if j >= hi:
            # Right run consumed: only the left-over left run must be moved.
            a[k:k + (mid - i)] = aux[i:mid]
            return
        if not (a[j] < aux[i]):
            # a[j] is not smaller than aux[i], so take the left run (stable).
            a[k] = aux[i]
            i += 1
        else:
            a[k] = a[j]
            j += 1
