from abc import ABC, abstractmethod
from math import sqrt

class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


class MyVector(Vector):
    def manhattan_distance(self, other: Vector) -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError("vectors must have the same length")

        return float(sum(abs(left - right) for left, right in zip(self.vals, other.vals)))

    def cosine_similarity(self, other: Vector) -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError("vectors must have the same length")

        self_magnitude = sqrt(sum(value * value for value in self.vals))
        other_magnitude = sqrt(sum(value * value for value in other.vals))
        if self_magnitude == 0 or other_magnitude == 0:
            raise ValueError("cosine similarity is undefined for a zero vector")

        dot_product = sum(left * right for left, right in zip(self.vals, other.vals))
        return float(dot_product / (self_magnitude * other_magnitude))
