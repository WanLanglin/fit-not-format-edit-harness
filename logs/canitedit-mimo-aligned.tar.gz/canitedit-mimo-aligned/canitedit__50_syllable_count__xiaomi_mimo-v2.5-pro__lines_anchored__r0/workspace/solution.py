import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    # Count combos at word boundaries
    words = line.split()
    combo_count = 0
    vowels = "aeiouy"

    for i in range(len(words) - 1):
        word1 = words[i]
        word2 = words[i + 1]

        # Check end patterns of word1
        ends_v = word1[-1] in vowels
        ends_vm = len(word1) >= 2 and word1[-2] in vowels and word1[-1] == 'm'

        # Check start patterns of word2
        starts_v = word2[0] in vowels
        starts_hv = len(word2) >= 2 and word2[0] == 'h' and word2[1] in vowels

        # Rule 1: V|V, Rule 2: Vm|V, Rule 3: V|hV, Rule 4: Vm|hV
        if (ends_v and starts_v) or (ends_vm and starts_v) or (ends_v and starts_hv) or (ends_vm and starts_hv):
            combo_count += 1

    syllable_count -= combo_count

    return syllable_count
