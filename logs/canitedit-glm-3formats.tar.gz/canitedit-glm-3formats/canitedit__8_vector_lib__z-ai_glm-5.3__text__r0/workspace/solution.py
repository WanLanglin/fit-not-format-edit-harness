from abc import ABC, abstractmethod

class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


import math


class MyVector(Vector):
    def __init__(self, *args: int):
        super().__init__(*args)

    def _check_same_length(self, other: Vector) -> None:
        if len(self.vals) != len(other.vals):
            raise ValueError(
                "Vectors must have the same length: "
                f"{len(self.vals)} != {len(other.vals)}"
            )

    def manhattan_distance(self, other: Vector) -> float:
        self._check_same_length(other)
        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def _magnitude(self) -> float:
        return math.sqrt(sum(val * val for val in self.vals))

    def cosine_similarity(self, other: Vector) -> float:
        self._check_same_length(other)

        self_magnitude = self._magnitude()
        other_magnitude = other._magnitude()
        if self_magnitude == 0 or other_magnitude == 0:
            raise ValueError(
                "Cannot compute cosine similarity of a zero-magnitude vector"
            )

        dot_product = sum(a * b for a, b in zip(self.vals, other.vals))
        cosine = dot_product / (self_magnitude * other_magnitude)
        # Guard against floating point drift pushing the value outside acos's domain.
        cosine = max(-1.0, min(1.0, cosine))
        return float(math.acos(cosine))
