import math
from abc import ABC, abstractmethod

class Vector(ABC):
    def __init__(self, *args: int):
        self.vals = args

    @abstractmethod
    def manhattan_distance(other) -> float:
        pass

    @abstractmethod
    def cosine_similarity(other) -> float:
        pass


class MyVector(Vector):
    def manhattan_distance(self, other: "Vector") -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError("Vectors must have the same length")
        return float(sum(abs(a - b) for a, b in zip(self.vals, other.vals)))

    def cosine_similarity(self, other: "Vector") -> float:
        if len(self.vals) != len(other.vals):
            raise ValueError("Vectors must have the same length")

        dot_product = sum(a * b for a, b in zip(self.vals, other.vals))
        self_magnitude = math.sqrt(sum(a * a for a in self.vals))
        other_magnitude = math.sqrt(sum(b * b for b in other.vals))

        if self_magnitude == 0 or other_magnitude == 0:
            raise ValueError("Vectors must not have a magnitude of zero")

        cosine = dot_product / (self_magnitude * other_magnitude)
        cosine = max(-1.0, min(1.0, cosine))
        return float(math.acos(cosine))
