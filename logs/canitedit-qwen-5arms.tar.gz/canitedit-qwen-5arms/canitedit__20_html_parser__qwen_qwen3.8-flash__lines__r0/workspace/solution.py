from typing import Dict, List, Optional, Union
import re


class HTMLElement:
    def __init__(self, name, content: List[Union[str, 'HTMLElement']],
                 attributes: Optional[Dict[str, str]] = None):
        self.name = name
        self.content = content
        # Dictionary of the HTML attributes of the element,
        # e.g. {'class': 'main nav', 'id': 'intro'}.
        self.attributes: Dict[str, str] = dict(attributes) if attributes else {}

    def __str__(self):
        attrs = ''.join(f' {name}="{value}"' for name, value in self.attributes.items())
        return f"<{self.name}{attrs}>{''.join(str(c) for c in self.content)}</{self.name}>"


def parse(content: str) -> List[HTMLElement]:
    """
    Parses the given HTML content and returns a list of HTMLElements.
    """
    tokens = tokenize(content)
    stack = []
    result = []

    for token in tokens:
        if is_start_tag(token):
            stack.append(HTMLElement(get_tag_name(token), [], get_attributes(token)))
        elif is_end_tag(token):
            element = stack.pop()
            if stack:
                stack[-1].content.append(element)
            else:
                result.append(element)
        else:
            if stack:
                stack[-1].content.append(token)

    return result


def tokenize(content: str) -> List[str]:
    # This regex splits the content into tags and text.
    # It looks for anything that starts with '<' and ends with '>', and treats it as a tag.
    # Everything else is treated as text.
    return re.findall(r'<[^>]+>|[^<]+', content)


def is_start_tag(token: str) -> bool:
    # A start tag starts with '<' but does not start with '</'.
    return token.startswith('<') and not token.startswith('</')


def is_end_tag(token: str) -> bool:
    # An end tag starts with '</'.
    return token.startswith('</')


def strip_tag_brackets(token: str) -> str:
    # Removes the surrounding '<' and '>' and the self-closing '/' so that only
    # the inside of the tag remains.
    inner = token[1:] if token.startswith('<') else token
    if inner.endswith('>'):
        inner = inner[:-1]
    if inner.endswith('/'):
        inner = inner[:-1]
    return inner


def get_tag_name(token: str) -> str:
    # Extracts the tag name from a token.
    # It removes '<', '>', and '/' from the token and selects the tag name from
    # the first word only, so the name is correct even when the element carries
    # attributes.
    parts = strip_tag_brackets(token).split(None, 1)
    return parts[0] if parts else ''


# A single attribute: a name, optionally followed by '=' and a value that is
# double quoted, single quoted, or unquoted.
ATTRIBUTE_RE = re.compile(
    r'''(?P<name>[^\s/>=<]+)\s*=\s*'''
    r'''(?:"(?P<double>[^"]*)"|'(?P<single>[^']*)'|(?P<bare>[^\s>]+))'''
    r'''|(?P<barename>[^\s/>=<]+)'''
)


def get_attributes(token: str) -> Dict[str, str]:
    """
    Extracts the HTML attributes from a tag token.

    Everything after the tag name is scanned for name/value pairs. An element
    may carry any number of attributes and a value may contain spaces, so a
    quoted value is taken verbatim between its quotes. Unquoted values end at
    whitespace, and an attribute name without a value maps to ''.
    """
    inner = strip_tag_brackets(token)

    # Everything after the first word (the tag name) is the attribute string.
    parts = inner.split(None, 1)
    attribute_string = parts[1] if len(parts) > 1 else ''

    attributes: Dict[str, str] = {}
    for match in ATTRIBUTE_RE.finditer(attribute_string):
        name = match.group('name') or match.group('barename')
        value = ''
        for group in ('double', 'single', 'bare'):
            found = match.group(group)
            if found is not None:
                value = found
                break
        attributes[name] = value

    return attributes
