from typing import List, Literal

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class MalformedExpression(ValueError):
    """raised when a sequence of tokens is not a well formed postfix expression"""


def operands(stack: List[float], operator: Token, position: int) -> tuple[float, float]:
    """the two numbers an operator applies to, the left one first

    Raises MalformedExpression when the operator is not preceded by two numbers.
    """
    if len(stack) < 2:
        raise MalformedExpression(
            f"malformed expression: operator {operator!r} at position {position} "
            "is not preceded by two numbers"
        )
    right = stack.pop()
    left = stack.pop()
    return left, right


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result

        The tokens are scanned from left to right until an operator is found, that operator
        is applied to the last two numbers and they are replaced by its result; the scan then
        starts again on the new sequence until no operators are left.

        Raises MalformedExpression when the input is malformed, that is when an operator is
        not preceded by two numbers, or when the process above ends with a sequence that has
        more than one number (or no number at all) remaining.
        """

        def parseHelp(tokens: List[Token], stack: List[float], position: int = 0) -> float:
            if not tokens:
                if len(stack) != 1:
                    raise MalformedExpression(
                        f"malformed expression: {len(stack)} numbers remain, "
                        "but exactly one is expected"
                    )
                return stack[0]
            token = tokens.pop(0)
            match token:
                case "+":
                    left, right = operands(stack, token, position)
                    stack.append(left + right)
                case "-":
                    left, right = operands(stack, token, position)
                    stack.append(left - right)
                case "*":
                    left, right = operands(stack, token, position)
                    stack.append(left * right)
                case "/":
                    left, right = operands(stack, token, position)
                    stack.append(left / right)
                case _:
                    if not isinstance(token, (int, float)):
                        raise MalformedExpression(
                            f"malformed expression: unexpected token {token!r} at position {position}"
                        )
                    stack.append(token)
            return parseHelp(tokens, stack, position + 1)

        return parseHelp(list(inputs))
