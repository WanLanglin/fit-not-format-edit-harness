import ast


class UsageCounter(ast.NodeVisitor):
    """
    Counts the usages of each identifier in the given AST.
    An usage does not count the definition or assignment itself;
    only identifiers that are used after their definition/assignment are counted.
    NOTE: This class does not handle the scoping rules of Python;
    it simply counts the usages based on the name of the identifiers.
    It also only supports identifiers defined in a function (its name and
    arguments) or in an assignment (including tuple/list unpacking).
    """

    def __init__(self):
        self.usages = {}

    def visit_Name(self, node):
        if node.id in self.usages:
            self.usages[node.id] += 1
            self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name not in self.usages:
            self.usages[node.name] = 0
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        if node.name not in self.usages:
            self.usages[node.name] = 0
        self.generic_visit(node)

    def visit_arguments(self, node):
        # The parameters of a function (or lambda) are definitions too, so they
        # have to be known before the body of the function is visited.
        for parameter in self._parameters(node):
            if parameter.arg not in self.usages:
                self.usages[parameter.arg] = 0
        self.generic_visit(node)

    @staticmethod
    def _parameters(arguments):
        """Every parameter of a function: positional, keyword, *args and **kwargs."""
        parameters = list(getattr(arguments, "posonlyargs", [])) + list(arguments.args)
        if arguments.vararg is not None:
            parameters.append(arguments.vararg)
        parameters.extend(arguments.kwonlyargs)
        if arguments.kwarg is not None:
            parameters.append(arguments.kwarg)
        return parameters

    def visit_Assign(self, node):
        defined = []
        for target in node.targets:
            defined.extend(self._defined_names(target))

        self.generic_visit(node)
        # The targets of an assignment are definitions, not usages.
        for name in defined:
            self.usages[name] -= 1

    def _defined_names(self, target):
        """The names defined by an assignment target, including tuple unpacking."""
        if isinstance(target, ast.Name):
            names = [target.id]
        elif isinstance(target, (ast.Tuple, ast.List)):
            names = []
            for element in target.elts:
                names.extend(self._defined_names(element))
        elif isinstance(target, ast.Starred):
            names = self._defined_names(target.value)
        else:
            # Other targets (attributes, subscripts, ...) define no new name.
            names = []

        for name in names:
            if name not in self.usages:
                self.usages[name] = 0
        return names
