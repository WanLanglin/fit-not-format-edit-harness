import string

VOWELS = "aeiouy"
# Longest first so that "aea" wins over the "ae" / "ea" it contains.
DIPHTHONGS = ("aea", "ae", "oe", "ei", "ea", "ia", "io")

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def diphthong_length(text, index):
    """Length of the longest diphthong in ``text`` starting at ``index``."""
    for diphthong in DIPHTHONGS:
        if text.startswith(diphthong, index):
            return len(diphthong)
    return 0

def vowel_count(line):
    text = prepare_line(line)
    vowel_count = 0
    index = 0
    while index < len(text):
        length = diphthong_length(text, index)
        if length:
            # A diphthong is not counted as a vowel: skip the whole run.
            index += length
            continue
        if text[index] in VOWELS:
            vowel_count += 1
        index += 1
    return vowel_count
