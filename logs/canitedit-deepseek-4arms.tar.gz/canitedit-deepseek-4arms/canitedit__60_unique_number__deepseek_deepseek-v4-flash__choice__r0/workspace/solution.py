from typing import List


def find_non_pair(numbers: List[int]) -> int:
    result = 0
    for number in numbers:
        result ^= number
    return result
