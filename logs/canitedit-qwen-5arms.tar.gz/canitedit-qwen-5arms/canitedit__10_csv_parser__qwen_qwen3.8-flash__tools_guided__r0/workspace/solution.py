import csv as _csv
import os


class CSVParser:
    def __init__(self, csv: str):
        self.csv = csv

    def contents(self) -> list[list[str]]:
        lines = self.csv.split("\n")
        output = []
        for line in lines:
            output.append(line.split(","))
        return output

    def header(self) -> list[str]:
        """Return the first row of the CSV text as a list of column names."""
        text = self.csv[1:] if self.csv.startswith("\ufeff") else self.csv
        rows = list(_csv.reader(text.splitlines()))
        return rows[0] if rows else []


def header(csv_file: str) -> list[str]:
    """Return the first row of a CSV file as a list of strings.

    ``csv_file`` may be either raw CSV text or the path to a file on disk.
    Each element of the returned list is one column of the first row; an empty
    list is returned when the CSV has no rows.
    """
    text = csv_file
    try:
        is_path = os.path.isfile(csv_file)
    except (OSError, ValueError):
        is_path = False
    if is_path:
        with open(csv_file, newline="", encoding="utf-8-sig") as handle:
            text = handle.read()
    return CSVParser(text).header()
