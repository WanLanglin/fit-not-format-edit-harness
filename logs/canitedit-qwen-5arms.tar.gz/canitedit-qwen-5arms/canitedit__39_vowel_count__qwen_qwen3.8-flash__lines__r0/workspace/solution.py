import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

DIPHTHONGS = ("aea", "ae", "oe", "ei", "ea", "ia", "io")

VOWELS = "aeiouy"

def vowel_count(line):
    vowel_count = 0
    text = prepare_line(line)
    index = 0
    while index < len(text):
        diphthong = next_diphthong(text, index)
        if diphthong is not None:
            index += len(diphthong)
            continue
        if text[index] in VOWELS:
            vowel_count += 1
        index += 1
    return vowel_count

def next_diphthong(text, index):
    for diphthong in DIPHTHONGS:
        if text.startswith(diphthong, index):
            return diphthong
    return None
