class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int):
        p_pp = self.prev_prev
        p = self.prev
        result = []
        for _ in range(n):
            output = p + p_pp
            p_pp = p
            p = output
            result.append(output)
        return result