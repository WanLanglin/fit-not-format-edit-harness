from collections import deque
from typing import Dict, List


class CyclicGraphError(RuntimeError, ValueError):
    '''Raised when a topological sort is requested for a cyclic graph.

    Inherits from both RuntimeError and ValueError so that callers may
    catch whichever of the two common choices they expect.
    '''

class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''Return the nodes ordered so that every node comes after all of
        the nodes that can reach it (Kahn's algorithm).

        Raises CyclicGraphError when the graph contains a cycle, because a
        cyclic graph has no topological order.
        '''
        # Group the nodes by id so that edges (which are ids) can be
        # resolved to the nodes they point at.
        nodes_by_id: Dict[int, List[Node]] = {}
        for node in self.nodes:
            nodes_by_id.setdefault(node.id, []).append(node)

        # Count how many edges still point at each id.
        in_degree = {node_id: 0 for node_id in nodes_by_id}
        for node in self.nodes:
            for target in node.out_edges:
                if target in in_degree:  # ignore edges leaving the graph
                    in_degree[target] += 1

        # Start with every node that nothing points at.
        ready = deque(node_id for node_id in in_degree if in_degree[node_id] == 0)
        ordered: List[Node] = []

        while ready:
            node_id = ready.popleft()
            for node in nodes_by_id[node_id]:
                ordered.append(node)
                for target in node.out_edges:
                    if target in in_degree:
                        in_degree[target] -= 1
                        if in_degree[target] == 0:
                            ready.append(target)

        # Nodes that never became ready sit on (or behind) a cycle.
        if len(ordered) != len(self.nodes):
            raise CyclicGraphError('The graph contains a cycle, '
                                   'so it cannot be sorted topologically')
        return ordered
