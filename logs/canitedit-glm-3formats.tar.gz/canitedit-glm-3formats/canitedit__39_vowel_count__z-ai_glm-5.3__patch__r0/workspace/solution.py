import string

DIPHTHONGS = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    """Count the vowels in a line, ignoring diphthongs.

    A diphthong is one of "ae", "oe", "ei", "ea", "ia", "io" or "aea";
    diphthongs are skipped entirely and add nothing to the count.
    """
    line = prepare_line(line)
    vowels = 0
    i = 0
    while i < len(line):
        # Longest diphthong starting at position i, so that "aea" is
        # recognised as a single diphthong rather than "ae" plus "a".
        diphthong = max(
            (candidate for candidate in DIPHTHONGS if line.startswith(candidate, i)),
            key=len,
            default=None,
        )
        if diphthong is None:
            if line[i] in "aeiouy":
                vowels += 1
            i += 1
        else:
            i += len(diphthong)  # diphthongs are not counted
    return vowels
