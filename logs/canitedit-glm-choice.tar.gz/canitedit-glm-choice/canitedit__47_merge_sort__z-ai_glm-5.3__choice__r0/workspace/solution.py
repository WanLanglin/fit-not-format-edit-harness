from typing import List


def _is_sorted(lst: List[int]) -> bool:
    """Return True when ``lst`` is already in non-decreasing order.

    Only ``<`` is used, so the check works for every element type the merge
    loop itself can compare, and it stops at the first inversion.
    """
    return all(not (lst[i + 1] < lst[i]) for i in range(len(lst) - 1))


def merge_sort(lst: List[int]) -> List[int]:
    if len(lst) > 1:
        # A sub-array that is already sorted (common in partially sorted
        # input) needs no split, no recursion and no copies -- a single
        # early-exit scan is enough.
        if _is_sorted(lst):
            return lst

        mid = len(lst) // 2
        L = lst[:mid]
        R = lst[mid:]
        merge_sort(L)
        merge_sort(R)

        # Early termination: both halves are sorted at this point, so when
        # the last element of the left half is not greater than the first
        # element of the right half (L[-1] <= R[0]) the sub-arrays are
        # already ordered relative to each other.  The merge loop and all of
        # its comparisons can be skipped; the halves only have to be copied
        # back into place.
        if not (R[0] < L[-1]):
            lst[:mid] = L
            lst[mid:] = R
            return lst

        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                lst[k] = L[i]
                i += 1
            else:
                lst[k] = R[j]
                j += 1
            k += 1
        while i < len(L):
            lst[k] = L[i]
            i += 1
            k += 1
        while j < len(R):
            lst[k] = R[j]
            j += 1
            k += 1
    return lst
