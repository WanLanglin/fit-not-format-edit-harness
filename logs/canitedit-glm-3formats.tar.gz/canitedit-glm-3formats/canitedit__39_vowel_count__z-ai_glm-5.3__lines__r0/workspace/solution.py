import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

DIPHTHONGS = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]

def vowel_count(line):
    letters = prepare_line(line)
    count = 0
    index = 0
    while index < len(letters):
        # Longest match first so "aea" is recognised before "ae"/"ea".
        if letters[index:index + 3] in DIPHTHONGS:
            index += 3
        elif letters[index:index + 2] in DIPHTHONGS:
            index += 2
        elif letters[index] in "aeiouy":
            count += 1
            index += 1
        else:
            index += 1
    return count
