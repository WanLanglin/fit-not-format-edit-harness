import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    diphthongs = ("aea", "ae", "oe", "ei", "ea", "ia", "io")
    line = prepare_line(line)
    count = 0
    index = 0

    while index < len(line):
        diphthong = next(
            (diphthong for diphthong in diphthongs if line.startswith(diphthong, index)),
            None,
        )
        if diphthong:
            count += 1
            index += len(diphthong)
        else:
            if line[index] in "aeiouy":
                count += 1
            index += 1

    return count
