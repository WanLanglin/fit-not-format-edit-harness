import string

DIPHTHONGS = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line).lower()
    diphthongs_sorted = sorted(DIPHTHONGS, key=len, reverse=True)
    count = 0
    i = 0
    while i < len(line):
        matched = False
        for diph in diphthongs_sorted:
            if line[i:i+len(diph)] == diph:
                i += len(diph)
                matched = True
                break
        if not matched:
            if line[i] in "aeiouy":
                count += 1
            i += 1
    return count
