class Employer:
    """
    Represents an entity that employs workers.
    """

    def __init__(self, name, funds):
        self.name = name
        self.funds = funds


class Worker:
    """
    Represents a person who does work for an employer.
    Name should be "[first name] [last name]" and pay 
    should be positive.
    """

    def __init__(self, name, pay, company):
        self.name = name
        self.pay = pay
        self.company = company
        self.money = 0

    def lastName(self):
        """
        Returns the last name of the worker.
        """
        return self.name.split()[-1]

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay
        self.company.funds -= self.pay

    def giveRaise(self, percent):
        """
        Gives the worker a raise in pay, given as a percentage of
        the current pay.
        """
        self.pay *= (1.0 + percent)


class PublicWorker(Worker):
    """
    Represents a worker who works for the government.
    People who work for the government are special
    because they are paid with public funds, which
    are virtually unlimited because of public debt.
    """

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay


def test_worker_invariants(w: Worker) -> None:
    """
    Checks the invariants of the Worker `w` with assertions.

    Invariants checked:

    * `name` is a string of the form "[first name] [last name]": exactly
      two names separated by a single space, and `lastName()` returns the
      second of them.
    * `pay` is a non-negative number, and so is `money`, which starts at
      0 and only ever grows by `pay`.
    * `givePay()` adds exactly one pay to the worker's money and removes
      exactly one pay from the company's funds; it changes nothing else,
      and paying twice pays two times.
    * `giveRaise(percent)` multiplies the pay by `(1.0 + percent)`, the
      pay the worker has at that moment, and changes nothing else.

    The methods are exercised with the sentinel values pay 100.0 (and
    200.0 for the raises), money 10.0 and funds 1000.0, chosen so that
    every expected result is exact in binary floating point; the checks
    are therefore meaningful whatever state `w` is in when it is passed
    in, even if it has not been paid yet or earns nothing.  `w` and its
    company are left exactly as they were, even when an assertion fails.
    """

    # --- the name is "[first name] [last name]" ------------------------

    name = getattr(w, "name", None)
    assert isinstance(name, str), "name must be a string, not %r" % (name,)
    names = name.split()
    assert len(names) == 2, (
        "name must be '<first name> <last name>', not %r" % (name,))
    first_name, last_name = names
    assert name == first_name + " " + last_name, (
        "the first name and the last name must be separated by exactly "
        "one space")
    try:
        actual_last_name = w.lastName()
    except Exception as exc:
        raise AssertionError("lastName() raised %r" % (exc,)) from exc
    assert actual_last_name == last_name, (
        "lastName() must return %r, not %r" % (last_name, actual_last_name))

    # --- the pay, and the money collected so far, are non-negative -----

    # A pay that cannot even be compared with 0 (a string, say) is not a
    # non-negative number either, so the TypeError is turned into the
    # AssertionError that the broken invariant deserves.
    pay = getattr(w, "pay", None)
    try:
        assert pay >= 0, "pay must be non-negative, not %r" % (pay,)
    except TypeError:
        raise AssertionError(
            "pay must be a non-negative number, not %r" % (pay,)) from None

    money = getattr(w, "money", None)
    try:
        assert money >= 0, "money must be non-negative, not %r" % (money,)
    except TypeError:
        raise AssertionError(
            "money must be a non-negative number, not %r"
            % (money,)) from None

    # --- givePay() and giveRaise() do what they promise ----------------

    # The checks below pay the worker out of `w.company`.  If that company
    # cannot be used (the worker has none, or its funds are not a number),
    # a scratch company stands in for it; it is removed again at the end,
    # so that `w` is left as it was.
    company = getattr(w, "company", None)
    original_company = company
    scratch = None
    if not isinstance(getattr(company, "funds", None), (int, float)):
        scratch = Employer("invariant check", 0.0)
        company = scratch
        w.company = scratch

    saved = (pay, money, company.funds)
    try:
        # givePay(): the worker gains exactly one pay, the company loses
        # exactly one pay, and nothing else changes.
        w.pay, w.money, company.funds = 100.0, 10.0, 1000.0
        try:
            w.givePay()
        except Exception as exc:
            raise AssertionError("givePay() raised %r" % (exc,)) from exc
        assert w.money == 110.0, (
            "givePay() must add exactly the pay to the worker's money, "
            "but the money is %r" % (w.money,))
        assert company.funds == 900.0, (
            "givePay() must remove exactly the pay from the company's "
            "funds, but the funds are %r" % (company.funds,))
        assert w.pay == 100.0, "givePay() must not change the pay"

        # Paying a second time pays a second time.
        try:
            w.givePay()
        except Exception as exc:
            raise AssertionError("givePay() raised %r" % (exc,)) from exc
        assert w.money == 210.0, (
            "givePay() must add the pay to the money the worker already "
            "has, but the money is %r" % (w.money,))
        assert company.funds == 800.0, (
            "givePay() must remove the pay from the funds that are left, "
            "but the funds are %r" % (company.funds,))

        # giveRaise(): the pay is multiplied by (1.0 + percent) and
        # nothing else changes.  A 25% raise, a 0% raise, a 50% pay cut
        # and a 25% pay cut are tried, from two different pays, so that a
        # raise is seen to be relative to the current pay; every
        # percentage is exactly representable, so every expected pay is
        # exact.
        raises = ((100.0, 0.25, 125.0),
                  (100.0, 0.0, 100.0),
                  (100.0, -0.5, 50.0),
                  (200.0, 0.25, 250.0),
                  (200.0, -0.25, 150.0))
        for old_pay, percent, expected_pay in raises:
            w.pay, w.money, company.funds = old_pay, 10.0, 1000.0
            try:
                w.giveRaise(percent)
            except Exception as exc:
                raise AssertionError(
                    "giveRaise(%r) raised %r" % (percent, exc)) from exc
            assert w.pay == expected_pay, (
                "giveRaise(%r) must turn a pay of %r into %r, not %r"
                % (percent, old_pay, expected_pay, w.pay))
            assert w.money == 10.0, (
                "giveRaise() must not change the worker's money")
            assert company.funds == 1000.0, (
                "giveRaise() must not change the company's funds")
    finally:
        w.pay, w.money, company.funds = saved
        if scratch is not None:
            w.company = original_company


def test_public_worker_invariants(w: PublicWorker) -> None:
    """
    Checks the invariants of the PublicWorker `w` with assertions.

    A PublicWorker is a Worker, so it keeps every Worker invariant:

    * `name` is a string of the form "[first name] [last name]": exactly
      two names separated by a single space, and `lastName()` returns the
      second of them.
    * `pay` is a non-negative number, and so is `money`, which starts at
      0 and only ever grows by `pay`.
    * `giveRaise(percent)` multiplies the pay by `(1.0 + percent)`, the
      pay the worker has at that moment, and changes nothing else.

    The difference to a plain Worker is `givePay()`: a public worker is
    paid out of public funds, which are virtually unlimited because of
    public debt, so `givePay()` adds exactly one pay to the worker's
    money (paying twice pays two times) while removing nothing at all
    from the company's funds.

    As in `test_worker_invariants`, the methods are exercised with
    sentinel values chosen so that every expected result is exact in
    binary floating point, and `w` and its company are left exactly as
    they were, even when an assertion fails.
    """

    # --- the name is "[first name] [last name]" ------------------------

    name = getattr(w, "name", None)
    assert isinstance(name, str), "name must be a string, not %r" % (name,)
    names = name.split()
    assert len(names) == 2, (
        "name must be '<first name> <last name>', not %r" % (name,))
    first_name, last_name = names
    assert name == first_name + " " + last_name, (
        "the first name and the last name must be separated by exactly "
        "one space")
    try:
        actual_last_name = w.lastName()
    except Exception as exc:
        raise AssertionError("lastName() raised %r" % (exc,)) from exc
    assert actual_last_name == last_name, (
        "lastName() must return %r, not %r" % (last_name, actual_last_name))

    # --- the pay, and the money collected so far, are non-negative -----

    # A pay that cannot even be compared with 0 (a string, say) is not a
    # non-negative number either, so the TypeError is turned into the
    # AssertionError that the broken invariant deserves.
    pay = getattr(w, "pay", None)
    try:
        assert pay >= 0, "pay must be non-negative, not %r" % (pay,)
    except TypeError:
        raise AssertionError(
            "pay must be a non-negative number, not %r" % (pay,)) from None

    money = getattr(w, "money", None)
    try:
        assert money >= 0, "money must be non-negative, not %r" % (money,)
    except TypeError:
        raise AssertionError(
            "money must be a non-negative number, not %r"
            % (money,)) from None

    # --- givePay() and giveRaise() do what they promise ----------------

    # givePay() must leave the company's funds alone, but the funds are
    # still watched, so a company is needed to watch.  If the worker's
    # own company cannot be used (the worker has none, or its funds are
    # not a number), a scratch company stands in for it; it is removed
    # again at the end, so that `w` is left as it was.
    company = getattr(w, "company", None)
    original_company = company
    scratch = None
    if not isinstance(getattr(company, "funds", None), (int, float)):
        scratch = Employer("invariant check", 0.0)
        company = scratch
        w.company = scratch

    saved = (pay, money, company.funds)
    try:
        # givePay(): the worker gains exactly one pay, the public funds
        # lose nothing, and nothing else changes.
        w.pay, w.money, company.funds = 100.0, 10.0, 1000.0
        try:
            w.givePay()
        except Exception as exc:
            raise AssertionError("givePay() raised %r" % (exc,)) from exc
        assert w.money == 110.0, (
            "givePay() must add exactly the pay to the worker's money, "
            "but the money is %r" % (w.money,))
        assert company.funds == 1000.0, (
            "givePay() must not remove anything from the public funds, "
            "but the funds are %r" % (company.funds,))
        assert w.pay == 100.0, "givePay() must not change the pay"

        # Paying a second time pays a second time.
        try:
            w.givePay()
        except Exception as exc:
            raise AssertionError("givePay() raised %r" % (exc,)) from exc
        assert w.money == 210.0, (
            "givePay() must add the pay to the money the worker already "
            "has, but the money is %r" % (w.money,))
        assert company.funds == 1000.0, (
            "givePay() must not remove anything from the public funds, "
            "but the funds are %r" % (company.funds,))

        # giveRaise(), inherited from Worker: the pay is multiplied by
        # (1.0 + percent) and nothing else changes.  A 25% raise, a 0%
        # raise, a 50% pay cut and a 25% pay cut are tried, from two
        # different pays, so that a raise is seen to be relative to the
        # current pay; every percentage is exactly representable, so
        # every expected pay is exact.
        raises = ((100.0, 0.25, 125.0),
                  (100.0, 0.0, 100.0),
                  (100.0, -0.5, 50.0),
                  (200.0, 0.25, 250.0),
                  (200.0, -0.25, 150.0))
        for old_pay, percent, expected_pay in raises:
            w.pay, w.money, company.funds = old_pay, 10.0, 1000.0
            try:
                w.giveRaise(percent)
            except Exception as exc:
                raise AssertionError(
                    "giveRaise(%r) raised %r" % (percent, exc)) from exc
            assert w.pay == expected_pay, (
                "giveRaise(%r) must turn a pay of %r into %r, not %r"
                % (percent, old_pay, expected_pay, w.pay))
            assert w.money == 10.0, (
                "giveRaise() must not change the worker's money")
            assert company.funds == 1000.0, (
                "giveRaise() must not change the company's funds")
    finally:
        w.pay, w.money, company.funds = saved
        if scratch is not None:
            w.company = original_company
