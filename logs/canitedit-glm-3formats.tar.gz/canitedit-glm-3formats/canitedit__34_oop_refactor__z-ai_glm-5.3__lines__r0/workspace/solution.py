from abc import ABC, abstractmethod


class Message(ABC):
    """Abstract base class for messages."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Process the message and return the resulting string."""
        raise NotImplementedError


class TextMessage(Message):
    """A message consisting of plain text."""

    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    """A message consisting of an image with a description."""

    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    """Factory that creates Message instances based on a message type."""

    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        if message_type == "text":
            return TextMessage(content)
        elif message_type == "image":
            return ImageMessage(content)
        else:
            raise ValueError(f"Unknown message type: {message_type}")


def process_message(message, message_type):
    """Backwards-compatible helper using the object-oriented classes."""
    return MessageFactory.get_message(message_type, message).process()
