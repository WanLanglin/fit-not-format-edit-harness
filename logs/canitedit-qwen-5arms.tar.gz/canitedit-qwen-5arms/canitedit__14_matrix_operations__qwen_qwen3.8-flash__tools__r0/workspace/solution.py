class Matrix:

    def __init__(self, matrix: list[list[int]]):
        self.matrix = matrix

    def same_size(self, other):
        """Return True if this matrix and ``other`` have the same dimensions."""
        return same_size(self, other)

    def add(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must be of the same size to be added")

        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] + other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def subtract(self, other):
        if not self.same_size(other):
            raise ValueError("Matrices must be of the same size to be subtracted")

        result = []
        for i in range(len(self.matrix)):
            row = []
            for j in range(len(self.matrix[0])):
                row.append(self.matrix[i][j] - other.matrix[i][j])
            result.append(row)
        return Matrix(result)

    def transpose(self):
        result = []
        for i in range(len(self.matrix[0])):
            row = []
            for j in range(len(self.matrix)):
                row.append(self.matrix[j][i])
            result.append(row)
        return Matrix(result)


def same_size(one, two):
    """Return True when the two matrices have the same number of rows and columns.

    Accepts Matrix instances or plain nested lists. Square and rectangular
    matrices are both supported.
    """
    one = one.matrix if isinstance(one, Matrix) else list(one)
    two = two.matrix if isinstance(two, Matrix) else list(two)

    if len(one) != len(two):
        return False

    return all(
        len(one_row) == len(two_row)
        for one_row, two_row in zip(one, two)
    )
