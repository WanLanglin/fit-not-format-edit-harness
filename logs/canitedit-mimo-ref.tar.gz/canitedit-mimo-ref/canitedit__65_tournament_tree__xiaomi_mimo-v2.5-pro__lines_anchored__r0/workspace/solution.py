from typing import Union


class Player:
    """
    A player and its rating; the rating is always a positive integer (>= 0).
    """

    def __init__(self, name, rating):
        self.name = name
        assert isinstance(rating, int) and rating >= 0
        self.rating = rating

    def against(self, other: 'Player') -> 'Player':
        """
        Return the player who wins between self and other.
        Ties are broken by the player with the lower name (lexicographically).
        """
        if self.rating > other.rating:
            return self
        elif self.rating == other.rating:
            if self.name < other.name:
                return self
            else:
                return other
        else:
            return other


class TournamentTreeNode:
    """
    A tournament tree, where the leaves are players and the internal nodes are
    matches and leaves are players.
    """

    def __init__(self, left: Union['TournamentTreeNode', Player], right: Union['TournamentTreeNode', Player]):
        self.left = left
        self.right = right


    def play(self):
        """
        Play the match at this node and return the winning Player.
        If the node is already resolved (both children are Players),
        return the winner directly.
        """
        if isinstance(self.left, TournamentTreeNode):
            self.left = self.left.play()
        if isinstance(self.right, TournamentTreeNode):
            self.right = self.right.play()
        return self.left.against(self.right)
