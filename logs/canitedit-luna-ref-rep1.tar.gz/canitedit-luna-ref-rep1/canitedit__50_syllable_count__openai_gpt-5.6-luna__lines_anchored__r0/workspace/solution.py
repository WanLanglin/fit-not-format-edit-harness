import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    vowels = "aeiouy"
    combos = 0
    words = line.split()
    for word, next_word in zip(words, words[1:]):
        if next_word and next_word[0] in vowels:
            if any(word.endswith(vowel + suffix)
                   for vowel in vowels
                   for suffix in ("", "m", "h", "mh")):
                combos += 1

    syllable_count += combos

    return syllable_count
