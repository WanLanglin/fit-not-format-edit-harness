from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        sequence: List[Token | float] = list(inputs)

        while True:
            operator_index = next(
                (index for index, token in enumerate(sequence) if token in {"+", "-", "*", "/"}),
                None,
            )
            if operator_index is None:
                break

            if operator_index < 2:
                raise Exception("malformed postfix expression")

            left = sequence[operator_index - 2]
            right = sequence[operator_index - 1]
            operator = sequence[operator_index]
            if operator == "+":
                result = left + right
            elif operator == "-":
                result = left - right
            elif operator == "*":
                result = left * right
            else:
                result = left / right
            sequence[operator_index - 2 : operator_index + 1] = [result]

        if len(sequence) != 1:
            raise Exception("malformed postfix expression")
        return sequence[0]
