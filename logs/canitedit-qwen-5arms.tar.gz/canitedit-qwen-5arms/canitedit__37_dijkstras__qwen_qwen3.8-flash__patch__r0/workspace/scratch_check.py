from solution import Edge, Graph, Node

a, b, c, d, e = (Node(i) for i in range(5))
g = Graph([a, b, c, d, e])
g.add_edge(Edge(a, b, 1))
g.add_edge(Edge(b, c, 2))
g.add_edge(Edge(a, c, 5))     # direct but longer than a->b->c
g.add_edge(Edge(c, d, 1))
# e intentionally unreachable

res = g.fibonacci(a)
assert res == {a: 0, b: 1, c: 3, d: 4, e: None}, res
assert all(isinstance(v, int) or v is None for v in res.values())
assert all(res[k] is None or type(res[k]) is int for k in res)
assert set(res.keys()) == set(g.nodes)

# single edge weight tie-break / distinct heap entries
assert g.fibonacci(b) == {a: None, b: 0, c: 2, d: 3, e: None}
assert g.fibonacci(d) == {a: None, b: None, c: None, d: 0, e: None}

# source not present in graph.nodes still returns an entry per graph node
stray = Node(99)
assert g.fibonacci(stray) == {a: None, b: None, c: None, d: None, e: None}

# lookup by an equal-but-distinct Node object works (hash/eq are id based)
assert g.fibonacci(Node(0))[b] == 1

# edges recorded only on adjacency lists (bypassing add_edge) are traversed
h = Graph([a, b, c])
ed = Edge(a, b, 4)
h.edges.append(ed)
a.out_edges.append(Edge(b, c, 6))
assert h.fibonacci(a) == {a: 0, b: 4, c: 10}, h.fibonacci(a)

# cycle handling: no infinite loop, smallest path wins
p, q, r = Node(10), Node(11), Node(12)
cy = Graph([p, q, r])
cy.add_edge(Edge(p, q, 1))
cy.add_edge(Edge(q, r, 1))
cy.add_edge(Edge(r, p, 1))
assert cy.fibonacci(p) == {p: 0, q: 1, r: 2}

print("all checks passed")
