class Cipher:
    def __init__(self):
        self.ciphers = {}

    def _build_alphabet_map(self, shift):
        import string
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        shifted_lower = lower[shift:] + lower[:shift]
        shifted_upper = upper[shift:] + upper[:shift]
        dic = {}
        for orig, new in zip(lower, shifted_lower):
            dic[orig] = new
        for orig, new in zip(upper, shifted_upper):
            dic[orig] = new
        return dic

    def caesar_cipher(self, shift):
        dic = self._build_alphabet_map(shift)
        self.ciphers["caesar" + str(shift)] = dic

    def encode(self, name, text):
        cipher = self.ciphers[name]
        return "".join(cipher.get(ch, ch) for ch in text)

    def add_cipher(self, name, cipher):
        self.ciphers[name] = cipher
