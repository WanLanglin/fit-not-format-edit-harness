"""Scratch harness used while verifying LinkedList.remove (no production code).

Behaviour verified by hand-tracing against solution.py:
  Cons.remove(el): head matches -> returns ``self.rest``; otherwise rebuilds
    ``Cons(self.first, new_rest)`` unless the recursive call returned the very
    same tail object (element absent), in which case ``self`` is returned so an
    "identical list" comes back.
  Empty.remove(el): returns ``self`` (already empty, nothing to remove).
Examples: [1,2,3,2,1].remove(2) -> [1,3,2,1] (first instance only);
  [1,2,3].remove(9) -> identical [1,2,3]; [].remove(5) -> Empty;
  [2,2,2].remove(2) -> [2,2]; [3,1,2].remove(1) -> [3,2].
"""
from solution import Cons, Empty, LinkedList


def of(xs):
    """Build a linked list from a python list (keeps the original order)."""
    l = Empty()
    for x in reversed(xs):
        l = Cons(x, l)
    return l


def to_list(l):
    """Flatten a linked list back into a python list."""
    out = []
    while isinstance(l, Cons):
        out.append(l.first)
        l = l.rest
    return out


def without_first(xs, element):
    """Reference implementation: drop only the first occurrence."""
    out = list(xs)
    if element in out:
        out.remove(element)
    return out


CASES = [
    ([1, 2, 3, 2, 1], 2),      # only the first instance is dropped
    ([1, 2, 3], 1),            # head
    ([1, 2, 3], 3),            # tail
    ([1, 2, 3], 9),            # absent -> identical list
    ([], 5),                   # empty list
    ([7], 7),                  # single element -> Empty
    ([7], 8),                  # single element, absent
    ([2, 2, 2], 2),            # all duplicates
    ([3, 1, 2], 1),            # unsorted
    (["a", "b", "a"], "a"),    # non-numeric payload
    ([1, 2, 3], 2),            # middle
]


def test_removes_first_instance():
    for xs, element in CASES:
        result = of(xs).remove(element)
        assert isinstance(result, LinkedList), (xs, element)
        assert to_list(result) == without_first(xs, element), (xs, element)


def test_absent_element_returns_identical_list():
    for xs, element in CASES:
        if element in xs:
            continue
        l = of(xs)
        r = l.remove(element)
        # "identical" -> same object (this implementation) or an equal list
        assert r is l or to_list(r) == xs, (xs, element)
        assert to_list(l) == xs, (xs, element)


def test_original_list_is_not_mutated():
    l = of([1, 2, 3])
    r = l.remove(2)
    assert to_list(l) == [1, 2, 3], to_list(l)
    assert to_list(r) == [1, 3], to_list(r)
    assert r is not l


def test_empty_stays_empty():
    assert isinstance(Empty().remove(1), Empty)
    assert isinstance(of([1]).remove(1), Empty)


def test_remove_composes_with_sort():
    assert to_list(of([3, 1, 2]).sort()) == [1, 2, 3]
    assert to_list(of([3, 1, 2]).remove(1).sort()) == [2, 3]


if __name__ == "__main__":
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            _fn()
            print("ok", _name)
    print("ALL OK")
