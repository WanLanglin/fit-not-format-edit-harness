import string

# Vowel combinations that are pronounced as a single sound, so they are not
# counted as vowels by vowel_count below.
DIPHTHONGS = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]


def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    text = prepare_line(line)
    # Longest diphthongs first, so that "aea" is matched as a whole instead
    # of "ae" consuming only part of it and leaving a stray "a" to be counted.
    diphthongs = sorted(DIPHTHONGS, key=len, reverse=True)
    vowels = 0
    position = 0
    while position < len(text):
        diphthong = next(
            (d for d in diphthongs if text.startswith(d, position)), None
        )
        if diphthong is not None:
            # A diphthong is not counted as a vowel.
            position += len(diphthong)
        else:
            if text[position] in "aeiouy":
                vowels += 1
            position += 1
    return vowels
