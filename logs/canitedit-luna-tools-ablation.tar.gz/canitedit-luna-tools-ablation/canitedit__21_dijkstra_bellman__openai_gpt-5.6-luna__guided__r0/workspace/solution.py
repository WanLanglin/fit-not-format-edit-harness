class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """Compute shortest distances from start to all other nodes.

        Uses the Bellman-Ford algorithm, which supports negative edge weights.
        A reachable negative-weight cycle makes shortest distances undefined and
        raises ValueError.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Relax every edge at most |V| - 1 times.  Edges are stored in the
        # adjacency lists, so this also handles the graph's undirected edges.
        for _ in range(len(self.nodes) - 1):
            changed = False
            for node in self.nodes:
                if shortest_path[node] == float('infinity'):
                    continue
                for neighbor, weight in self.edges[node]:
                    distance = shortest_path[node] + weight
                    if distance < shortest_path[neighbor]:
                        shortest_path[neighbor] = distance
                        changed = True
            if not changed:
                break

        # If an edge can still be relaxed, a reachable negative cycle exists.
        for node in self.nodes:
            if shortest_path[node] == float('infinity'):
                continue
            for neighbor, weight in self.edges[node]:
                if shortest_path[node] + weight < shortest_path[neighbor]:
                    raise ValueError('Graph contains a negative cycle')

        return shortest_path
