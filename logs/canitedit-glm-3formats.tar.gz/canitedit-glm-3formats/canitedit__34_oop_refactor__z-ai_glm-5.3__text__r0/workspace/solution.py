from abc import ABC, abstractmethod


class Message(ABC):
    """Abstract base class for messages."""

    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        """Process the message and return the resulting string."""
        raise NotImplementedError


class TextMessage(Message):
    """A message containing plain text."""

    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    """A message containing an image described by its content."""

    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    """Creates Message instances based on a message type."""

    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        if message_type == "text":
            return TextMessage(content)
        elif message_type == "image":
            return ImageMessage(content)
        else:
            raise ValueError(f"Unknown message type: {message_type}")
