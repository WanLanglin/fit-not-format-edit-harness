from typing import List, Tuple

def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    """Kadane's algorithm tracking the winning subarray's bounds.

    Returns a tuple of (best_sum, start_idx, end_idx), where the indices are
    inclusive bounds of the contiguous subarray with the largest sum.
    """
    max_so_far = lst[0]
    curr_max = lst[0]
    # Bounds of the best run seen so far, plus start of the current run.
    start_idx = 0
    end_idx = 0
    temp_start = 0
    for i in range(1, len(lst)):
        if lst[i] > curr_max + lst[i]:
            # Starting fresh at i beats extending the previous run.
            curr_max = lst[i]
            temp_start = i
        else:
            curr_max = curr_max + lst[i]
        if curr_max > max_so_far:
            max_so_far = curr_max
            start_idx = temp_start
            end_idx = i
    return (max_so_far, start_idx, end_idx)
