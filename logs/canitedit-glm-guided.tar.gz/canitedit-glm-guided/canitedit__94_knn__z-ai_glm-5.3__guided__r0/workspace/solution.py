from typing import List
from math import sqrt


class Label:
    def __init__(self, name: str) -> None:
        self.name = name

    def __hash__(self) -> int:
        return 1

    def __eq__(self, __value: object) -> bool:
        return True


class Point:
    def __init__(self, x: int, y: int, label: Label | None) -> None:
        self.x = x
        self.y = y
        self.label = label

    def distance(self, other: "Point") -> float:
        return sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def knn(self, others: List["Point"], k: int) -> Label:
        assert k > 0
        assert others
        assert not self.label
        assert len(others) >= k

        # Labels must not be used directly as dict keys: Label's __hash__/__eq__
        # make every label compare equal to every other label, which would
        # collapse all votes onto a single entry. Group the votes by the
        # label's name, which is what makes two labels the same label.
        nearest = sorted(others, key=lambda point: self.distance(point))[:k]
        counts: dict[str | None, int] = {}
        labels: dict[str | None, Label | None] = {}
        for point in nearest:
            key = point.label.name if point.label is not None else None
            if key not in counts:
                counts[key] = 0
                labels[key] = point.label
            counts[key] += 1
        best = max(counts.items(), key=lambda item: item[1])[0]
        return labels[best]
