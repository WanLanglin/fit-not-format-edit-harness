import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def _combo_counts(line):
    """Return the number of vowel combinations across word boundaries."""
    vowels = "aeiouy"
    combos = 0
    words = line.split(" ")

    for first, second in zip(words, words[1:]):
        if not first or not second:
            continue

        second_starts_vowel = second[0] in vowels
        second_starts_h_vowel = len(second) >= 2 and second[0] == "h" and second[1] in vowels
        first_ends_vowel = first[-1] in vowels
        first_ends_vowel_m = len(first) >= 2 and first[-2] in vowels and first[-1] == "m"
        first_ends_vowel_h = len(first) >= 2 and first[-2] in vowels and first[-1] == "h"
        combo = (
            (first_ends_vowel and second_starts_vowel)
            or (first_ends_vowel_m and second_starts_vowel)
            or (first_ends_vowel_h and second_starts_vowel)
            or (first_ends_vowel_m and second_starts_h_vowel)
        )
        if combo:
            combos += 1

    return combos


def vowel_count(line):
    vowels = "aeiouy"
    count = 0
    in_vowel_group = False
    for char in line.lower():
        if char in vowels:
            if not in_vowel_group:
                count += 1
            in_vowel_group = True
        else:
            in_vowel_group = False

    # Keep word-boundary combos out of the vowel count; syllable_count adds
    # them back explicitly.
    return count - _combo_counts(line.lower())


def syllable_count(line):
    assert type(line) == str
    line = prepare_string(line)
    combos = _combo_counts(line)

    syllable_count = vowel_count(line)
    syllable_count += combos
    return syllable_count
