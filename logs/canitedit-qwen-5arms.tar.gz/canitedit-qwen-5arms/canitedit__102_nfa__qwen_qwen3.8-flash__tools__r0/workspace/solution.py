from typing import Dict, List, Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic finite automaton equivalent to :class:`NFA`.

    Subset construction over the NFA (taking epsilon-closures) yields the
    reachable state sets ``{0}`` (start, rejecting), ``{1, 2}`` and ``{2}``
    (both accepting and behaviourally identical, so merged) and ``{}``
    (rejecting sink).  The recognised language is ``a b*``: an ``a`` followed
    by zero or more ``b``s.

    DFA states::

        0  start         - nothing useful seen yet       (NFA {0})     reject
        1  accepts ``a b*``                              (NFA {1,2})   accept
        2  sink          - no extension can be accepted  (NFA {})      reject
    """

    table: Dict[State, Dict[Input, State]] = {
        0: {"a": 1, "b": 2, "": 0},
        1: {"a": 2, "b": 1, "": 1},
        2: {"a": 2, "b": 2, "": 2},
    }

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        self.current = self.table[self.current][input]
        return self.current

    def accepted(self) -> bool:
        return self.current in self.accept


class NFA:
    """The original non-deterministic automaton, kept as the reference for the
    language recognised by :class:`DFA`."""

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1, 2}

    def transition(self, input: Input) -> List[State]:
        table = {
            0: {"a": [1, 2], "b": [], "": [0]},
            1: {"a": [], "b": [], "": [1]},
            2: {"a": [], "b": [2], "": [2]},
        }
        return table[self.current][input]

    def accepted(self) -> bool:
        return self.current in self.accept
