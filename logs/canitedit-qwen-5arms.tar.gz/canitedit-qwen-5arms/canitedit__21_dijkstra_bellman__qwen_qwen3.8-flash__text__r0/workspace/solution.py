import heapq


class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}
        # Every arc exactly as it was added. ``self.edges`` mirrors each edge
        # in both directions, so this keeps track of the direction an edge was
        # added with (needed by ``distances_to`` for negative weights).
        self.arcs = []

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))
        self.arcs.append((from_node, to_node, weight))

    def _relaxation_arcs(self):
        """
        Returns the list of (from_node, to_node, weight) arcs that a shortest
        path algorithm is allowed to relax.

        Arcs with a non-negative weight are returned in both directions, which
        keeps the undirected behaviour of add_edge.  An arc with a negative
        weight is only returned in the direction it was added: if it could also
        be travelled backwards, every negative edge would by itself be a
        negative cycle (from_node -> to_node -> from_node) and negative weights
        would be of no use at all.
        """
        negative_arcs = {arc for arc in self.arcs if arc[2] < 0}
        # Without any recorded arc (e.g. when ``edges`` was filled by hand)
        # there is no direction to recover, so the graph stays undirected.
        recorded = bool(self.arcs)

        arcs = []
        for node, neighbors in self.edges.items():
            for neighbor, weight in neighbors:
                if weight >= 0 or not recorded or (node, neighbor, weight) in negative_arcs:
                    arcs.append((node, neighbor, weight))

        return arcs

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.

        Graphs whose weights are all non-negative are handled by Dijkstra's
        algorithm, which is the faster option.  As soon as a negative weight is
        involved, the Bellman-Ford algorithm is used instead, so negative
        weights are supported as well.  Shortest paths are not defined when a
        negative cycle is reachable from the start node, and a ValueError is
        raised in that case.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        if all(weight >= 0 for neighbors in self.edges.values() for _, weight in neighbors):
            return self._dijkstra_to(start)

        return self._bellman_ford_to(start, self._relaxation_arcs())

    def _dijkstra_to(self, start):
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0
        unvisited_nodes = [(0, start)]

        while unvisited_nodes:
            current_dist, current_node = heapq.heappop(unvisited_nodes)

            for neighbor, weight in self.edges[current_node]:
                distance = current_dist + weight

                if distance < shortest_path[neighbor]:
                    shortest_path[neighbor] = distance
                    heapq.heappush(unvisited_nodes, (distance, neighbor))

        return shortest_path

    def _bellman_ford_to(self, start, arcs):
        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # A shortest path uses at most len(nodes) - 1 arcs, so that many rounds
        # of relaxations are enough to settle every distance.  The loop breaks
        # early as soon as a round improves nothing.
        for _ in range(len(self.nodes) - 1):
            relaxed = False

            for node, neighbor, weight in arcs:
                distance = shortest_path[node] + weight

                if distance < shortest_path[neighbor]:
                    shortest_path[neighbor] = distance
                    relaxed = True

            if not relaxed:
                break

        # One extra round: an improving arc can only exist because a negative
        # cycle is reachable from the start node.
        for node, neighbor, weight in arcs:
            if shortest_path[node] + weight < shortest_path[neighbor]:
                raise ValueError(
                    'Graph contains a negative cycle reachable from the start '
                    'node, so shortest paths are not defined'
                )

        return shortest_path
