import inspect
from functools import cmp_to_key


def _required_arg_count(func):
    """Number of positional arguments a callable must be given (best effort)."""
    try:
        parameters = inspect.signature(func).parameters
    except (TypeError, ValueError):
        return 1
    return sum(
        1
        for parameter in parameters.values()
        if parameter.kind
        in (parameter.POSITIONAL_ONLY, parameter.POSITIONAL_OR_KEYWORD)
        and parameter.default is parameter.empty
    )


def _as_sort_key(method):
    """
    Turn a sorting method into a function usable as `sorted`'s `key`.

    A one-argument method is already a key function. A two-argument method is
    treated as a classic comparator (negative / zero / positive) and wrapped so
    that comparing two of its results uses that comparator.
    """
    if _required_arg_count(method) >= 2:
        return lambda item: cmp_to_key(method)(item)
    return method


class Comparators:
    """
    A class for that allows for custom comparator actions that work in conjuction with Python's default sorted function
    Example usage: `sorted(lorem_ipsum, key=Comparators.by_length)`
    """

    def by_length(obj):
        """Comparing by length of object"""
        return len(obj)

    def by_num_vowels(obj):
        """Comparing by the number of vowels"""
        vowels = "aeiou"
        return sum(1 for char in obj if char.lower() in vowels)

    def by_numerical_value(obj):
        """Comparing by the numerical value of the object"""
        return obj

    def by_word_count(obj):
        """Comparison by the number of words in the object"""
        return len(obj.split())

    @staticmethod
    def sort_with_tiebreaker(items, primary, tiebreaker):
        """
        Sort `items` using `primary`, resolving ties with `tiebreaker`.

        `primary` and `tiebreaker` are either key functions (like the other
        comparators in this class, taking one item and returning the value to
        order by) or two-argument comparator functions (returning a negative
        number, zero or a positive number). They may be mixed freely. Items
        that tie on both methods keep their original relative order, because
        Python's sort is stable. The input list is not modified.

        Example usage: `Comparators.sort_with_tiebreaker(words, Comparators.by_length, Comparators.by_num_vowels)`
        """
        primary_key = _as_sort_key(primary)
        tiebreaker_key = _as_sort_key(tiebreaker)
        return sorted(items, key=lambda item: (primary_key(item), tiebreaker_key(item)))
