from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]


class DFA:
    """Deterministic automaton equivalent to the original NFA.

    The original NFA accepted exactly the language "a" followed by any
    number of "b" characters: its only non-deterministic move was
    0 -"a"-> {1, 2} (both accepting), after which only 2 -"b"-> 2 keeps
    the run alive, and its epsilon transitions were mere self loops.

    The subset construction produces the states {0}, {1, 2}, {2} and the
    empty set.  {1, 2} and {2} are equivalent (both accepting, both loop
    on "b" and die on "a"), so they merge into a single accepting state,
    giving this minimal DFA:

        0 (start)      --"a"--> 1, --"b"--> 2
        1 (accepting)  --"a"--> 2, --"b"--> 1
        2 (dead sink)  --"a"--> 2, --"b"--> 2

    The empty input leaves the automaton where it is, which mirrors the
    epsilon self loops of the original NFA.
    """

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self):
        return self.current in self.accept
