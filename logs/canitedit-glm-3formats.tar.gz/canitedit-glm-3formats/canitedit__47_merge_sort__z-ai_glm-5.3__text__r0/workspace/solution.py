from typing import List


def merge_sort(lst: List[int]) -> List[int]:
    """Sort ``lst`` in place using merge sort and return it.

    Optimization for partially sorted input: each half is sorted directly
    inside ``lst`` and then a single comparison decides whether the two halves
    have to be merged at all. Because both halves are sorted at that point,
    ``lst[mid - 1]`` is the largest element of the left half and ``lst[mid]``
    is the smallest element of the right half. If ``lst[mid - 1] <= lst[mid]``
    the halves are already ordered relative to each other, so the merge -- and
    with it every comparison and copy it would perform -- is skipped. Arrays
    built from large sorted subsequences (including already sorted arrays)
    are therefore handled in near-linear time instead of always paying the
    full O(n log n) merge cost.
    """
    _merge_sort(lst, 0, len(lst))
    return lst


def _merge_sort(lst: List[int], lo: int, hi: int) -> None:
    """Sort the slice ``lst[lo:hi]`` in place."""
    if hi - lo > 1:
        mid = lo + (hi - lo) // 2

        # Sort each half where it lives inside ``lst``. No temporary lists are
        # created unless a merge actually turns out to be necessary.
        _merge_sort(lst, lo, mid)
        _merge_sort(lst, mid, hi)

        # Early termination: both halves are sorted, so if the last element of
        # the left half does not come after the first element of the right
        # half, the sub-arrays are already ordered relative to each other and
        # the whole merge step can be skipped.
        if not (lst[mid] < lst[mid - 1]):
            return

        # The halves overlap, so a real merge is needed. Copy each half once
        # and merge them back into ``lst``.
        L = lst[lo:mid]
        R = lst[mid:hi]

        i = j = 0
        k = lo
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                lst[k] = L[i]
                i += 1
            else:
                lst[k] = R[j]
                j += 1
            k += 1
        while i < len(L):
            lst[k] = L[i]
            i += 1
            k += 1
        while j < len(R):
            lst[k] = R[j]
            j += 1
            k += 1
