import heapq
from itertools import count
from typing import Dict, Iterable, List, Optional


class Node:
    '''Simple node (No duplicate edges between nodes)'''

    def __init__(self, id: int):
        self.id = id
        self.out_edges = []
        self.in_edges = []

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Node):
            return False
        else:
            return self.id == __value.id

    def __hash__(self) -> int:
        return self.id


class Edge:
    def __init__(self, src: Node, dest: Node, weight: int):
        assert weight > 0
        assert src != dest

        self.src = src
        self.dest = dest
        self.weight = weight

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, Edge):
            return False
        else:
            return self.dest == __value.dest and self.src == __value.src


class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''

    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques.keys():
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        self.edges = []

    def add_edge(self, edge: Edge):
        assert edge not in self.edges
        self.edges.append(edge)

    def _all_edges(self) -> Iterable[Edge]:
        '''Every distinct Edge object this graph knows about.

        Edges are collected from ``self.edges`` and from the adjacency lists of
        the nodes, skipping objects already yielded (the same Edge may be
        reachable through both).
        '''
        seen = set()
        groups = [self.edges] + [node.out_edges for node in self.nodes]
        for group in groups:
            for edge in list(group):
                if id(edge) in seen:
                    continue
                seen.add(id(edge))
                yield edge

    def fibonacci(self, x: Node) -> Dict[Node, Optional[int]]:
        '''Shortest path distances from ``x`` to every node of this graph.

        Despite the name this is a single source shortest path walk (Dijkstra,
        valid because every Edge weight is strictly positive). A path's length
        is the sum of the weights of the edges taken, and the distance reported
        is the length of the smallest such path.

        Returns a dict keyed by every node in ``self.nodes`` whose values are
        the ``int`` distance from ``x``, or ``None`` for nodes which cannot be
        reached from ``x``. The distance from ``x`` to itself is 0.
        '''
        adjacency: Dict[Node, List[Edge]] = {node: [] for node in self.nodes}
        for edge in self._all_edges():
            # Only edges between two nodes of the graph can be traversed.
            if edge.src in adjacency and edge.dest in adjacency:
                adjacency[edge.src].append(edge)

        distances: Dict[Node, Optional[int]] = {
            node: None for node in self.nodes
        }

        distances_seen: Dict[Node, int] = {x: 0}
        if x in distances:
            distances[x] = 0

        settled = set()
        order = count()
        queue = [(0, next(order), x)]
        while queue:
            distance, _, node = heapq.heappop(queue)
            if node in settled:
                continue
            settled.add(node)
            # A node is popped in non-decreasing distance order, so this is the
            # final, smallest distance to it.
            if node in distances:
                distances[node] = distance

            for edge in adjacency.get(node, []):
                neighbour = edge.dest
                if neighbour in settled:
                    continue
                candidate = distance + edge.weight
                best = distances_seen.get(neighbour)
                if best is None or candidate < best:
                    distances_seen[neighbour] = candidate
                    heapq.heappush(queue, (candidate, next(order), neighbour))

        return distances
