import math

def gcd(a : int, b : int) -> int:
    """Compute the Greatest Common Divisor (GCD) of a and b."""
    assert a > 0 and b > 0
    while b != 0:
        a, b = b, a % b
    return a

def euler_totient(n : int) -> int:
    """Compute the Euler's Totient function of n."""
    assert n > 0 
    if n == 1 : return 1
    count = 0
    for i in range(1, n):
        if gcd(i, n) == 1:
            count += 1
    return count

def powermod(base : int, exp : int, mod : int) -> int:
    """Compute base ** exp % mod by successive squaring.

    The recursion halves the exponent at every step: to obtain a**b it first
    computes a**(b/2) and then squares it, i.e. a**(b/2) * a**(b/2) mod c.
    An odd exponent peels off one factor of ``base`` so that the remaining
    exponent is even, and the recursion bottoms out at exp == 0, which
    returns 1.
    """
    assert mod > 0
    assert exp >= 0
    if mod == 1:
        # every integer is congruent to 0 modulo 1
        return 0
    if exp == 0:
        return 1
    if exp == 1:
        return base % mod
    base = base % mod
    if exp % 2 == 0:
        half = powermod(base, exp // 2, mod)   # a**(exp/2) mod c
        return (half * half) % mod             # a**(exp/2) * a**(exp/2) mod c
    return (base * powermod(base, exp - 1, mod)) % mod

def check_coprime_euler(a : int, b : int):
    assert a > 0 and b > 0
    return powermod(a, euler_totient(b), b) == 1
