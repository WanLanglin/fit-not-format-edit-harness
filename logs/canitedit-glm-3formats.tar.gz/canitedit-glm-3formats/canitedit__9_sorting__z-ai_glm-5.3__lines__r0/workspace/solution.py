class Sorter:
    def __init__(self):
        pass

    def sort(self, nums: list[int]):
        """Sort ``nums`` in place using insertion sort."""
        for i in range(1, len(nums)):
            self.insert(nums, i)

    def insert(self, nums: list[int], i: int):
        """Insert ``nums[i]`` into the already-sorted ``nums[:i]`` in place."""
        num = nums[i]
        j = i - 1
        while j >= 0 and num < nums[j]:
            nums[j + 1] = nums[j]
            j -= 1
        nums[j + 1] = num
