def concatenate_nums(message):
    sep = "  " if "  " in message else " "
    subject, verb, object_ = message.split(sep)
    return f"{object_}{sep}{verb}{sep}{subject}"


def format_string(name1, name2, message):
    message = concatenate_nums(message)
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {message}'
    return formattedString
