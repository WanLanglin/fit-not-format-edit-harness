import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    diphthongs = ("aea", "ae", "oe", "ei", "ea", "ia", "io")
    count = 0
    cleaned_line = prepare_line(line)
    position = 0

    while position < len(cleaned_line):
        diphthong = next(
            (diphthong for diphthong in diphthongs if cleaned_line.startswith(diphthong, position)),
            None,
        )
        if diphthong:
            position += len(diphthong)
        else:
            if cleaned_line[position] in "aeiouy":
                count += 1
            position += 1

    return count
