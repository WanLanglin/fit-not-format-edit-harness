*** Begin Patch
*** Update File: profile_analyzer_cli.py
@@
             self._get_list_profile_lines(
-            self._get_list_profile_lines(
+            _get_list_profile_lines(
@@
-  def _get_list_profile_lines(
-      self, device_name, device_index, device_count,
+def _get_list_profile_lines(
+      device_name, device_index, device_count,
*** End Patch
