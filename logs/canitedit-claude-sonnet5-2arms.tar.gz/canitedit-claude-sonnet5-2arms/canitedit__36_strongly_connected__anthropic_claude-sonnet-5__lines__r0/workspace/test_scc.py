from solution import Node, Graph

def test_simple():
    a = Node(0)
    b = Node(1)
    c = Node(2)
    d = Node(3)
    g = Graph([a, b, c, d])
    g.add_edge(a, b)
    g.add_edge(b, c)
    g.add_edge(c, a)
    g.add_edge(c, d)
    result = g.strongly_connected_components()
    assert result[a] == result[b] == result[c]
    assert result[d] != result[a]
    print("simple ok", result)

def test_all_separate():
    a = Node(0)
    b = Node(1)
    c = Node(2)
    g = Graph([a, b, c])
    g.add_edge(a, b)
    g.add_edge(b, c)
    result = g.strongly_connected_components()
    assert len(set(result.values())) == 3
    print("separate ok", result)

def test_all_together():
    a = Node(0)
    b = Node(1)
    c = Node(2)
    g = Graph([a, b, c])
    g.add_edge(a, b)
    g.add_edge(b, c)
    g.add_edge(c, a)
    result = g.strongly_connected_components()
    assert len(set(result.values())) == 1
    print("together ok", result)

def test_two_sccs():
    a = Node(0)
    b = Node(1)
    c = Node(2)
    d = Node(3)
    e = Node(4)
    f = Node(5)
    g = Graph([a, b, c, d, e, f])
    g.add_edge(a, b)
    g.add_edge(b, a)
    g.add_edge(b, c)
    g.add_edge(d, e)
    g.add_edge(e, f)
    g.add_edge(f, d)
    g.add_edge(c, d)
    result = g.strongly_connected_components()
    assert result[a] == result[b]
    assert result[d] == result[e] == result[f]
    assert result[a] != result[c]
    assert result[c] != result[d]
    print("two ok", result)

if __name__ == "__main__":
    test_simple()
    test_all_separate()
    test_all_together()
    test_two_sccs()
    print("all passed")
