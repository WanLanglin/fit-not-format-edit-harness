import solution

print(solution.vowel_count('adspirate meis primaque ab origine mundi'))
print(solution.vowel_count('in nova fert animus mutatas dicere formas'))
