import hashlib
from typing import Tuple

# Width of the SHA-256 digest in bytes; the challenge is derived from the whole
# digest, so the security level of the non-interactive proof is fixed by SHA-256.
SHA256_DIGEST_BYTES = hashlib.sha256().digest_size

# Domain-separation tag for the Fiat-Shamir transcript, so that this protocol's
# hash can never collide with a digest computed over unrelated data.
CHALLENGE_DOMAIN = b"schnorr-nizk-sha256"


def _transcript_bytes(t: int, y: int, p: int) -> bytes:
    """Encode every transcript value unambiguously (ordered, length-prefixed).

    Each field is prefixed with its length so that distinct value triples can
    never produce the same byte string (avoiding "1"|"23" vs "12"|"3" clashes).
    """
    fields = []
    for name, value in (("t", t), ("y", y), ("p", p)):
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(f"{name} must be an int, got {type(value).__name__}")
        encoded = str(value).encode("utf-8")
        fields.append(len(encoded).to_bytes(8, "big"))
        fields.append(encoded)
    return CHALLENGE_DOMAIN + b"|".join(fields)


def keygen(p: int, g: int, x: int) -> Tuple[Tuple[int, int, int], int]:
    """generate public and private key with given prime (p), base (g), and private key (x)."""
    y = pow(g, x, p)  # public key
    return (p, g, y), x


def prover_commitment(p: int, g: int, r: int) -> Tuple[int, int]:
    """step 1: Prover sends a commitment with given random value (r)."""
    t = pow(g, r, p)
    return t, r


def hash_to_challenge(t: int, y: int, p: int) -> int:
    """step 2 (non-interactive): derive the verifier challenge with Fiat-Shamir.

    Replaces the old interactive verifier step: instead of waiting for a
    random value from the verifier, the challenge is the SHA-256 hash of *all*
    transcript values -- the prover commitment ``t``, the public key ``y`` and
    the prime ``p``. Binding the hash to ``y`` and ``p`` too means a challenge
    cannot be predicted, chosen after the fact, or replayed against a different
    key or commitment.

    The digest is mapped into ``[1, p-1]``, the challenge space of the original
    interactive protocol, so ``s`` remains well defined modulo ``p-1``.
    """
    if p <= 2:
        raise ValueError("p must be greater than 2 to derive a challenge")
    digest = hashlib.sha256(_transcript_bytes(t, y, p)).digest()
    assert len(digest) == SHA256_DIGEST_BYTES
    h = int.from_bytes(digest, "big")
    return (h % (p - 1)) + 1


def prover_response(r: int, c: int, x: int, p: int) -> int:
    """step 3: Prover sends a response."""
    s = (r + c * x) % (p-1)
    return s


def verifier_check(p: int, g: int, y: int, t: int, c: int, s: int) -> bool:
    """verifier checks the prover's response."""
    return pow(g, s, p) == (t * pow(y, c, p)) % p


def schnorr_proof(p: int, g: int, y: int, x: int, r: int) -> Tuple[int, int, int]:
    """Build the one-way non-interactive proof message ``(t, c, s)``.

    No verifier participation is needed, so the proof can be generated (and
    later checked) offline -- exactly like a signature.
    """
    # step 1: Commitment
    t, _ = prover_commitment(p, g, r)

    # step 2: Challenge -- computed from the transcript rather than received
    # from the verifier (this is what makes the protocol non-interactive).
    c = hash_to_challenge(t, y, p)

    # step 3: Response
    s = prover_response(r, c, x, p)

    return t, c, s


def schnorr_verify(p: int, g: int, y: int, t: int, s: int) -> bool:
    """Verify a non-interactive proof from public values only (no private key)."""
    if not 2 <= g <= p-1 or not 1 <= t <= p-1:
        return False
    c = hash_to_challenge(t, y, p)
    return verifier_check(p, g, y, t, c, s)


def schnorr_protocol(p: int, g: int, x: int, r: int, c=None, bits: int = 256) -> bool:
    """demonstrate the non-interactive Schnorr protocol with given values.

    The verifier's message is gone: the challenge is produced by
    ``hash_to_challenge`` (Fiat-Shamir), so the prover sends a single message
    that anyone can verify afterwards and no randomness can be handed to the
    prover by a verifier. The former ``c`` argument is now ignored -- the
    challenge is derived, never supplied -- and is accepted only so that older
    call sites keep working; ``bits`` is unused as well, since the challenge
    width is fixed by the SHA-256 digest.
    """
    if (not 2 <= g <= p-1) or (not 2 <= x <= p-2) or (not 2 <= r <= p-2):
        return False
    # key generation
    params, x = keygen(p, g, x)
    p, g, y = params

    # prover: a single, self-contained non-interactive message
    t, c, s = schnorr_proof(p, g, y, x, r)

    # a derived challenge is only usable if it lies in the expected range
    if not 1 <= c <= p-1:
        return False

    # verification: the verifier recomputes the challenge itself and checks it
    # agrees with the transmitted one, then runs the usual Schnorr check.
    return c == hash_to_challenge(t, y, p) and verifier_check(p, g, y, t, c, s)
