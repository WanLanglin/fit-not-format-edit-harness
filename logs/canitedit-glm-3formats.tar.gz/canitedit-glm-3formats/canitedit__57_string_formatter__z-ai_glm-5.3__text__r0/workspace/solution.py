import re


def concatenate_nums(message):
    """Change the word order of ``message`` from subject-verb-object to
    object-verb-subject.

    ``message`` is composed only of a subject, a verb and an object which
    are separated by spaces.  The spacing used in ``message`` is kept in
    the returned string:

    concatenate_nums('the cat  chased  the mouse')
    -> 'the mouse  chased  the cat'
    """
    words = message.split()
    if not words:
        return message

    # Subject, verb and object separated by runs of two or more spaces:
    # multi word subjects and objects stay together.
    groups = re.split(r'(\s{2,})', message.strip())
    if len(groups) == 5:
        subject, first_sep, verb, second_sep, obj = groups
        return obj + first_sep + verb + second_sep + subject

    # Subject, verb and object are three single words, e.g. 'cat chased mouse'.
    if len(words) == 3:
        subject, verb, obj = words
        return obj + ' ' + verb + ' ' + subject

    # Multi word subject and object separated by single spaces: the verb is
    # taken to be the word in the middle of the message (articles such as
    # "the" are never the verb), so the subject and the object are swapped
    # as whole blocks of words.
    middle = len(words) // 2
    articles = ('a', 'an', 'the')
    candidates = [i for i, word in enumerate(words) if word.lower() not in articles]
    if not candidates:
        candidates = list(range(len(words)))
    verb_index = min(candidates, key=lambda i: (abs(i - middle), i))
    subject = ' '.join(words[:verb_index])
    verb = words[verb_index]
    obj = ' '.join(words[verb_index + 1:])
    return obj + ' ' + verb + ' ' + subject


def format_string(name1, name2, message):
    message = concatenate_nums(message)
    formattedString = f'Hello, {name1.lower().capitalize()}! You have a message from {name2.lower().capitalize()}. The message is: {message}'
    return formattedString
