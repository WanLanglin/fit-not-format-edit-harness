class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output

    def next_n_fibs(self, n):
        saved_prev_prev = self.prev_prev
        saved_prev = self.prev
        result = []
        for _ in range(n):
            result.append(self.__next__())
        self.prev_prev = saved_prev_prev
        self.prev = saved_prev
        return result
