"""Tests for the ordered/unordered list "see more" translation.

Run with: pytest test_lists.py   (or: python test_lists.py)
"""
import sys

from solution import HTMLElement, parse, translate_html_to_markdown

MAX_ITEMS = 5
SEE_MORE = "[see more](/see-more)"


def li(text):
    return HTMLElement('li', [text], {})


def ul(*items):
    return HTMLElement('ul', list(items), {})


def ol(*items):
    return HTMLElement('ol', list(items), {})


def items(n, start=1):
    return [li(f"item {i}") for i in range(start, start + n)]


# --- Unordered list -------------------------------------------------------

def test_ul_more_than_five_items_shows_see_more():
    out = translate_html_to_markdown([ul(*items(7))])
    lines = out.split("\n")
    assert lines == [
        "- item 1",
        "- item 2",
        "- item 3",
        "- item 4",
        "- item 5",
        f"- {SEE_MORE}",
    ]


def test_ul_exactly_five_items_has_no_link():
    out = translate_html_to_markdown([ul(*items(5))])
    assert SEE_MORE not in out
    assert len(out.split("\n")) == 5


def test_ul_fewer_than_five_items_has_no_link():
    out = translate_html_to_markdown([ul(li("a"), li("b"))])
    assert SEE_MORE not in out


def test_ul_many_items_still_single_link():
    out = translate_html_to_markdown([ul(*items(50))])
    lines = out.split("\n")
    assert len(lines) == MAX_ITEMS + 1
    assert lines[MAX_ITEMS] == f"- {SEE_MORE}"


def test_ul_ignores_whitespace_text_nodes_when_counting():
    content = [v for i in range(1, 8) for v in ("\n  ", li(f"item {i}"))] + ["\n"]
    out = translate_html_to_markdown([ul(*content)])
    assert out.split("\n")[-1] == f"- {SEE_MORE}"


# --- Ordered list --------------------------------------------------------

def test_ol_more_than_five_items_shows_numbered_see_more():
    out = translate_html_to_markdown([ol(*items(7))])
    lines = out.split("\n")
    assert lines == [
        "1. item 1",
        "2. item 2",
        "3. item 3",
        "4. item 4",
        "5. item 5",
        f"6. {SEE_MORE}",
    ]


def test_ol_exactly_five_items_has_no_link():
    out = translate_html_to_markdown([ol(*items(5))])
    assert SEE_MORE not in out
    assert len(out.split("\n")) == 5


def test_ol_fewer_than_five_items_has_no_link():
    out = translate_html_to_markdown([ol(li("a"))])
    assert SEE_MORE not in out


def test_ol_many_items_still_single_link():
    out = translate_html_to_markdown([ol(*items(20))])
    lines = out.split("\n")
    assert len(lines) == MAX_ITEMS + 1
    assert lines[MAX_ITEMS] == f"6. {SEE_MORE}"


# --- End-to-end through the parser ---------------------------------------

def test_parsed_ol_more_than_five_items():
    html = ("<ol><li>one</li><li>two</li><li>three</li><li>four</li>"
            "<li>five</li><li>six</li><li>seven</li></ol>")
    out = translate_html_to_markdown(parse(html))
    assert out.split("\n")[-1] == f"6. {SEE_MORE}"


def test_parsed_ul_more_than_five_items():
    html = "<ul><li>a</li><li>b</li><li>c</li><li>d</li><li>e</li><li>f</li></ul>"
    out = translate_html_to_markdown(parse(html))
    assert out.split("\n")[-1] == f"- {SEE_MORE}"


def test_parsed_ul_five_items_no_link():
    html = "<ul><li>a</li><li>b</li><li>c</li><li>d</li><li>e</li></ul>"
    out = translate_html_to_markdown(parse(html))
    assert SEE_MORE not in out


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS: {name}")
            except AssertionError as exc:
                failures += 1
                print(f"FAIL: {name}: {exc}")
    print("\nALL TESTS PASSED" if not failures else f"\n{failures} FAILURES")
    sys.exit(1 if failures else 0)
