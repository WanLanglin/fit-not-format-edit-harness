from collections import deque
from typing import List


class GraphCycleError(ValueError, RuntimeError):
    '''Raised when a topological sort is attempted on a cyclic graph.'''


class Node:
    '''Simple node (No duplicate edges between nodes)'''
    def __init__(self, id: int, out_edges: List[int]):
        uniques = {}
        for edge in out_edges:
            if edge in uniques.keys():
                raise RuntimeError
            else:
                uniques[edge] = True
        self.id = id
        self.out_edges = out_edges

class Graph:
    '''Simple directed graph (No duplicate edges between nodes, no duplicate nodes)'''
    def __init__(self, nodes: List[Node]):
        uniques = {}
        for node in nodes:
            if node in uniques:
                raise RuntimeError
            else:
                uniques[node] = True
        self.nodes = nodes
        
    def find_node(self, id: int):
        for node in self.nodes:
            if node.id == id:
                return node
    
    def topological_sort(self) -> List[Node]:
        '''
        Return the graph's nodes in topological order, i.e. an ordering in
        which every node appears after all nodes that can reach it.

        Raises GraphCycleError if the graph contains a cycle.
        '''
        nodes_by_id = {node.id: node for node in self.nodes}
        in_degree = {node.id: 0 for node in self.nodes}

        # Count incoming edges, ignoring edges pointing at nodes that are not
        # part of this graph.
        for node in self.nodes:
            for target in node.out_edges:
                if target in in_degree:
                    in_degree[target] += 1

        ready = deque(node for node in self.nodes if in_degree[node.id] == 0)
        ordered = []

        while ready:
            node = ready.popleft()
            ordered.append(node)
            for target in node.out_edges:
                if target not in in_degree:
                    continue
                in_degree[target] -= 1
                if in_degree[target] == 0:
                    ready.append(nodes_by_id[target])

        if len(ordered) != len(self.nodes):
            raise GraphCycleError("Graph contains a cycle; topological sort is impossible.")

        return ordered
