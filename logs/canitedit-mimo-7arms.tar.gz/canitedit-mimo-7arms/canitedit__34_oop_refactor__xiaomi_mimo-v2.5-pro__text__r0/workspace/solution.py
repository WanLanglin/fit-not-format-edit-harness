from abc import ABC, abstractmethod


class Message(ABC):
    def __init__(self, content: str):
        self.content = content

    @abstractmethod
    def process(self) -> str:
        pass


class TextMessage(Message):
    def process(self) -> str:
        return f"Processed text message: {self.content}"


class ImageMessage(Message):
    def process(self) -> str:
        return f"Processed image message with description: {self.content}"


class MessageFactory:
    @staticmethod
    def get_message(message_type: str, content: str) -> Message:
        if message_type == "text":
            return TextMessage(content)
        elif message_type == "image":
            return ImageMessage(content)
        else:
            raise ValueError(f"Unknown message type: {message_type}")
