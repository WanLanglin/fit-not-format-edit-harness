import heapq


class Graph:
    def __init__(self):
        self.nodes = set()
        self.edges = {}

    def add_node(self, value):
        self.nodes.add(value)
        self.edges[value] = []

    def add_edge(self, from_node, to_node, weight):
        self.edges[from_node].append((to_node, weight))
        self.edges[to_node].append((from_node, weight))

    def distances_to(self, start):
        """
        Computes the shortest distances from start to all other nodes in the graph.
        Uses the Bellman-Ford algorithm, supporting negative weights.
        Raises a ValueError if the graph contains a negative cycle.
        """
        if start not in self.nodes:
            raise ValueError('Start node not in graph')

        shortest_path = {node: float('infinity') for node in self.nodes}
        shortest_path[start] = 0

        # Relax all edges up to V-1 times.
        for _ in range(len(self.nodes) - 1):
            updated = False
            for from_node in self.edges:
                for to_node, weight in self.edges[from_node]:
                    if shortest_path[from_node] != float('infinity'):
                        distance = shortest_path[from_node] + weight
                        if distance < shortest_path[to_node]:
                            shortest_path[to_node] = distance
                            updated = True
            if not updated:
                break

        # A V-th relaxation that still improves a path means there is a
        # negative cycle reachable from the start node.
        for from_node in self.edges:
            for to_node, weight in self.edges[from_node]:
                if shortest_path[from_node] != float('infinity'):
                    distance = shortest_path[from_node] + weight
                    if distance < shortest_path[to_node]:
                        raise ValueError('Graph contains a negative cycle')

        return shortest_path
