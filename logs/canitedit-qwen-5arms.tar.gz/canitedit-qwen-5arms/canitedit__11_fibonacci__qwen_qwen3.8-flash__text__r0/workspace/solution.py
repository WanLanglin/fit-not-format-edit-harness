class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output

    def next_n_fibs(self, n: int) -> list:
        """Return the next ``n`` Fibonacci numbers that ``__next__`` would
        produce, without mutating the iterator's state.
        """
        prev_prev = getattr(self, 'prev_prev', 0)
        prev = getattr(self, 'prev', 1)
        fibs = []
        for _ in range(max(n, 0)):
            output = prev + prev_prev
            prev_prev, prev = prev, output
            fibs.append(output)
        return fibs
