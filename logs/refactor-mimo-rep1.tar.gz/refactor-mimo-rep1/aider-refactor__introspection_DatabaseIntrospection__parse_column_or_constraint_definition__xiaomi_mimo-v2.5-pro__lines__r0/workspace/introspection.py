from collections import namedtuple

import sqlparse

from django.db import DatabaseError
from django.db.backends.base.introspection import BaseDatabaseIntrospection
from django.db.backends.base.introspection import FieldInfo as BaseFieldInfo
from django.db.backends.base.introspection import TableInfo
from django.db.models import Index
from django.utils.regex_helper import _lazy_re_compile

FieldInfo = namedtuple(
    "FieldInfo", BaseFieldInfo._fields + ("pk", "has_json_constraint")
)

field_size_re = _lazy_re_compile(r"^\s*(?:var)?char\s*\(\s*(\d+)\s*\)\s*$")


def get_field_size(name):
    """Extract the size number from a "varchar(11)" type name"""
    m = field_size_re.search(name)
    return int(m[1]) if m else None


def _parse_column_or_constraint_definition(tokens, columns):
    token = None
    is_constraint_definition = None
    field_name = None
    constraint_name = None
    unique = False
    unique_columns = []
    check = False
    check_columns = []
    braces_deep = 0
    for token in tokens:
        if token.match(sqlparse.tokens.Punctuation, "("):
            braces_deep += 1
        elif token.match(sqlparse.tokens.Punctuation, ")"):
            braces_deep -= 1
            if braces_deep < 0:
                # End of columns and constraints for table definition.
                break
        elif braces_deep == 0 and token.match(sqlparse.tokens.Punctuation, ","):
            # End of current column or constraint definition.
            break
        # Detect column or constraint definition by first token.
        if is_constraint_definition is None:
            is_constraint_definition = token.match(
                sqlparse.tokens.Keyword, "CONSTRAINT"
            )
            if is_constraint_definition:
                continue
        if is_constraint_definition:
            # Detect constraint name by second token.
            if constraint_name is None:
                if token.ttype in (sqlparse.tokens.Name, sqlparse.tokens.Keyword):
                    constraint_name = token.value
                elif token.ttype == sqlparse.tokens.Literal.String.Symbol:
                    constraint_name = token.value[1:-1]
            # Start constraint columns parsing after UNIQUE keyword.
            if token.match(sqlparse.tokens.Keyword, "UNIQUE"):
                unique = True
                unique_braces_deep = braces_deep
            elif unique:
                if unique_braces_deep == braces_deep:
                    if unique_columns:
                        # Stop constraint parsing.
                        unique = False
                    continue
                if token.ttype in (sqlparse.tokens.Name, sqlparse.tokens.Keyword):
                    unique_columns.append(token.value)
                elif token.ttype == sqlparse.tokens.Literal.String.Symbol:
                    unique_columns.append(token.value[1:-1])
        else:
            # Detect field name by first token.
            if field_name is None:
                if token.ttype in (sqlparse.tokens.Name, sqlparse.tokens.Keyword):
                    field_name = token.value
                elif token.ttype == sqlparse.tokens.Literal.String.Symbol:
                    field_name = token.value[1:-1]
            if token.match(sqlparse.tokens.Keyword, "UNIQUE"):
                unique_columns = [field_name]
        # Start constraint columns parsing after CHECK keyword.
        if token.match(sqlparse.tokens.Keyword, "CHECK"):
            check = True
            check_braces_deep = braces_deep
        elif check:
            if check_braces_deep == braces_deep:
                if check_columns:
                    # Stop constraint parsing.
                    check = False
                continue
            if token.ttype in (sqlparse.tokens.Name, sqlparse.tokens.Keyword):
                if token.value in columns:
                    check_columns.append(token.value)
            elif token.ttype == sqlparse.tokens.Literal.String.Symbol:
                if token.value[1:-1] in columns:
                    check_columns.append(token.value[1:-1])
    unique_constraint = (
        {
            "unique": True,
            "columns": unique_columns,
            "primary_key": False,
            "foreign_key": None,
            "check": False,
            "index": False,
        }
        if unique_columns
        else None
    )
    check_constraint = (
        {
            "check": True,
            "columns": check_columns,
            "primary_key": False,
            "unique": False,
            "foreign_key": None,
            "index": False,
        }
        if check_columns
        else None
    )
    return constraint_name, unique_constraint, check_constraint, token


# This light wrapper "fakes" a dictionary interface, because some SQLite data
# types include variables in them -- e.g. "varchar(30)" -- and can't be matched
# as a simple dictionary lookup.
class FlexibleFieldLookupDict:
