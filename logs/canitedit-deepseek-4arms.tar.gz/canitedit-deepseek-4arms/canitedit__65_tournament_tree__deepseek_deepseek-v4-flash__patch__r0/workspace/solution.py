from typing import Optional, Union


class Player:
    """
    A player and its rating; the rating is always a positive integer (>= 0).
    """

    def __init__(self, name, rating):
        self.name = name
        assert isinstance(rating, int) and rating >= 0
        self.rating = rating

    def against(self, other: 'Player') -> 'Player':
        """
        Return the player that wins the game between ``self`` and ``other``.
        Ties are broken by the player with the lower name (lexicographically).
        """
        if self.rating > other.rating:
            return self
        elif self.rating == other.rating:
            # ties broken by name
            if self.name < other.name:
                return self
            else:
                return other
        else:
            return other


class TournamentTreeNode:
    """
    A tournament tree, where the leaves are players and the internal nodes are
    matches and leaves are players.
    """

    def __init__(self, left: Union['TournamentTreeNode', Player], right: Union['TournamentTreeNode', Player]):
        self.left = left
        self.right = right

    def play(self):
        """
        Play the match at this node. If the match is already played, do nothing.
        """
        if isinstance(self.left, Player) and isinstance(self.right, Player):
            return
        else:
            if isinstance(self.left, TournamentTreeNode):
                self.left.play()
                self.left = self.left.left.against(self.left.right)
            if isinstance(self.right, TournamentTreeNode):
                self.right.play()
                self.right = self.right.left.against(self.right.right)
