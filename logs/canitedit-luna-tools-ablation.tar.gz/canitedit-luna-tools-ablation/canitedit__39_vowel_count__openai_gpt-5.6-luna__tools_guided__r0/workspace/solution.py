import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    """Count vowels, treating the listed diphthongs as one vowel."""
    cleaned_line = prepare_line(line)
    diphthongs = ("aea", "ae", "oe", "ei", "ea", "ia", "io")
    count = 0
    index = 0

    while index < len(cleaned_line):
        diphthong = next(
            (item for item in diphthongs if cleaned_line.startswith(item, index)),
            None,
        )
        if diphthong:
            count += 1
            index += len(diphthong)
        else:
            if cleaned_line[index] in "aeiouy":
                count += 1
            index += 1

    return count
