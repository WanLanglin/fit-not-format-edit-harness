from typing import List, Tuple


def max_sublstay_sum(lst: List[int]) -> Tuple[int, int, int]:
    max_so_far = curr_max = lst[0]
    start_idx = max_start_idx = max_end_idx = 0

    for i in range(1, len(lst)):
        if lst[i] > curr_max + lst[i]:
            curr_max = lst[i]
            start_idx = i
        else:
            curr_max += lst[i]

        if curr_max > max_so_far:
            max_so_far = curr_max
            max_start_idx = start_idx
            max_end_idx = i

    return max_so_far, max_start_idx, max_end_idx
