from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """Parse a sequence of input tokens using postfix notation."""
        stack: List[float] = []

        for token in inputs:
            if token in ("+", "-", "*", "/"):
                if len(stack) < 2:
                    raise Exception("Malformed postfix expression")

                right = stack.pop()
                left = stack.pop()
                match token:
                    case "+":
                        result = left + right
                    case "-":
                        result = left - right
                    case "*":
                        result = left * right
                    case "/":
                        result = left / right
                stack.append(result)
            else:
                stack.append(token)

        if len(stack) != 1:
            raise Exception("Malformed postfix expression")
        return stack[0]
