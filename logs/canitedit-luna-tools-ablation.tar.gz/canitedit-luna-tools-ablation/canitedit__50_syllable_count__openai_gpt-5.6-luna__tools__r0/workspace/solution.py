import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    words = line.split(" ")
    vowels = "aeiouy"
    for first, second in zip(words, words[1:]):
        if not first or not second:
            continue

        starts_with_vowel = second[0] in vowels
        starts_with_h_vowel = (
            len(second) > 1 and second[0] == "h" and second[1] in vowels
        )
        ends_with_vowel = first[-1] in vowels
        ends_with_vowel_m = (
            len(first) > 1 and first[-1] == "m" and first[-2] in vowels
        )
        ends_with_vowel_h = (
            len(first) > 1 and first[-1] == "h" and first[-2] in vowels
        )

        if (
            (ends_with_vowel and starts_with_vowel)
            or (ends_with_vowel_m and starts_with_vowel)
            or (ends_with_vowel_h and starts_with_vowel)
            or (ends_with_vowel_m and starts_with_h_vowel)
        ):
            syllable_count += 1

    return syllable_count
