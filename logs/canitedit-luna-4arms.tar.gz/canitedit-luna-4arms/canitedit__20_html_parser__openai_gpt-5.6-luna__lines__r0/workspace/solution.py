from typing import Dict, List, Union
import re


class HTMLElement:
    def __init__(self, name, content: List[Union[str, 'HTMLElement']], attributes: Dict[str, str] = None):
        self.name = name
        self.content = content
        self.attributes = attributes if attributes is not None else {}

    def __str__(self):
        attributes = ''.join(
            f' {name}="{value}"' for name, value in self.attributes.items()
        )
        content = ''.join(str(c) for c in self.content)
        return f"<{self.name}{attributes}>{content}</{self.name}>"

    def __repr__(self):
        return f"HTMLElement(name={self.name}, content={repr(self.content)}, attributes={repr(self.attributes)})"


def parse(content: str) -> List[HTMLElement]:
    """
    Parses the given HTML content and returns a list of HTMLElements.
    """
    tokens = tokenize(content)
    stack = []
    result = []

    for token in tokens:
        if is_start_tag(token):
            stack.append(HTMLElement(get_tag_name(token), [], get_attributes(token)))
        elif is_end_tag(token):
            element = stack.pop()
            if stack:
                stack[-1].content.append(element)
            else:
                result.append(element)
        else:
            if stack:
                stack[-1].content.append(token)

    return result


def tokenize(content: str) -> List[str]:
    # This regex splits the content into tags and text.
    # It looks for anything that starts with '<' and ends with '>', and treats it as a tag.
    # Everything else is treated as text.
    return re.findall(r'<[^>]+>|[^<]+', content)


def is_start_tag(token: str) -> bool:
    # A start tag starts with '<' but does not start with '</'.
    return token.startswith('<') and not token.startswith('</')


def is_end_tag(token: str) -> bool:
    # An end tag starts with '</'.
    return token.startswith('</')


def get_tag_name(token: str) -> str:
    # Extract the tag name from the first word in a token.
    return token.lstrip('<').split(None, 1)[0].rstrip('>')


def get_attributes(token: str) -> Dict[str, str]:
    # Extract name/value pairs, allowing quoted values to contain spaces.
    tag_contents = token.strip('<>')
    parts = tag_contents.split(None, 1)
    if len(parts) < 2:
        return {}

    attributes = {}
    attribute_text = parts[1].rstrip('/').strip()
    pattern = r'''([^\s=/>]+)\s*(?:=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?'''
    for match in re.finditer(pattern, attribute_text):
        name = match.group(1)
        value = match.group(2) or match.group(3) or match.group(4)
        attributes[name] = value if value is not None else ''
    return attributes
