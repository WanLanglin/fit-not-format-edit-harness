from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""

        stack: List[float] = []
        for token in inputs:
            if isinstance(token, int):
                stack.append(float(token))
            else:
                if len(stack) < 2:
                    raise Exception("Malformed postfix expression")
                b = stack.pop()
                a = stack.pop()
                if token == "+":
                    stack.append(a + b)
                elif token == "-":
                    stack.append(a - b)
                elif token == "*":
                    stack.append(a * b)
                elif token == "/":
                    stack.append(a / b)
                else:
                    raise Exception("Malformed postfix expression")

        if len(stack) != 1:
            raise Exception("Malformed postfix expression")
        return stack[0]
