from typing import Dict, Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2]

# Subset construction of the previous NFA (start state 0, accepting {1, 2}).
# Every NFA state's "" move points to itself, so the epsilon closures are
# trivial and "" behaves as an identity move in the DFA as well:
#
#   DFA state | NFA state set | accepts? | on "a" | on "b" | on ""
#   ----------+---------------+----------+--------+--------+------
#       0     |     {0}       |    no    |   1    |   2    |   0   (start)
#       1     |    {1, 2}     |   yes    |   2    |   1    |   1
#       2     |      {}       |    no    |   2    |   2    |   2   (dead)
#
# The NFA sets {1, 2} and {2} both have residual language b*, so they are
# merged into state 1, giving the minimal DFA. The recognised language is
# a b* : an "a" followed by zero or more "b"s.


class DFA:
    """Deterministic finite automaton equivalent to the original NFA."""

    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1}

    def transition(self, input: Input) -> State:
        table: Dict[State, Dict[Input, State]] = {
            0: {"a": 1, "b": 2, "": 0},
            1: {"a": 2, "b": 1, "": 1},
            2: {"a": 2, "b": 2, "": 2},
        }
        self.current = table[self.current][input]
        return self.current

    def accepted(self) -> bool:
        return self.current in self.accept
