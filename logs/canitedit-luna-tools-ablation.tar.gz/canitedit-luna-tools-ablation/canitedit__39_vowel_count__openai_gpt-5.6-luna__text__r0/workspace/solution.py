import string

DIPHTHONGS = ("aea", "ae", "oe", "ei", "ea", "ia", "io")

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    vowel_count = 0
    prepared_line = prepare_line(line)
    index = 0
    while index < len(prepared_line):
        diphthong = next(
            (diphthong for diphthong in DIPHTHONGS if prepared_line.startswith(diphthong, index)),
            None,
        )
        if diphthong:
            vowel_count += 1
            index += len(diphthong)
        else:
            if prepared_line[index] in "aeiouy":
                vowel_count += 1
            index += 1
    return vowel_count
