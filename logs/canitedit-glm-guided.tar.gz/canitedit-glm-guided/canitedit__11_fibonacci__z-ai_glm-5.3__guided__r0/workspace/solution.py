class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int) -> list:
        """Return the next ``n`` fibonacci numbers without mutating state."""
        prev_prev = getattr(self, "prev_prev", 0)
        prev = getattr(self, "prev", 1)
        results = []
        for _ in range(n):
            output = prev_prev + prev
            prev_prev = prev
            prev = output
            results.append(output)
        return results
