from solution import HTMLElement, parse, get_tag_name, get_attributes

# --- Basic parsing without attributes (regression check) ---
result = parse("<div>text</div>")
assert len(result) == 1
assert result[0].name == "div"
assert result[0].content == ["text"]
assert result[0].attributes == {}
assert str(result[0]) == "<div>text</div>", str(result[0])

# --- Single attribute with quoted value containing spaces ---
result = parse('<a href="https://example.com/some page">link</a>')
assert result[0].name == "a", result[0].name
assert result[0].attributes == {"href": "https://example.com/some page"}, result[0].attributes
assert str(result[0]) == '<a href="https://example.com/some page">link</a>', str(result[0])

# --- Multiple attributes ---
result = parse('<input type="checkbox" name="agree" checked>')
assert result[0].name == "input", result[0].name
assert result[0].attributes == {"type": "checkbox", "name": "agree", "checked": ""}, result[0].attributes

# --- Single quoted value with spaces, mixed with other attributes ---
result = parse("<div id='main content' class=box data-x=1>Hello</div>")
assert result[0].name == "div", result[0].name
assert result[0].attributes == {"id": "main content", "class": "box", "data-x": "1"}, result[0].attributes
assert str(result[0]) == '<div id="main content" class="box" data-x="1">Hello</div>', str(result[0])

# --- Nested elements with attributes ---
result = parse('<div class="outer"><span class="inner bold">Hi</span>tail</div>')
assert len(result) == 1
outer = result[0]
assert outer.name == "div" and outer.attributes == {"class": "outer"}
child = outer.content[0]
assert isinstance(child, HTMLElement)
assert child.name == "span" and child.attributes == {"class": "inner bold"}
assert child.content == ["Hi"]
assert outer.content[1] == "tail"
assert str(outer) == '<div class="outer"><span class="inner bold">Hi</span>tail</div>', str(outer)

# --- Tag with no attributes ---
result = parse("<br>")
assert result[0].name == "br" and result[0].attributes == {}

result = parse("<div hidden>text</div>")
assert result[0].attributes == {"hidden": ""}, result[0].attributes
assert str(result[0]) == "<div hidden>text</div>", str(result[0])

# --- Valueless attributes are preserved in __str__ ---
result = parse('<div disabled required>go</div>')
assert result[0].attributes == {"disabled": "", "required": ""}
assert str(result[0]) == "<div disabled required>go</div>", str(result[0])

# --- Tag name is only the first word ---
assert get_tag_name('<a href="x y">') == "a"
assert get_tag_name('<div class="a">') == "div"
assert get_tag_name('</div>') == "div"
assert get_tag_name('<div >') == "div"

# --- get_attributes helper ---
assert get_attributes('<div>') == {}
assert get_attributes('<a href="x y" id=z>') == {"href": "x y", "id": "z"}
assert get_attributes('<div data-msg="hello world">') == {"data-msg": "hello world"}
assert get_attributes('<img src="a.png" alt="an image" width=100>') == {
    "src": "a.png", "alt": "an image", "width": "100"}

# --- Manual construction with attributes ---
elem = HTMLElement("p", ["hi"], {"class": "note big"})
assert str(elem) == '<p class="note big">hi</p>', str(elem)
# __repr__ was not part of the requested changes, so it keeps its original format.
assert repr(elem) == "HTMLElement(name=p, content=['hi'])", repr(elem)

# --- Multiple root level elements ---
result = parse('<a href="1">x</a><b>y</b>')
assert [e.name for e in result] == ["a", "b"]
assert result[0].attributes == {"href": "1"}
assert result[1].attributes == {}

print("All checks passed")
