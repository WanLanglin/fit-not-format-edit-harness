from abc import ABC
from abc import abstractmethod
from typing import List, Tuple

class Strategy(ABC):
    @abstractmethod
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        '''Returns a tuple(row, column) which indicates where to move 
           in a 3x3 grid.'''
        pass

class CornerStrategy(Strategy):
    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        if board[0][0] == None:
            return (0, 0)
        elif board[0][2] == None:
            return (0, 2)
        elif board[2][0] == None:
            return (2, 0)
        elif board[2][2] == None:
            return (2, 2)
        else:
            raise Exception

class GoodStrategy(Strategy):
    '''Beats CornerStrategy by owning the middle column.

    CornerStrategy only ever plays the four corner squares, so the centre
    and the four edge squares are always free for this player.  Taking the
    centre and then the top/bottom edges completes column 1 after only
    three moves, while the corners alone can never give CornerStrategy a
    line (every corner line needs the centre or an edge).

    Corners are deliberately left alone: if this player grabbed a corner,
    CornerStrategy could run out of corners and raise an exception before
    this player has won.
    '''

    # Move priority: centre first, then the edges that form the middle
    # column, then the remaining edges.  No corners.
    MOVE_ORDER: List[Tuple[int, int]] = [(1, 1), (0, 1), (2, 1), (1, 0), (1, 2)]

    def returnMove(self, board: List[List[bool]]) -> Tuple[int, int]:
        for row, col in self.MOVE_ORDER:
            if board[row][col] is None:
                return (row, col)
        # Defensive fallback: this player should already have won long
        # before these squares are reached, but never crash on a move.
        for row in range(3):
            for col in range(3):
                if board[row][col] is None:
                    return (row, col)
        raise Exception("No legal move available")
        
class Game:
    def __init__(self, player1: Strategy, player2: Strategy):
        self.playerOne = player1
        self.playerTwo = player2
        self.board = [[None for _ in range(3)] for _ in range(3)]

    def player1Won(self):
        playerTurn = True
        while not self.playerXWon(True) and not self.playerXWon(False) and not self.gameOver():
             strat = self.playerOne if playerTurn else self.playerTwo
             move = strat.returnMove(self.board)
             self.board[move[0]][move[1]] = playerTurn
             playerTurn = not playerTurn
        if self.gameOver():
            return False
        else:
            return self.playerXWon(True)


    def gameOver(self):
        for row in self.board:
            for col in row:
                if col == None:
                    return False
        return True
    
    def playerXWon(self, x: bool):
        for i in range(3):
            if self.rowNX(i, x):
                return True
        for i in range(3):
            if self.colNX(i, x):
                return True
        downDiag = self.board[0][0] == x and self.board[1][1] == x and self.board[2][2] == x
        upDiag = self.board[2][0] == x and self.board[1][1] == x and self.board[0][2] == x
        return downDiag or upDiag
    


    def rowNX(self, n: int, x: bool):
        for col in self.board[n]:
            if col != x:
                return False
        return True
    def colNX(self, n: int, x: bool):
        for row in self.board:
            if row[n] != x:
                return False
        return True
