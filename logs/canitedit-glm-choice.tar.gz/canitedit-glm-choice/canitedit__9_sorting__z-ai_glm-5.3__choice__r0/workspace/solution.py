class Sorter:
    def __init__(self):
        pass

    def sort(self, nums: list[int]):
        """Sort `nums` in ascending order, in place."""
        for i in range(1, len(nums)):
            self.insert(nums, i)

    def insert(self, nums: list[int], index: int) -> None:
        """Insert nums[index] into the sorted prefix nums[:index], in place."""
        num = nums[index]
        while index > 0 and num < nums[index - 1]:
            nums[index] = nums[index - 1]
            index -= 1
        nums[index] = num
