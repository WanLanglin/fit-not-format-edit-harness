import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)

    vowels = "aeiouy"
    words = line.split(" ")

    for word, next_word in zip(words, words[1:]):
        # The first word of a 'combo' ends with a vowel, with a vowel
        # followed by 'm', or with a vowel followed by 'h'.
        first_elides = bool(word) and (
            word[-1] in vowels
            or (len(word) > 1 and word[-1] in "mh" and word[-2] in vowels)
        )

        # The second word of a 'combo' starts with a vowel, or with 'h'
        # followed by a vowel.
        second_elides = bool(next_word) and (
            next_word[0] in vowels
            or (len(next_word) > 1 and next_word[0] == "h" and next_word[1] in vowels)
        )

        if first_elides and second_elides:
            # The vowels of a 'combo' are pronounced as a single syllable,
            # so one syllable is lost at this word boundary.
            syllable_count -= 1

    return syllable_count
