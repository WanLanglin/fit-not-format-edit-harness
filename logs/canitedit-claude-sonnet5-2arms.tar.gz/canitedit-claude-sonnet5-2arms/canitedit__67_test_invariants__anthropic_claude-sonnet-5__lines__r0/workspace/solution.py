class Employer:
    """
    Represents an entity that employs workers.
    """

    def __init__(self, name, funds):
        self.name = name
        self.funds = funds


class Worker:
    """
    Represents a person who does work for an employer.
    Name should be "[first name] [last name]" and pay 
    should be positive.
    """

    def __init__(self, name, pay, company):
        self.name = name
        self.pay = pay
        self.company = company
        self.money = 0

    def lastName(self):
        """
        Returns the last name of the worker.
        """
        return self.name.split()[-1]

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay
        self.company.funds -= self.pay

    def giveRaise(self, percent):
        """
        Gives the worker a raise in pay, given as a percentage of
        the current pay.
        """
        self.pay *= (1.0 + percent)


class PublicWorker(Worker):
    """
    Represents a worker who works for the government.
    People who work for the government are special
    because they are paid with public funds, which
    are virtually unlimited because of public debt.
    """

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay


import copy


def test_worker_invariants(w: Worker):
    """
    Asserts the invariants that all Worker instances must satisfy:
      - name is "[first name] [last name]"
      - pay is non-negative
      - lastName() returns the last name
      - givePay() adds pay to worker's money and removes it from the
        employer's funds
      - giveRaise(percent) multiplies pay by (1.0 + percent)
    """
    # name invariant: exactly a first name and a last name separated by
    # a single space
    assert isinstance(w.name, str)
    parts = w.name.split(" ")
    assert len(parts) == 2
    assert all(part != "" for part in parts)

    # lastName() invariant
    assert w.lastName() == parts[-1]

    # pay invariant
    assert w.pay >= 0

    # givePay() invariant, checked on a copy to avoid mutating w
    w_copy = copy.deepcopy(w)
    old_money = w_copy.money
    old_funds = w_copy.company.funds
    pay = w_copy.pay
    w_copy.givePay()
    assert w_copy.money == old_money + pay
    assert w_copy.company.funds == old_funds - pay
    assert w_copy.pay >= 0

    # giveRaise() invariant, checked on a (different) copy
    r_copy = copy.deepcopy(w)
    old_pay = r_copy.pay
    percent = 0.2
    r_copy.giveRaise(percent)
    assert r_copy.pay == old_pay * (1.0 + percent)


def test_public_worker_invariants(w: PublicWorker):
    """
    Asserts the invariants that all PublicWorker instances must satisfy:
    all the Worker invariants, plus the fact that givePay() does not
    remove any funds from the employer, since public workers are paid
    with (effectively unlimited) public funds.
    """
    # PublicWorker must satisfy all the base Worker invariants first,
    # except that givePay() behaves differently, so re-check the
    # name/pay/lastName/giveRaise invariants directly here as well.
    test_worker_invariants_common(w)

    # givePay() invariant specific to PublicWorker: money increases by
    # pay, but the employer's funds are untouched
    w_copy = copy.deepcopy(w)
    old_money = w_copy.money
    old_funds = w_copy.company.funds
    pay = w_copy.pay
    w_copy.givePay()
    assert w_copy.money == old_money + pay
    assert w_copy.company.funds == old_funds
    assert w_copy.pay >= 0


def test_worker_invariants_common(w):
    """
    Checks the invariants shared by Worker and PublicWorker that do not
    depend on the specific behavior of givePay().
    """
    assert isinstance(w.name, str)
    parts = w.name.split(" ")
    assert len(parts) == 2
    assert all(part != "" for part in parts)

    assert w.lastName() == parts[-1]

    assert w.pay >= 0

    r_copy = copy.deepcopy(w)
    old_pay = r_copy.pay
    percent = 0.2
    r_copy.giveRaise(percent)
    assert r_copy.pay == old_pay * (1.0 + percent)
