from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        sequence: List[Token | float] = list(inputs)

        while True:
            operator_index = next(
                (index for index, token in enumerate(sequence) if token in {"+", "-", "*", "/"}),
                None,
            )
            if operator_index is None:
                break
            if operator_index < 2:
                raise Exception("Malformed postfix expression")

            operator = sequence[operator_index]
            left = sequence[operator_index - 2]
            right = sequence[operator_index - 1]
            if isinstance(left, str) or isinstance(right, str):
                raise Exception("Malformed postfix expression")

            match operator:
                case "+":
                    result = left + right
                case "-":
                    result = left - right
                case "*":
                    result = left * right
                case "/":
                    result = left / right
                case _:
                    raise Exception("Malformed postfix expression")

            sequence[operator_index - 2 : operator_index + 1] = [result]

        if len(sequence) != 1 or isinstance(sequence[0], str):
            raise Exception("Malformed postfix expression")
        return sequence[0]
