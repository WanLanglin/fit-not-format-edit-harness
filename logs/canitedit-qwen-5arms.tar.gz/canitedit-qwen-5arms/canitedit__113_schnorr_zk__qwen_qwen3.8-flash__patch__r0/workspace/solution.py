import hashlib
from typing import Tuple


def keygen(p: int, g: int, x: int) -> Tuple[Tuple[int, int, int], int]:
    """generate public and private key with given prime (p), base (g), and private key (x)."""
    y = pow(g, x, p)  # public key
    return (p, g, y), x


def prover_commitment(p: int, g: int, r: int) -> Tuple[int, int]:
    """step 1: Prover sends a commitment with given random value (r)."""
    t = pow(g, r, p)
    return t, r


def hash_to_challenge(t: int, y: int, p: int) -> int:
    """step 2 (non-interactive): derive the challenge from the transcript.

    Fiat-Shamir heuristic: instead of waiting for a random challenge from an
    online verifier, the challenge is the SHA-256 hash of the whole transcript,
    i.e. of *all* values that bind the proof to this statement -- the prover
    commitment ``t``, the public key ``y`` and the prime ``p``.  SHA-256 is used
    because modelling it as a random oracle makes the resulting challenge
    unpredictable to a prover that has not fixed ``t`` yet, which is what keeps
    the non-interactive proof sound (and zero knowledge).

    The returned challenge is an integer in ``[1, p-1]`` (never 0, so the proof
    always constrains the secret key).
    """
    if p < 3:
        raise ValueError("p must be at least 3 to derive a challenge")

    # A domain-separation tag plus explicit field/length separators guarantees
    # that distinct (t, y, p) triples cannot be encoded to the same bytes, so
    # every supplied value contributes to the digest.
    transcript = b"|".join(
        (
            b"Schnorr-NIZK-SHA256-v1",
            b"t=" + str(int(t)).encode("ascii"),
            b"y=" + str(int(y)).encode("ascii"),
            b"p=" + str(int(p)).encode("ascii"),
        )
    )
    digest = hashlib.sha256(transcript).digest()

    # map the 256-bit digest uniformly-ish into [1, p-1]
    return int.from_bytes(digest, "big") % (p - 1) + 1


def prover_response(r: int, c: int, x: int, p: int) -> int:
    """step 3: Prover sends a response."""
    s = (r + c * x) % (p-1)
    return s


def verifier_check(p: int, g: int, y: int, t: int, c: int, s: int) -> bool:
    """verifier checks the prover's response against the challenge (c)."""
    return pow(g, s, p) == (t * pow(y, c, p)) % p


def schnorr_protocol(p: int, g: int, x: int, r: int, bits: int = 256) -> bool:
    """Demonstrate the *non-interactive* (Fiat-Shamir) Schnorr proof.

    No verifier message is needed any more: the prover emits the transcript
    ``(t, s)`` on its own, and the verifier re-derives the challenge itself from
    ``(t, y, p)`` via :func:`hash_to_challenge`.  Hence the ``c`` argument of the
    interactive version is gone.
    """
    if (not 2 <= g <= p-1) or (not 2 <= x <= p-2) or (not 2 <= r <= p-2):
        return False
    # key generation
    params, x = keygen(p, g, x)
    p, g, y = params

    # step 1: Commitment
    t, r = prover_commitment(p, g, r)

    # step 2: Challenge -- computed from the transcript, not sent by a verifier
    c = hash_to_challenge(t, y, p)

    # step 3: Response -- the non-interactive proof is the pair (t, s)
    s = prover_response(r, c, x, p)

    # verification: an offline verifier re-computes the challenge from (t, y, p)
    # and checks g**s == t * y**c (mod p).  Nothing else is recomputed by the
    # prover -- the same hash is used on both sides, so the proof is one-way.
    return verifier_check(p, g, y, t, hash_to_challenge(t, y, p), s)
