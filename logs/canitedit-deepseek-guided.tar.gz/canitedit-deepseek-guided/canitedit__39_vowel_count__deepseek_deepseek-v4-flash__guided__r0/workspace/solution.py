import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    prepared = prepare_line(line)
    diphthongs = sorted(["ae", "oe", "ei", "ea", "ia", "io", "aea"], key=len, reverse=True)
    count = 0
    i = 0
    n = len(prepared)
    while i < n:
        if prepared[i] not in "aeiouy":
            i += 1
            continue
        matched = False
        for d in diphthongs:
            if prepared.startswith(d, i):
                i += len(d)
                matched = True
                break
        if not matched:
            count += 1
            i += 1
    return count
