"""Ad-hoc regression checks for binary_search returning the FIRST occurrence.

Run with:  python verify_first_occurrence.py
"""

import random

from solution import binary_search

CASES = [
    ([1, 2, 3, 4, 5], 3, 2),        # single hit, unchanged behavior
    ([1, 2, 2, 2, 3, 4], 2, 1),     # duplicates -> leftmost index
    ([2, 2, 2], 2, 0),              # all duplicates
    ([1, 2, 3, 4, 4, 4, 5], 4, 3),  # naive midpoint lands on a duplicate
    ([1, 3, 5, 7], 6, -1),          # missing
    ([], 1, -1),                    # empty
    ([5], 5, 0),
    ([5], 4, -1),
    ([-3, -3, 0, 2, 2, 2], -3, 0),  # duplicates at the very start
    ([1] * 100, 1, 0),              # large duplicate block
]


def first_index(lst, x):
    return next((i for i, v in enumerate(lst) if v == x), -1)


def main():
    for lst, x, expected in CASES:
        got = binary_search(lst, x)
        assert got == expected, f"binary_search({lst}, {x}) -> {got}, expected {expected}"
        assert got == first_index(lst, x), f"linear-scan mismatch for {lst}, {x}"

    random.seed(0)
    for _ in range(5000):
        lst = sorted(random.randint(-30, 30) for _ in range(random.randint(0, 40)))
        x = random.randint(-32, 32)
        got = binary_search(lst, x)
        assert got == first_index(lst, x), (lst, x, got)

    print("all checks passed")


if __name__ == "__main__":
    main()
