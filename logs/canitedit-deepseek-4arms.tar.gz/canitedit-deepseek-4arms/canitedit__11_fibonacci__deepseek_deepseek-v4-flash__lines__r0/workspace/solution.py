class Fib:
    def __iter__(self):
        self.prev_prev = 0
        self.prev = 1
        return self
    def __next__(self):
        output = self.prev + self.prev_prev
        self.prev_prev = self.prev
        self.prev = output
        return output
    def next_n_fibs(self, n: int):
        prev_prev, prev = self.prev_prev, self.prev
        result = []
        for _ in range(n):
            output = prev + prev_prev
            result.append(output)
            prev_prev, prev = prev, output
        return result
