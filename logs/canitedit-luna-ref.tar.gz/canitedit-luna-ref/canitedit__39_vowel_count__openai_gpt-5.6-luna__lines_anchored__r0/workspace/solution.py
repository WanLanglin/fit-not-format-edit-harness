import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    diphthongs = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]
    vowel_count = 0
    index = 0
    while index < len(line):
        if any(line.startswith(diphthong, index) for diphthong in diphthongs):
            index += max(
                len(diphthong)
                for diphthong in diphthongs
                if line.startswith(diphthong, index)
            )
        else:
            if line[index] in "aeiouy":
                vowel_count += 1
            index += 1
    return vowel_count
