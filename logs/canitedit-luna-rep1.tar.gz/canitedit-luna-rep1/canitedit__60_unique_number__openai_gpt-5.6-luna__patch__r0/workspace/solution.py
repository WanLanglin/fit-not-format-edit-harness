from typing import List


def find_non_pair(numbers: List[int]) -> int:
    non_pair = 0
    for number in numbers:
        non_pair ^= number
    return non_pair
