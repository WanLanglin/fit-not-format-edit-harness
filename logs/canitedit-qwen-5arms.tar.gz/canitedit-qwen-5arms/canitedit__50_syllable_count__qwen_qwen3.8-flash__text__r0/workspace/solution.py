import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

VOWELS = "aeiouy"

def vowel_count(line):
    # Plain number of vowels in the line: this deliberately does NOT take any
    # "combo" (elision) spanning a word boundary into account, that is handled
    # by syllable_count() below.
    vowel_count = 0
    for c in line:
        if c in VOWELS:
            vowel_count += 1
    return vowel_count

def combo_count(line):
    """Count the number of 'combo's in `line`.

    A combo happens across the boundary between two words (words are the
    substrings separated by " ") when a word that ends in a vowel -- possibly
    followed by 'm' or 'h' -- is followed by a word that begins with a vowel,
    possibly preceded by 'h':

      V  # V      e.g. "mare et"
      Vm # V      e.g. "repostum iudicium"
      Vh # V      e.g. "magnh illa"   (vowel + h at the end of a word)
      V  # hV     e.g. "pondere habentia"
      Vm # hV     e.g. "sam henry"

    where V is a vowel ('y' included) and '#' is the space between two words.
    Each combo merges two vowels into a single syllable.
    """
    combos = 0
    words = line.split(" ")

    for i in range(len(words) - 1):
        current, following = words[i], words[i + 1]
        if not current or not following:
            continue

        # the first word must end in a vowel, optionally followed by m or h
        if current[-1] in VOWELS:
            pass
        elif current[-1] in "mh" and len(current) > 1 and current[-2] in VOWELS:
            pass
        else:
            continue

        # the next word must begin with a vowel, optionally preceded by h
        if following[0] in VOWELS:
            combos += 1
        elif following[0] == "h" and len(following) > 1 and following[1] in VOWELS:
            combos += 1

    return combos

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    # every combo (a vowel at the end of a word elided against a vowel at the
    # beginning of the next one) accounts for one syllable less than the two
    # vowels it joins
    syllable_count -= combo_count(line)

    return syllable_count
