import ast


class UsageCounter(ast.NodeVisitor):
    """
    Counts the usages of each identifier in the given AST.
    An usage does not count the definition or assignment itself;
    only identifiers that are used after their definition/assignment are counted.
    NOTE: This class does not handle the scoping rules of Python;
    it simply counts the usages based on the name of the identifiers.
    It also only supports identifiers defined in either a function (including
    its arguments) or an assignment operation (including tuple targets).
    """

    def __init__(self):
        self.usages = {}

    def visit_Name(self, node):
        if node.id in self.usages:
            self.usages[node.id] += 1
            self.generic_visit(node)

    def visit_FunctionDef(self, node):
        self._visit_function(node)

    def visit_AsyncFunctionDef(self, node):
        self._visit_function(node)

    def visit_Lambda(self, node):
        for name in self._argument_names(node.args):
            self._define(name)
        self.generic_visit(node)

    def _visit_function(self, node):
        self._define(node.name)
        for name in self._argument_names(node.args):
            self._define(name)
        self.generic_visit(node)

    def visit_Assign(self, node):
        defined_names = []
        for target in node.targets:
            defined_names.extend(self._target_names(target))

        for name in defined_names:
            self._define(name)

        self.generic_visit(node)
        # The assignment targets are Name nodes too, so they are counted as
        # usages while visiting; undo that so the definitions are not counted.
        for name in defined_names:
            self.usages[name] -= 1

    def _define(self, name):
        """Add ``name`` to the known identifiers, without counting a usage."""
        if name not in self.usages:
            self.usages[name] = 0

    @staticmethod
    def _argument_names(arguments):
        """Return the names of the arguments of a function or lambda."""
        args = list(getattr(arguments, "posonlyargs", [])) + list(arguments.args)
        if arguments.vararg is not None:
            args.append(arguments.vararg)
        args.extend(arguments.kwonlyargs)
        if arguments.kwarg is not None:
            args.append(arguments.kwarg)
        return [argument.arg for argument in args]

    @classmethod
    def _target_names(cls, target):
        """Return the names defined by an assignment target."""
        if isinstance(target, ast.Name):
            return [target.id]
        if isinstance(target, (ast.Tuple, ast.List)):
            names = []
            for element in target.elts:
                names.extend(cls._target_names(element))
            return names
        if isinstance(target, ast.Starred):
            return cls._target_names(target.value)
        return []
