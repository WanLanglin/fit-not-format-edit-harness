from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""
        sequence = list(inputs)
        operators = {"+", "-", "*", "/"}

        while True:
            operator_index = next(
                (index for index, token in enumerate(sequence) if token in operators),
                None,
            )
            if operator_index is None:
                if len(sequence) != 1 or not isinstance(sequence[0], int):
                    raise Exception("malformed postfix expression")
                return sequence[0]

            if operator_index < 2 or not all(
                isinstance(token, int)
                for token in sequence[operator_index - 2 : operator_index]
            ):
                raise Exception("malformed postfix expression")

            left, right = sequence[operator_index - 2 : operator_index]
            operator = sequence[operator_index]
            match operator:
                case "+":
                    result = left + right
                case "-":
                    result = left - right
                case "*":
                    result = left * right
                case "/":
                    result = left / right

            sequence[operator_index - 2 : operator_index + 1] = [result]
