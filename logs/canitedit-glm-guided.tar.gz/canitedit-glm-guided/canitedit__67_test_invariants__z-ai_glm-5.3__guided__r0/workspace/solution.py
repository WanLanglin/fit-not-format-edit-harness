import math


class Employer:
    """
    Represents an entity that employs workers.
    """

    def __init__(self, name, funds):
        self.name = name
        self.funds = funds


class Worker:
    """
    Represents a person who does work for an employer.
    Name should be "[first name] [last name]" and pay 
    should be positive.
    """

    def __init__(self, name, pay, company):
        self.name = name
        self.pay = pay
        self.company = company
        self.money = 0

    def lastName(self):
        """
        Returns the last name of the worker.
        """
        return self.name.split()[-1]

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay
        self.company.funds -= self.pay

    def giveRaise(self, percent):
        """
        Gives the worker a raise in pay, given as a percentage of
        the current pay.
        """
        self.pay *= (1.0 + percent)


class PublicWorker(Worker):
    """
    Represents a worker who works for the government.
    People who work for the government are special
    because they are paid with public funds, which
    are virtually unlimited because of public debt.
    """

    def givePay(self):
        """
        Pays the worker, which adds to the worker's money.
        and removes from the company's funds.
        """
        self.money += self.pay


# ---------------------------------------------------------------------------
# Invariant checks
# ---------------------------------------------------------------------------
# test_worker_invariants and test_public_worker_invariants each take a worker
# in an arbitrary state and check every invariant of that worker with assert
# statements.  Both leave the worker and its company exactly as they found
# them, so they may be called repeatedly, in any order, and on workers that
# are already part way through their working life.
# ---------------------------------------------------------------------------


def _at_least(value, bound):
    """
    Returns True when value is a number that is at least bound.  A value
    that cannot be compared with a number at all returns False, so a check
    written with _at_least can only ever fail an assert instead of raising
    some other kind of error.
    """
    try:
        return value >= bound
    except TypeError:
        return False


def _is_number(value):
    """
    Returns True when value behaves like a number, which the pay, the
    money and the company funds of a worker all have to.
    """
    return _at_least(value, float("-inf"))


def _close(actual, expected):
    """
    Returns True when two numbers are equal, ignoring the tiny rounding
    differences that floating point arithmetic can introduce.  Values that
    cannot be treated as numbers return False.
    """
    try:
        return math.isclose(float(actual), float(expected),
                            rel_tol=1e-9, abs_tol=1e-9)
    except (TypeError, ValueError, OverflowError):
        return False


def test_worker_invariants(w: Worker):
    """
    Checks every invariant of a Worker with assert statements:

    * the worker has a name, a pay, a money balance, a company and the
      methods lastName, givePay and giveRaise,
    * the name is a first name and a last name separated by exactly one
      space, with nothing missing and no other whitespace,
    * lastName() returns the last name,
    * the pay and the money earned so far are non-negative numbers,
    * the worker works for a company that has funds,
    * givePay() adds the pay to the worker's money, removes the same
      amount from the company's funds, and changes nothing else,
    * giveRaise(percent) multiplies the pay by (1 + percent), measured
      against the pay at that moment, and changes nothing else.
    """
    # The worker must be made of all the pieces a worker is made of.
    assert hasattr(w, "name"), "a worker must have a name"
    assert hasattr(w, "pay"), "a worker must have a pay"
    assert hasattr(w, "money"), "a worker must have a money balance"
    assert hasattr(w, "company"), "a worker must have a company"
    assert callable(getattr(w, "lastName", None)), "a worker must have lastName()"
    assert callable(getattr(w, "givePay", None)), "a worker must have givePay()"
    assert callable(getattr(w, "giveRaise", None)), "a worker must have giveRaise()"

    # The name must be a first name and a last name separated by exactly
    # one space: two non-empty parts and no other whitespace anywhere.
    assert isinstance(w.name, str), f"the name must be a string, got {w.name!r}"
    parts = w.name.split(" ")
    assert len(parts) == 2, (
        f"the name must be '[first name] [last name]', got {w.name!r}"
    )
    first_name, last_name = parts
    assert first_name != "", f"the name must have a first name, got {w.name!r}"
    assert last_name != "", f"the name must have a last name, got {w.name!r}"
    assert w.name == first_name + " " + last_name, (
        f"the name must be '[first name] [last name]', got {w.name!r}"
    )

    # lastName() must report the last name.
    assert w.lastName() == last_name, (
        f"lastName() must return {last_name!r}, got {w.lastName()!r}"
    )

    # The pay and the money earned so far must be non-negative numbers.
    assert _is_number(w.pay), f"the pay must be a number, got {w.pay!r}"
    assert _at_least(w.pay, 0), f"the pay must be non-negative, got {w.pay!r}"
    assert _is_number(w.money), f"the money must be a number, got {w.money!r}"
    assert _at_least(w.money, 0), (
        f"the money must be non-negative, got {w.money!r}"
    )

    # The worker must work for a company that has funds.
    assert w.company is not None, "a worker must have a company"
    assert hasattr(w.company, "funds"), "the company must have funds"
    assert _is_number(w.company.funds), (
        f"the company funds must be a number, got {w.company.funds!r}"
    )

    # Everything from here on moves money around, so remember the whole
    # state of the worker and of its company, and put it back at the end.
    saved_name = w.name
    saved_pay = w.pay
    saved_money = w.money
    saved_company = w.company
    saved_funds = w.company.funds
    try:
        # Work with a strictly positive pay, so that a payment and a raise
        # both have a visible effect even if the worker was created with a
        # pay of zero.
        pay = saved_pay if saved_pay > 0 else 100.0
        w.pay = pay

        # givePay(): the worker gains the pay and the company loses it.
        w.givePay()
        assert _close(w.money, saved_money + pay), (
            f"givePay must add {pay!r} to the worker's money, but the money "
            f"went from {saved_money!r} to {w.money!r}"
        )
        assert _close(w.company.funds, saved_funds - pay), (
            f"givePay must take {pay!r} out of the company's funds, but the "
            f"funds went from {saved_funds!r} to {w.company.funds!r}"
        )

        # A second payment must add to the money that is already there
        # rather than replace it, and must take another bite out of the
        # company's funds.
        w.givePay()
        assert _close(w.money, saved_money + 2 * pay), (
            "givePay must add to the money the worker already has, but the "
            f"money is {w.money!r} instead of {saved_money + 2 * pay!r}"
        )
        assert _close(w.company.funds, saved_funds - 2 * pay), (
            "givePay must keep taking the pay out of the company's funds, "
            f"but the funds are {w.company.funds!r} instead of "
            f"{saved_funds - 2 * pay!r}"
        )

        # Being paid must not touch anything else about the worker.
        assert _close(w.pay, pay), "givePay must not change the pay"
        assert w.name == saved_name, "givePay must not change the name"
        assert w.company is saved_company, "givePay must not change the company"

        money_after_pay = w.money
        funds_after_pay = w.company.funds

        # giveRaise(): the pay grows by the given percentage of the pay the
        # worker has at that moment, and a second raise compounds on the
        # new pay.
        w.giveRaise(0.5)
        assert _close(w.pay, pay * 1.5), (
            f"giveRaise(0.5) must set the pay to {pay * 1.5!r}, got {w.pay!r}"
        )
        w.giveRaise(0.5)
        assert _close(w.pay, pay * 1.5 * 1.5), (
            "giveRaise must work on the pay the worker has at the time, so "
            f"two raises of 50% must set the pay to {pay * 1.5 * 1.5!r}, "
            f"got {w.pay!r}"
        )

        # A raise must keep the pay a non-negative number and must not
        # touch anything else about the worker or its company.
        assert _at_least(w.pay, 0), "a raise must keep the pay non-negative"
        assert _close(w.money, money_after_pay), (
            "giveRaise must not change the worker's money"
        )
        assert _close(w.company.funds, funds_after_pay), (
            "giveRaise must not change the company's funds"
        )
        assert w.name == saved_name, "giveRaise must not change the name"
        assert w.company is saved_company, (
            "giveRaise must not change the company"
        )
    finally:
        w.name = saved_name
        w.pay = saved_pay
        w.money = saved_money
        w.company = saved_company
        saved_company.funds = saved_funds


def test_public_worker_invariants(w: PublicWorker):
    """
    Checks every invariant of a PublicWorker with assert statements:

    * the worker has a name, a pay, a money balance, a company and the
      methods lastName, givePay and giveRaise,
    * the name is a first name and a last name separated by exactly one
      space, with nothing missing and no other whitespace,
    * lastName() returns the last name,
    * the pay and the money earned so far are non-negative numbers,
    * the worker works for a company that has funds,
    * givePay() adds the pay to the worker's money.  A public worker is
      paid out of public funds, which are unlimited because of public
      debt, so the company's funds are left untouched and nothing else
      changes,
    * giveRaise(percent) multiplies the pay by (1 + percent), measured
      against the pay at that moment, and changes nothing else.
    """
    # The worker must be made of all the pieces a worker is made of.
    assert hasattr(w, "name"), "a worker must have a name"
    assert hasattr(w, "pay"), "a worker must have a pay"
    assert hasattr(w, "money"), "a worker must have a money balance"
    assert hasattr(w, "company"), "a worker must have a company"
    assert callable(getattr(w, "lastName", None)), "a worker must have lastName()"
    assert callable(getattr(w, "givePay", None)), "a worker must have givePay()"
    assert callable(getattr(w, "giveRaise", None)), "a worker must have giveRaise()"

    # The name must be a first name and a last name separated by exactly
    # one space: two non-empty parts and no other whitespace anywhere.
    assert isinstance(w.name, str), f"the name must be a string, got {w.name!r}"
    parts = w.name.split(" ")
    assert len(parts) == 2, (
        f"the name must be '[first name] [last name]', got {w.name!r}"
    )
    first_name, last_name = parts
    assert first_name != "", f"the name must have a first name, got {w.name!r}"
    assert last_name != "", f"the name must have a last name, got {w.name!r}"
    assert w.name == first_name + " " + last_name, (
        f"the name must be '[first name] [last name]', got {w.name!r}"
    )

    # lastName() must report the last name.
    assert w.lastName() == last_name, (
        f"lastName() must return {last_name!r}, got {w.lastName()!r}"
    )

    # The pay and the money earned so far must be non-negative numbers.
    assert _is_number(w.pay), f"the pay must be a number, got {w.pay!r}"
    assert _at_least(w.pay, 0), f"the pay must be non-negative, got {w.pay!r}"
    assert _is_number(w.money), f"the money must be a number, got {w.money!r}"
    assert _at_least(w.money, 0), (
        f"the money must be non-negative, got {w.money!r}"
    )

    # The worker must work for a company that has funds.
    assert w.company is not None, "a worker must have a company"
    assert hasattr(w.company, "funds"), "the company must have funds"
    assert _is_number(w.company.funds), (
        f"the company funds must be a number, got {w.company.funds!r}"
    )

    # Everything from here on moves money around, so remember the whole
    # state of the worker and of its company, and put it back at the end.
    saved_name = w.name
    saved_pay = w.pay
    saved_money = w.money
    saved_company = w.company
    saved_funds = w.company.funds
    try:
        # Work with a strictly positive pay, so that a payment and a raise
        # both have a visible effect even if the worker was created with a
        # pay of zero.
        pay = saved_pay if saved_pay > 0 else 100.0
        w.pay = pay

        # givePay(): the worker gains the pay, and because public funds
        # are unlimited the company's funds are left alone.
        w.givePay()
        assert _close(w.money, saved_money + pay), (
            f"givePay must add {pay!r} to the worker's money, but the money "
            f"went from {saved_money!r} to {w.money!r}"
        )
        assert _close(w.company.funds, saved_funds), (
            "a public worker is paid out of unlimited public funds, so "
            f"givePay must leave the company's funds at {saved_funds!r}, "
            f"but they are now {w.company.funds!r}"
        )

        # A second payment must add to the money that is already there
        # rather than replace it, and must still leave the funds alone.
        w.givePay()
        assert _close(w.money, saved_money + 2 * pay), (
            "givePay must add to the money the worker already has, but the "
            f"money is {w.money!r} instead of {saved_money + 2 * pay!r}"
        )
        assert _close(w.company.funds, saved_funds), (
            "a public worker is paid out of unlimited public funds, so "
            f"givePay must leave the company's funds at {saved_funds!r}, "
            f"but they are now {w.company.funds!r}"
        )

        # Being paid must not touch anything else about the worker.
        assert _close(w.pay, pay), "givePay must not change the pay"
        assert w.name == saved_name, "givePay must not change the name"
        assert w.company is saved_company, "givePay must not change the company"

        money_after_pay = w.money
        funds_after_pay = w.company.funds

        # giveRaise(): the pay grows by the given percentage of the pay the
        # worker has at that moment, and a second raise compounds on the
        # new pay.
        w.giveRaise(0.5)
        assert _close(w.pay, pay * 1.5), (
            f"giveRaise(0.5) must set the pay to {pay * 1.5!r}, got {w.pay!r}"
        )
        w.giveRaise(0.5)
        assert _close(w.pay, pay * 1.5 * 1.5), (
            "giveRaise must work on the pay the worker has at the time, so "
            f"two raises of 50% must set the pay to {pay * 1.5 * 1.5!r}, "
            f"got {w.pay!r}"
        )

        # A raise must keep the pay a non-negative number and must not
        # touch anything else about the worker or its company.
        assert _at_least(w.pay, 0), "a raise must keep the pay non-negative"
        assert _close(w.money, money_after_pay), (
            "giveRaise must not change the worker's money"
        )
        assert _close(w.company.funds, funds_after_pay), (
            "giveRaise must not change the company's funds"
        )
        assert w.name == saved_name, "giveRaise must not change the name"
        assert w.company is saved_company, (
            "giveRaise must not change the company"
        )
    finally:
        w.name = saved_name
        w.pay = saved_pay
        w.money = saved_money
        w.company = saved_company
        saved_company.funds = saved_funds
