import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    diphthongs = ("aea", "ae", "oe", "ei", "ea", "ia", "io")
    vowel_count = 0
    position = 0

    while position < len(line):
        diphthong = next(
            (item for item in diphthongs if line.startswith(item, position)),
            None,
        )
        if diphthong:
            vowel_count += 1
            position += len(diphthong)
        else:
            if line[position] in "aeiouy":
                vowel_count += 1
            position += 1

    return vowel_count
