import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def combo_count(line):
    vowels = "aeiouy"
    combo_count = 0

    words = line.split(" ")
    for left, right in zip(words, words[1:]):
        left_ends_with_vowel = bool(left) and left[-1] in vowels
        left_ends_with_vowel_m = len(left) >= 2 and left[-2] in vowels and left[-1] == "m"
        left_ends_with_vowel_h = len(left) >= 2 and left[-2] in vowels and left[-1] == "h"
        right_starts_with_vowel = bool(right) and right[0] in vowels
        right_starts_with_h_vowel = (
            len(right) >= 2 and right[0] == "h" and right[1] in vowels
        )

        if (left_ends_with_vowel or left_ends_with_vowel_m) and (
                right_starts_with_vowel or right_starts_with_h_vowel):
            combo_count += 1

    return combo_count


def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
