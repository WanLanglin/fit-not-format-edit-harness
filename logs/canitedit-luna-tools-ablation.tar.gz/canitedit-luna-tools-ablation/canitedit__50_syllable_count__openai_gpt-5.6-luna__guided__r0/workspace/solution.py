import string

def prepare_string(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line.lower()

def vowel_count(line):
    vowel_count = 0
    for c in line:
        if c in "aeiouy":
            vowel_count += 1
    return vowel_count

def combo_count(line):
    vowels = "aeiouy"
    combos = 0

    words = line.split(" ")
    for word, next_word in zip(words, words[1:]):
        if not word or not next_word:
            continue

        # A combo is one vowel sound spanning the word boundary.  The
        # optional m/h belongs to the end of the first word, except that
        # m may be followed by h at the start of the next word.
        if ((word[-1] in vowels and next_word[0] in vowels) or
            (len(word) >= 2 and word[-2] in vowels and
             word[-1] in "mh" and next_word[0] in vowels) or
            (len(word) >= 2 and word[-2] in vowels and word[-1] == "m" and
             len(next_word) >= 2 and next_word[0] == "h" and
             next_word[1] in vowels)):
            combos += 1

    return combos

def syllable_count(line):
    syllable_count = 0

    assert type(line) == str
    line = prepare_string(line)

    syllable_count += vowel_count(line)
    syllable_count -= combo_count(line)

    return syllable_count
