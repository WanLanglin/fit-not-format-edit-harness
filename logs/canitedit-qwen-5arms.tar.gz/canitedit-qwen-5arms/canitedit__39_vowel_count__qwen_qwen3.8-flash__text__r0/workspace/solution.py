import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

DIPHTHONGS = ["ae", "oe", "ei", "ea", "ia", "io", "aea"]
# longest first so that e.g. "aea" is skipped in one go instead of matching "ae"
DIPHTHONGS_BY_LENGTH = sorted(DIPHTHONGS, key=len, reverse=True)

def strip_diphthongs(line):
    stripped = []
    index = 0
    while index < len(line):
        for diphthong in DIPHTHONGS_BY_LENGTH:
            if line.startswith(diphthong, index):
                index += len(diphthong)
                break
        else:
            stripped.append(line[index])
            index += 1
    return "".join(stripped)

def vowel_count(line):
    vowel_count = 0
    for letter in strip_diphthongs(prepare_line(line)):
        if letter in "aeiouy":
            vowel_count += 1
    return vowel_count
