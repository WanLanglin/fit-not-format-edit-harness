from typing import Literal, List

Op = Literal["+", "-", "*", "/"]
Token = int | Op


class PostfixParser:
    def parse(self, inputs: List[Token]) -> float:
        """parses a sequence of input tokens using postfix notation and computes the result"""

        tokens = list(inputs)
        while True:
            for i in range(len(tokens)):
                if isinstance(tokens[i], str) and tokens[i] in ("+", "-", "*", "/"):
                    if i < 2:
                        raise Exception("malformed input")
                    b = tokens[i - 1]
                    a = tokens[i - 2]
                    if tokens[i] == "+":
                        result = a + b
                    elif tokens[i] == "-":
                        result = a - b
                    elif tokens[i] == "*":
                        result = a * b
                    else:
                        result = a / b
                    tokens[i - 2 : i + 1] = [result]
                    break
            else:
                break
        if len(tokens) != 1:
            raise Exception("malformed input")
        return tokens[0]
