from solution import Leaf, Node

t = Node(Leaf(1), Leaf(2))
t2 = t.tree_map(lambda x: x * 10)
assert t != Node(Leaf(10), Leaf(20)), "tree_map should not mutate original"
assert t == Node(Leaf(1), Leaf(2)), "original mutated by tree_map"
assert t2 == Node(Leaf(10), Leaf(20)), "tree_map result wrong"

t3 = t.tree_filter(lambda v: v > 1, filler=99)
assert t == Node(Leaf(1), Leaf(2)), "original mutated by tree_filter"
assert t3 == Node(Leaf(99), Leaf(99))

print("all checks passed")
