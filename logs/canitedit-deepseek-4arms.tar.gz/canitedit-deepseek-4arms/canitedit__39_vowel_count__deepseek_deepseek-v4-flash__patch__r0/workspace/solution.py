import string

DIPHTHONGS = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    count = 0
    i = 0
    n = len(line)
    while i < n:
        matched = False
        for d in DIPHTHONGS:
            if line.startswith(d, i):
                i += len(d)
                matched = True
                break
        if matched:
            continue
        if line[i] in "aeiouy":
            count += 1
        i += 1
    return count