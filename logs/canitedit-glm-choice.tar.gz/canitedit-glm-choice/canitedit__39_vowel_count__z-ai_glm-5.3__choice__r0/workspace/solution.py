import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    # Diphthongs are not counted. Longer diphthongs are matched first so that
    # "aea" is recognised as one diphthong rather than "ae" plus a lone "a".
    diphthongs = ["aea", "ae", "oe", "ei", "ea", "ia", "io"]
    vowels = "aeiouy"
    line = prepare_line(line)
    count = 0
    i = 0
    while i < len(line):
        for diphthong in diphthongs:
            if line.startswith(diphthong, i):
                i += len(diphthong)
                break
        else:
            if line[i] in vowels:
                count += 1
            i += 1
    return count
