from typing import Dict, List, Optional, Union
import re


# Matches a tag token: the angle brackets, an optional leading '/' (end tag),
# the tag name and everything that follows it (i.e. the attributes).
_TAG_PATTERN = re.compile(r'<\s*/?\s*([^\s/>]+)\s*(.*?)\s*/?>\s*$', re.DOTALL)

# Matches a single attribute: a name, optionally followed by '=' and a value.
# The value is a string which may be double quoted, single quoted or unquoted.
# A valueless attribute (e.g. 'disabled') matches the name only.
_ATTRIBUTE_PATTERN = re.compile(
    r'([^\s=/>"\']+)'      # attribute name
    r'(?:\s*=\s*'           # optional '=' followed by the value
    r'(?:"([^"]*)"'        #   double quoted value, may contain spaces
    r"|'([^']*)'"           #   single quoted value, may contain spaces
    r'|([^\s>]+)'           #   unquoted value
    r'))?'
)


class HTMLElement:
    def __init__(self, name: str,
                 content: List[Union[str, 'HTMLElement']],
                 attributes: Optional[Dict[str, Optional[str]]] = None):
        self.name = name
        self.content = content
        # The HTML attributes of the element, e.g. {'class': 'container'}.
        self.attributes = {} if attributes is None else attributes

    def __str__(self):
        # The attributes are rendered as name="value" pairs in the opening tag.
        attributes = ''.join(
            f' {name}' if value is None else f' {name}="{value}"'
            for name, value in self.attributes.items()
        )
        content = ''.join(str(c) for c in self.content)
        return f'<{self.name}{attributes}>{content}</{self.name}>'

    def __repr__(self):
        return f"HTMLElement(name={self.name}, content={repr(self.content)})"


def parse(content: str) -> List[HTMLElement]:
    """
    Parses the given HTML content and returns a list of HTMLElements.
    """
    tokens = tokenize(content)
    stack = []
    result = []

    for token in tokens:
        if is_start_tag(token):
            stack.append(HTMLElement(get_tag_name(token), [], get_attributes(token)))
        elif is_end_tag(token):
            element = stack.pop()
            if stack:
                stack[-1].content.append(element)
            else:
                result.append(element)
        else:
            if stack:
                stack[-1].content.append(token)

    return result


def tokenize(content: str) -> List[str]:
    # This regex splits the content into tags and text.
    # It looks for anything that starts with '<' and ends with '>', and treats it as a tag.
    # Everything else is treated as text.
    return re.findall(r'<[^>]+>|[^<]+', content)


def is_start_tag(token: str) -> bool:
    # A start tag starts with '<' but does not start with '</'.
    return token.startswith('<') and not token.startswith('</')


def is_end_tag(token: str) -> bool:
    # An end tag starts with '</'.
    return token.startswith('</')


def get_tag_name(token: str) -> str:
    # Extracts the tag name from a token.
    # The tag name is the first word of the token, so the attributes that
    # may follow it (and the brackets) are ignored.
    words = token.strip('<>/').split()
    return words[0] if words else ''


def get_attributes(token: str) -> Dict[str, Optional[str]]:
    """
    Extracts the HTML attributes from the given tag token.

    A tag may contain multiple attributes, and an attribute value is a string
    which may contain spaces, e.g. '<div class="a b" id=main>'.
    Attributes without a value are mapped to None.
    """
    attributes: Dict[str, Optional[str]] = {}

    match = _TAG_PATTERN.match(token)
    if match is None:
        return attributes

    for attribute in _ATTRIBUTE_PATTERN.finditer(match.group(2)):
        name = attribute.group(1)
        double_quoted, single_quoted, unquoted = attribute.group(2, 3, 4)
        if double_quoted is not None:
            attributes[name] = double_quoted
        elif single_quoted is not None:
            attributes[name] = single_quoted
        elif unquoted is not None:
            attributes[name] = unquoted
        else:
            # A valueless (boolean) attribute, e.g. '<input disabled>'.
            attributes[name] = None

    return attributes
