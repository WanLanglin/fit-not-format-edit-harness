import string

def prepare_line(line):
    for char in string.punctuation:
        line = line.replace(char, "")
    for char in string.digits:
        line = line.replace(char, "")
    return line

def vowel_count(line):
    line = prepare_line(line)
    diphthongs = sorted(["ae", "oe", "ei", "ea", "ia", "io", "aea"], key=len, reverse=True)
    count = 0
    i = 0
    while i < len(line):
        if line[i] in "aeiouy":
            # Check if this position starts a diphthong
            matched = False
            for d in diphthongs:
                if line[i:i+len(d)] == d:
                    i += len(d)
                    matched = True
                    break
            if not matched:
                count += 1
                i += 1
        else:
            i += 1
    return count
