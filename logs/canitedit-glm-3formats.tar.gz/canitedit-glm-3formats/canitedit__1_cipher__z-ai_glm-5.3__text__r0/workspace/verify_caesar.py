from solution import Cipher

c = Cipher()

# Task example: shift 4 maps 'a' -> 'e'
c.caesar_cipher(4)
cipher = c.ciphers["caesar4"]
print("name stored:", "caesar4" in c.ciphers)
print("a->", cipher["a"], "(expect e)")
print("z->", cipher["z"], "(expect d, wrap-around)")
print("full cipher4:", "".join(cipher[l] for l in c.alphabet))
print("translate 'abc' with caesar4:", c.translate("caesar4", "abc"))

# Shift 0 should be the identity mapping
c.caesar_cipher(0)
print("caesar0 identity:", "".join(c.ciphers["caesar0"][l] for l in c.alphabet))

# Negative shift goes backwards
c.caesar_cipher(-1)
print("caesar-1 'a'->", c.ciphers["caesar-1"]["a"], "(expect z)")

# Default cipher untouched
c2 = Cipher()
keys_before = set(c2.ciphers)
c2.caesar_cipher(13)
print("default preserved:", "default" in c2.ciphers, "new keys:", set(c2.ciphers) - keys_before)
print("caesar13 'n'->", c2.ciphers["caesar13"]["n"], "(expect a)")
