from solution import KeyValueCache

cache = KeyValueCache()

# Initial state
assert cache.get_hits() == 0
assert cache.get_misses() == 0
assert cache.get_num_entries() == 0
assert cache.stats == {"hits": 0, "misses": 0, "num_entries": 0}

# Insertion
cache.put("a", 1, ["alias_a"])
cache.put("b", 2)
assert cache.get_num_entries() == 2

# Hits / misses via primary
assert cache.get_by_primary("a") == 1
assert cache.get_hits() == 1 and cache.get_misses() == 0
assert cache.get_by_primary("zzz") is None
assert cache.get_hits() == 1 and cache.get_misses() == 1

# Hits / misses via secondary
assert cache.get_by_secondary("alias_a") == 1
assert cache.get_hits() == 2 and cache.get_misses() == 1
assert cache.get_by_secondary("nope") is None
assert cache.get_hits() == 2 and cache.get_misses() == 2

# Overwrite does not inflate entry count
cache.put("a", 99)
assert cache.get_num_entries() == 2

# Deletion removes entry (and secondary aliases)
cache.delete("a")
assert cache.get_num_entries() == 1
assert cache.get_by_secondary("alias_a") is None
assert cache.get_hits() == 2 and cache.get_misses() == 3

# Deleting a non-existent key is a no-op
cache.delete("ghost")
assert cache.get_num_entries() == 1

# Delete down to empty
cache.delete("b")
assert cache.get_num_entries() == 0

print("All stats assertions passed")
