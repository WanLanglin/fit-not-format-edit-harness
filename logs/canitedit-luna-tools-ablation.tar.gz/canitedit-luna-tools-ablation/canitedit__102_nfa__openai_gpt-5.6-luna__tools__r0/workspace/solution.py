from typing import Literal

Input = Literal["a", "b", ""]
State = Literal[0, 1, 2, 3]


class DFA:
    def __init__(self) -> None:
        self.current: State = 0
        self.accept: set[State] = {1, 2}

    def transition(self, input: Input) -> State:
        table = {
            # 0: {0}, 1: {1, 2}, 2: {2}, and 3: {} are the
            # subsets of NFA states represented by these DFA states.
            0: {"a": 1, "b": 3, "": 0},
            1: {"a": 3, "b": 2, "": 1},
            2: {"a": 3, "b": 2, "": 2},
            3: {"a": 3, "b": 3, "": 3},
        }
        return table[self.current][input]

    def accepted(self) -> bool:
        return self.current in self.accept
